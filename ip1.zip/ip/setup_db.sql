-- =========================================================================
-- DATABASE SETUP & MIGRATION SCRIPT FOR VMS VEHICLE & SCRAP TRANSACTION MODULES
-- Run this script in SQL Server Management Studio (SSMS) on the target database.
-- =========================================================================

-- 1. Create SystemSettings Table if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SystemSettings]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[SystemSettings](
        [Key] [varchar](100) NOT NULL PRIMARY KEY,
        [Value] [nvarchar](max) NULL,
        [UpdatedAt] [datetime] NULL
    );
END
GO

-- 2. Create ScrapProducts Table if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScrapProducts]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[ScrapProducts](
        [Id] [varchar](50) NOT NULL PRIMARY KEY,
        [Name] [nvarchar](100) NOT NULL,
        [PricePerKg] [decimal](18, 2) NOT NULL,
        [CreatedBy] [varchar](50) NULL,
        [CreatedAt] [datetime] NULL,
        [UpdatedAt] [datetime] NULL
    );
END
GO

-- 3. Create ScrapEntries Table if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScrapEntries]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[ScrapEntries](
        [Id] [varchar](50) NOT NULL PRIMARY KEY,
        [CompanyName] [nvarchar](200) NOT NULL,
        [VehicleNumber] [varchar](50) NOT NULL,
        [OwnerName] [nvarchar](100) NULL,
        [Status] [varchar](50) NOT NULL,
        [PettyCashierVerifiedAmount] [decimal](18, 2) NULL,
        [RejectReason] [nvarchar](max) NULL,
        [QueryQuestion] [nvarchar](max) NULL,
        [QueryAnswer] [nvarchar](max) NULL,
        [ProofDocument] [varchar](100) NULL,
        [CreatedBy] [varchar](50) NULL,
        [BranchId] [varchar](50) NULL,
        [BranchName] [nvarchar](100) NULL,
        [CreatedAt] [datetime] NULL,
        [UpdatedAt] [datetime] NULL,
        [ReviewedBy] [varchar](50) NULL,
        [ReviewedByRole] [varchar](50) NULL,
        [ReviewedAt] [datetime] NULL
    );
END
GO

-- 4. Create ScrapEntryItems Table if it doesn't exist
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ScrapEntryItems]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[ScrapEntryItems](
        [Id] [varchar](50) NOT NULL PRIMARY KEY,
        [ScrapEntryId] [varchar](50) NOT NULL FOREIGN KEY REFERENCES [dbo].[ScrapEntries](Id) ON DELETE CASCADE,
        [ProductId] [varchar](50) NOT NULL,
        [ProductName] [nvarchar](100) NOT NULL,
        [Weight] [decimal](18, 2) NOT NULL,
        [PricePerKg] [decimal](18, 2) NOT NULL,
        [TotalAmount] [decimal](18, 2) NOT NULL
    );
END
GO

-- 5. Setup Menu Chapter Registrations (Chapters 28 to 32)
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ChapterMaster]') AND type in (N'U'))
BEGIN
    -- Ensure custom modules exist in ChapterMaster
    IF NOT EXISTS (SELECT 1 FROM ChapterMaster WHERE ChapterId = 28)
        INSERT INTO ChapterMaster (ChapterId, ChapterName, Status) VALUES (28, 'Vehicle Trip Entry', 'Active');
    IF NOT EXISTS (SELECT 1 FROM ChapterMaster WHERE ChapterId = 29)
        INSERT INTO ChapterMaster (ChapterId, ChapterName, Status) VALUES (29, 'Vehicle Trip List', 'Active');
    IF NOT EXISTS (SELECT 1 FROM ChapterMaster WHERE ChapterId = 30)
        INSERT INTO ChapterMaster (ChapterId, ChapterName, Status) VALUES (30, 'Scrap Purchase Entry', 'Active');
    IF NOT EXISTS (SELECT 1 FROM ChapterMaster WHERE ChapterId = 31)
        INSERT INTO ChapterMaster (ChapterId, ChapterName, Status) VALUES (31, 'Scrap Entry List', 'Active');
    IF NOT EXISTS (SELECT 1 FROM ChapterMaster WHERE ChapterId = 32)
         INSERT INTO ChapterMaster (ChapterId, ChapterName, Status) VALUES (32, 'Scrap Product Master', 'Active');
END
GO

-- 6. Setup Menu Function Registrations (Functions 68 to 72)
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[FunctionMaster]') AND type in (N'U'))
BEGIN
    IF NOT EXISTS (SELECT 1 FROM FunctionMaster WHERE FunctionId = 68)
        INSERT INTO FunctionMaster (FunctionId, ChapterId, FunctionName, Url, Status) VALUES (68, 28, 'Trip Log entry', 'Transaction/VehicleTrip.aspx', 'Active');
    IF NOT EXISTS (SELECT 1 FROM FunctionMaster WHERE FunctionId = 69)
        INSERT INTO FunctionMaster (FunctionId, ChapterId, FunctionName, Url, Status) VALUES (69, 29, 'Trip Log history list', 'Transaction/VehicleTripList.aspx', 'Active');
    IF NOT EXISTS (SELECT 1 FROM FunctionMaster WHERE FunctionId = 70)
        INSERT INTO FunctionMaster (FunctionId, ChapterId, FunctionName, Url, Status) VALUES (70, 30, 'Scrap Entry', 'Transaction/ScrapEntry.aspx', 'Active');
    IF NOT EXISTS (SELECT 1 FROM FunctionMaster WHERE FunctionId = 71)
        INSERT INTO FunctionMaster (FunctionId, ChapterId, FunctionName, Url, Status) VALUES (71, 31, 'Scrap Purchase history list', 'Transaction/ScrapEntryList.aspx', 'Active');
    IF NOT EXISTS (SELECT 1 FROM FunctionMaster WHERE FunctionId = 72)
        INSERT INTO FunctionMaster (FunctionId, ChapterId, FunctionName, Url, Status) VALUES (72, 32, 'Scrap pricing config', 'Master/ScrapProductMaster.aspx', 'Active');
END
GO

-- 7. Assign User Access Rights (UserPolicies mapping)
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[UserPolicies]') AND type in (N'U'))
BEGIN
    -- Map Admin (User 1) and User 22624 (Parthi) access roles for new modules
    IF NOT EXISTS (SELECT 1 FROM UserPolicies WHERE UserId = 1 AND FunctionId = 68)
        INSERT INTO UserPolicies (UserId, FunctionId, ReadSession, EditSession, ApprovalSession, CreatedBy, CreatedAt) VALUES (1, 68, 'inline', 'inline', 'inline', 'system', GETDATE());
    IF NOT EXISTS (SELECT 1 FROM UserPolicies WHERE UserId = 1 AND FunctionId = 69)
        INSERT INTO UserPolicies (UserId, FunctionId, ReadSession, EditSession, ApprovalSession, CreatedBy, CreatedAt) VALUES (1, 69, 'inline', 'inline', 'inline', 'system', GETDATE());
    IF NOT EXISTS (SELECT 1 FROM UserPolicies WHERE UserId = 1 AND FunctionId = 70)
        INSERT INTO UserPolicies (UserId, FunctionId, ReadSession, EditSession, ApprovalSession, CreatedBy, CreatedAt) VALUES (1, 70, 'inline', 'inline', 'inline', 'system', GETDATE());
    IF NOT EXISTS (SELECT 1 FROM UserPolicies WHERE UserId = 1 AND FunctionId = 71)
        INSERT INTO UserPolicies (UserId, FunctionId, ReadSession, EditSession, ApprovalSession, CreatedBy, CreatedAt) VALUES (1, 71, 'inline', 'inline', 'inline', 'system', GETDATE());
    IF NOT EXISTS (SELECT 1 FROM UserPolicies WHERE UserId = 1 AND FunctionId = 72)
        INSERT INTO UserPolicies (UserId, FunctionId, ReadSession, EditSession, ApprovalSession, CreatedBy, CreatedAt) VALUES (1, 72, 'inline', 'inline', 'inline', 'system', GETDATE());

    IF NOT EXISTS (SELECT 1 FROM UserPolicies WHERE UserId = 22624 AND FunctionId = 68)
        INSERT INTO UserPolicies (UserId, FunctionId, ReadSession, EditSession, ApprovalSession, CreatedBy, CreatedAt) VALUES (22624, 68, 'inline', 'inline', 'inline', 'system', GETDATE());
    IF NOT EXISTS (SELECT 1 FROM UserPolicies WHERE UserId = 22624 AND FunctionId = 69)
        INSERT INTO UserPolicies (UserId, FunctionId, ReadSession, EditSession, ApprovalSession, CreatedBy, CreatedAt) VALUES (22624, 69, 'inline', 'inline', 'inline', 'system', GETDATE());
    IF NOT EXISTS (SELECT 1 FROM UserPolicies WHERE UserId = 22624 AND FunctionId = 70)
        INSERT INTO UserPolicies (UserId, FunctionId, ReadSession, EditSession, ApprovalSession, CreatedBy, CreatedAt) VALUES (22624, 70, 'inline', 'inline', 'inline', 'system', GETDATE());
    IF NOT EXISTS (SELECT 1 FROM UserPolicies WHERE UserId = 22624 AND FunctionId = 71)
        INSERT INTO UserPolicies (UserId, FunctionId, ReadSession, EditSession, ApprovalSession, CreatedBy, CreatedAt) VALUES (22624, 71, 'inline', 'inline', 'inline', 'system', GETDATE());
    IF NOT EXISTS (SELECT 1 FROM UserPolicies WHERE UserId = 22624 AND FunctionId = 72)
        INSERT INTO UserPolicies (UserId, FunctionId, ReadSession, EditSession, ApprovalSession, CreatedBy, CreatedAt) VALUES (22624, 72, 'inline', 'inline', 'inline', 'system', GETDATE());
END
GO

PRINT 'SQL Setup and Migration script executed successfully!';
GO
