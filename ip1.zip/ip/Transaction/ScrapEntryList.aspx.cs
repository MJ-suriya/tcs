using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;

public partial class Transaction_ScrapEntryList : System.Web.UI.Page
{
    public bool IsAdminUser
    {
        get
        {
            if (Session == null) return false;
            string category = Session["CategoryName"] != null ? Session["CategoryName"].ToString() : "";
            string username = Session["UserName"] != null ? Session["UserName"].ToString() : "";
            string editSession = Session["EditSession"] != null ? Session["EditSession"].ToString() : "none";
            string approvalSession = Session["ApprovalSession"] != null ? Session["ApprovalSession"].ToString() : "none";
            return category == "SA" || username == "ADMIN" || editSession == "inline" || approvalSession == "inline";
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null)
        {
            Response.Redirect("~/Login.aspx");
        }
    }

    private static string GetUsername()
    {
        return HttpContext.Current.Session["UserName"] != null ? HttpContext.Current.Session["UserName"].ToString() : "system";
    }

    private static string GetUserRole()
    {
        string editSession = HttpContext.Current.Session["EditSession"] != null ? HttpContext.Current.Session["EditSession"].ToString() : "none";
        string approvalSession = HttpContext.Current.Session["ApprovalSession"] != null ? HttpContext.Current.Session["ApprovalSession"].ToString() : "none";
        
        if (approvalSession == "inline")
        {
            if (HttpContext.Current.Session["UserName"] != null && HttpContext.Current.Session["UserName"].ToString().ToUpper() == "ADMIN") 
                return "admin";
            return "manager";
        }
        
        if (editSession == "inline")
        {
            return "pettycashier";
        }
        
        return "security";
    }

    [WebMethod(EnableSession = true)]
    public static object GetEntries(string status, string date)
    {
        string role = GetUserRole();
        string username = GetUsername();
        return clsScrapEntry.GetEntries(status, date, username, role);
    }

    [WebMethod(EnableSession = true)]
    public static object VerifyScrapEntry(string id, double verifiedAmount, string proofDocumentBase64, string proofDocumentFileName)
    {
        string editSession = HttpContext.Current.Session["EditSession"] != null ? HttpContext.Current.Session["EditSession"].ToString() : "none";
        string role = GetUserRole();
        if (editSession != "inline" && role != "admin")
        {
            return new { error = "Unauthorized verification permission. Must have Edit policy rights." };
        }
        string res = clsScrapEntry.VerifyScrapEntry(id, verifiedAmount, proofDocumentBase64, proofDocumentFileName);
        if (res == "success") return new { success = true };
        return new { error = res };
    }

    [WebMethod(EnableSession = true)]
    public static object ApproveEntry(string id)
    {
        string approvalSession = HttpContext.Current.Session["ApprovalSession"] != null ? HttpContext.Current.Session["ApprovalSession"].ToString() : "none";
        string role = GetUserRole();
        if (approvalSession != "inline" && role != "admin")
        {
            return new { error = "Unauthorized approval permission. Must have Approval policy rights." };
        }
        string res = clsScrapEntry.ApproveEntry(id, GetUsername(), role);
        if (res == "success") return new { success = true };
        return new { error = res };
    }

    [WebMethod(EnableSession = true)]
    public static object RejectEntry(string id, string reason)
    {
        string approvalSession = HttpContext.Current.Session["ApprovalSession"] != null ? HttpContext.Current.Session["ApprovalSession"].ToString() : "none";
        string role = GetUserRole();
        if (approvalSession != "inline" && role != "admin")
        {
            return new { error = "Unauthorized approval permission. Must have Approval policy rights." };
        }
        string res = clsScrapEntry.RejectEntry(id, reason, GetUsername(), role);
        if (res == "success") return new { success = true };
        return new { error = res };
    }

    [WebMethod(EnableSession = true)]
    public static object QueryEntry(string id, string question)
    {
        string approvalSession = HttpContext.Current.Session["ApprovalSession"] != null ? HttpContext.Current.Session["ApprovalSession"].ToString() : "none";
        string role = GetUserRole();
        if (approvalSession != "inline" && role != "admin")
        {
            return new { error = "Unauthorized permission to query entries. Must have Approval policy rights." };
        }
        string res = clsScrapEntry.QueryEntry(id, question);
        if (res == "success") return new { success = true };
        return new { error = res };
    }

    [WebMethod(EnableSession = true)]
    public static object AnswerEntryQuery(string id, string answer)
    {
        string res = clsScrapEntry.AnswerEntryQuery(id, answer);
        if (res == "success") return new { success = true };
        return new { error = res };
    }

    [WebMethod]
    public static object GetSystemSetting(string key)
    {
        return new { value = clsSystemSetting.GetSetting(key) };
    }

    [WebMethod(EnableSession = true)]
    public static object UpdateSystemSetting(string key, object value)
    {
        string editSession = HttpContext.Current.Session["EditSession"] != null ? HttpContext.Current.Session["EditSession"].ToString() : "none";
        string role = GetUserRole();
        if (editSession != "inline" && role != "admin")
        {
            return new { error = "Unauthorized settings update permission. Must have Edit policy rights." };
        }
        string res = clsSystemSetting.UpdateSetting(key, value);
        if (res == "success") return new { success = true };
        return new { error = res };
    }

    [WebMethod]
    public static object GetBranches()
    {
        return clsBranch.GetBranches();
    }
}
