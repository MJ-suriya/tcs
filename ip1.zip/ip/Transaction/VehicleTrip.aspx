<%@ Page Title="" Language="C#" MasterPageFile="~/General/Master.master" AutoEventWireup="true"
    CodeFile="VehicleTrip.aspx.cs" Inherits="Transaction_VehicleTrip" %>

    <asp:Content ID="Content1" ContentPlaceHolderID="ctnHead" runat="Server">
        <style>
            .baseline-card {
                background-color: #f4f6f9;
                border-left: 4px solid #3c8dbc;
                padding: 10px;
                margin-bottom: 15px;
                border-radius: 3px;
            }

            .baseline-title {
                font-weight: bold;
                color: #333;
                margin-bottom: 5px;
                text-transform: uppercase;
                font-size: 11px;
                letter-spacing: 0.5px;
            }

            .baseline-value {
                font-size: 16px;
                font-weight: bold;
                color: #00a65a;
            }

            .expense-row {
                margin-bottom: 5px;
                background: #fdfdfd;
                border: 1px solid #eee;
                padding: 8px;
                border-radius: 3px;
            }
        </style>
        <script class="text/javascript">
            var fuelPrices = { petrol: 0.0, diesel: 0.0 };
            var expensesList = [];

            window.onload = function () {
                initDateTimePickers();
                LoadVehicles();
                LoadFuelPrices();
                LoadBranches();
                LoadWaitingList();
            };

            function initDateTimePickers() {
                var now = new Date();
                var offset = now.getTimezoneOffset() * 60000;
                var localISOTime = new Date(now - offset).toISOString().slice(0, 16);
                $("#txt_StartDateTime").val(localISOTime);
                $("#txt_EndDateTime").val(localISOTime);
            }

            function LoadFuelPrices() {
                PageMethods.GetFuelPrices(function (prices) {
                    if (prices) fuelPrices = prices;
                });
            }

            function LoadBranches() {
                PageMethods.GetBranches(function (response) {
                    $("#cmb_Branch").html("<option value=''>System / Main</option>");
                    if (response && response.length > 0) {
                        $.each(response, function (key, val) {
                            $("#cmb_Branch").append("<option value='" + val.id + "'>" + val.name + "</option>");
                        });
                    }
                });
            }

            function LoadVehicles() {
                PageMethods.GetVehicles(function (response) {
                    $("#cmb_Vehicle").html("<option value=''>Select Vehicle</option>");
                    if (response && response.length > 0) {
                        $.each(response, function (key, val) {
                            $("#cmb_Vehicle").append("<option value='" + val.vehicleNumber + "'>" + val.vehicleNumber + " (" + val.shortName + ")</option>");
                        });
                    }
                });
            }

            function onVehicleChange() {
                var vNum = $("#cmb_Vehicle").val();
                if (!vNum) {
                    clearBaseline();
                    return;
                }
                $("#baseline_loading").show();
                PageMethods.GetVehicleBaseline(vNum, function (baseline) {
                    $("#baseline_loading").hide();
                    if (baseline) {
                        $("#lbl_StartKm").text(baseline.startKm);
                        $("#lbl_AvailableFuel").text(baseline.availableFuel.toFixed(2) + " L");
                        $("#lbl_ExpectedMileage").text(baseline.expectedMileage ? (baseline.expectedMileage.toFixed(2) + " Km/L") : "N/A");
                        $("#hf_StartKm").val(baseline.startKm);
                        $("#hf_AvailableFuel").val(baseline.availableFuel);
                        $("#hf_TankCapacity").val(baseline.tankCapacity);
                        $("#txt_EndKm").attr("min", baseline.startKm);
                    }
                });
            }

            function clearBaseline() {
                $("#lbl_StartKm").text("0");
                $("#lbl_AvailableFuel").text("0 L");
                $("#lbl_ExpectedMileage").text("N/A");
                $("#hf_StartKm").val("0");
                $("#hf_AvailableFuel").val("0");
                $("#hf_TankCapacity").val("0");
            }

            function onDriverChange() {
                var driver = $("#txt_DriverName").val().trim().toLowerCase();
                if (driver === 'fuel log') {
                    $("#txt_FromLocation").val("GATE").attr("disabled", true);
                    $("#txt_ToLocation").val("FUEL STATION").attr("disabled", true);
                    $("#div_RemainingFuel").hide();
                    $("#div_FuelDetails").show();
                } else {
                    $("#txt_FromLocation").val("").attr("disabled", false);
                    $("#txt_ToLocation").val("").attr("disabled", false);
                    $("#div_RemainingFuel").hide();
                    $("#div_FuelDetails").hide();
                }
            }

            function addExpense() {
                var type = $("#cmb_ExpType").val();
                var amt = parseFloat($("#txt_ExpAmount").val());
                var desc = $("#txt_ExpDesc").val().trim();

                if (!type) {
                    swal("Attention", "Select expense type", "warning");
                    return;
                }
                if (isNaN(amt) || amt <= 0) {
                    swal("Attention", "Enter a valid amount", "warning");
                    return;
                }

                expensesList.push({
                    expenseType: type,
                    amount: amt,
                    date: new Date().toISOString(),
                    description: desc
                });

                renderExpenses();
                $("#txt_ExpAmount").val("");
                $("#txt_ExpDesc").val("");
            }

            function removeExpense(idx) {
                expensesList.splice(idx, 1);
                renderExpenses();
            }

            function renderExpenses() {
                $("#div_ExpensesList").html("");
                if (expensesList.length === 0) {
                    $("#div_ExpensesList").html("<p class='text-muted small'>No expenses added yet.</p>");
                    return;
                }
                $.each(expensesList, function (idx, exp) {
                    var itemHtml = '<div class="expense-row d-flex justify-content-between align-items-center">'
                        + '<div>'
                        + '<strong class="text-uppercase">' + exp.expenseType + '</strong>: Rs ' + exp.amount.toFixed(2)
                        + (exp.description ? (' <span class="text-muted small">(' + exp.description + ')</span>') : '')
                        + '</div>'
                        + '<div><button type="button" class="btn btn-danger btn-xs" onclick="removeExpense(' + idx + ')"><i class="fa fa-remove"></i></button></div>'
                        + '</div>';
                    $("#div_ExpensesList").append(itemHtml);
                });
            }

            function saveLog() {
                $("#btn_Save").attr("disabled", true);

                var driver = $("#txt_DriverName").val().trim();
                var vNum = $("#cmb_Vehicle").val();
                var fromLoc = $("#txt_FromLocation").val().trim();
                var toLoc = $("#txt_ToLocation").val().trim();
                var startDt = $("#txt_StartDateTime").val();
                var endDt = $("#txt_EndDateTime").val();
                var endKm = parseFloat($("#txt_EndKm").val());
                var fuelAdded = parseFloat($("#txt_FuelAdded").val()) || 0;
                var remainingFuel = $("#txt_RemainingFuel").val().trim() !== "" ? parseFloat($("#txt_RemainingFuel").val()) : null;

                var fuelType = $("#cmb_FuelType").val();
                var pricePerL = parseFloat($("#txt_PricePerLitre").val()) || null;
                var milReason = $("#txt_MileageReason").val().trim();

                var branchId = $("#cmb_Branch").val();
                var branchName = branchId ? $("#cmb_Branch option:selected").text() : "";

                if (!driver || !vNum || !fromLoc || !toLoc || !startDt || isNaN(endKm)) {
                    swal("Attention", "Please fill in all mandatory fields (*)", "warning");
                    $("#btn_Save").attr("disabled", false);
                    return;
                }

                var draftId = $("#hf_DraftId").val();

                PageMethods.CreateVehicleLog(
                    driver, vNum, fromLoc, toLoc, startDt, endDt, endKm, fuelAdded, remainingFuel,
                    fuelType, pricePerL, milReason, branchId, branchName, expensesList, "", draftId,
                    function (response) {
                        if (response.error) {
                            swal("Error", response.error, "error");
                            $("#btn_Save").attr("disabled", false);
                        } else {
                            swal("Success", "Trip Log submitted successfully!", "success");
                            clearForm();
                            LoadWaitingList();
                        }
                    }
                );
            }

            function saveDraft() {
                var driver = $("#txt_DriverName").val().trim();
                var vNum = $("#cmb_Vehicle").val();
                var fromLoc = $("#txt_FromLocation").val().trim();
                var toLoc = $("#txt_ToLocation").val().trim();
                var startDt = $("#txt_StartDateTime").val();
                var endDt = $("#txt_EndDateTime").val();
                var endKm = $("#txt_EndKm").val().trim() !== "" ? parseFloat($("#txt_EndKm").val()) : null;
                var fuelAdded = parseFloat($("#txt_FuelAdded").val()) || 0;
                var remainingFuel = $("#txt_RemainingFuel").val().trim() !== "" ? parseFloat($("#txt_RemainingFuel").val()) : null;

                var fuelType = $("#cmb_FuelType").val();
                var pricePerL = parseFloat($("#txt_PricePerLitre").val()) || null;

                var branchId = $("#cmb_Branch").val();
                var branchName = branchId ? $("#cmb_Branch option:selected").text() : "";

                var draftId = $("#hf_DraftId").val();

                PageMethods.SaveDraft(
                    draftId, driver, vNum, fromLoc, toLoc, startDt, endDt, endKm, fuelAdded, remainingFuel,
                    fuelType, pricePerL, branchId, branchName, expensesList, "",
                    function (response) {
                        if (response.error) {
                            swal("Error", response.error, "error");
                        } else {
                            swal("Success", "Draft saved in Waiting List!", "success");
                            clearForm();
                            LoadWaitingList();
                        }
                    }
                );
            }

            function LoadWaitingList() {
                PageMethods.GetWaitingList(function (response) {
                    $("#tbl_bdy_Waiting").html("");
                    if (response && response.length > 0) {
                        $.each(response, function (key, val) {
                            var start = val.startDateTime ? new Date(val.startDateTime).toLocaleString() : '—';
                            var row = '<tr>'
                                + '<td>' + val.driverName + '</td>'
                                + '<td>' + val.vehicleNumber + '</td>'
                                + '<td>' + val.fromLocation + ' &rarr; ' + val.toLocation + '</td>'
                                + '<td>' + start + '</td>'
                                + '<td>'
                                + '<button type="button" class="btn btn-default btn-xs" onclick="loadDraft(\'' + val.id + '\')"><i class="fa fa-pencil"></i> Edit</button>'
                                + '<button type="button" class="btn btn-danger btn-xs" onclick="deleteDraft(\'' + val.id + '\')"><i class="fa fa-trash"></i></button>'
                                + '</td>'
                                + '</tr>';
                            $("#tbl_bdy_Waiting").append(row);
                        });
                        $("#div_WaitingCard").show();
                    } else {
                        $("#div_WaitingCard").hide();
                    }
                });
            }

            function loadDraft(id) {
                PageMethods.GetWaitingList(function (response) {
                    var draft = null;
                    $.each(response, function (key, val) {
                        if (val.id === id) {
                            draft = val;
                            return false;
                        }
                    });
                    if (draft) {
                        $("#hf_DraftId").val(draft.id);
                        $("#txt_DriverName").val(draft.driverName);
                        onDriverChange();
                        $("#cmb_Vehicle").val(draft.vehicleNumber);
                        onVehicleChange();
                        $("#txt_FromLocation").val(draft.fromLocation);
                        $("#txt_ToLocation").val(draft.toLocation);

                        if (draft.startDateTime) {
                            var sDt = new Date(draft.startDateTime);
                            var sOffset = sDt.getTimezoneOffset() * 60000;
                            $("#txt_StartDateTime").val(new Date(sDt - sOffset).toISOString().slice(0, 16));
                        }
                        if (draft.endDateTime) {
                            var eDt = new Date(draft.endDateTime);
                            var eOffset = eDt.getTimezoneOffset() * 60000;
                            $("#txt_EndDateTime").val(new Date(eDt - eOffset).toISOString().slice(0, 16));
                        }

                        $("#txt_EndKm").val(draft.endKm || "");
                        $("#txt_FuelAdded").val(draft.fuelAdded || 0);
                        $("#txt_RemainingFuel").val(draft.remainingFuel || "");
                        $("#cmb_FuelType").val(draft.fuelType || "diesel");
                        $("#txt_PricePerLitre").val(draft.pricePerLitre || "");
                        $("#cmb_Branch").val(draft.branch || "");

                        expensesList = [];
                        if (draft.expenses && draft.expenses.length > 0) {
                            $.each(draft.expenses, function (k, v) {
                                expensesList.push(v);
                            });
                        }
                        renderExpenses();
                        swal("Loaded", "Draft loaded for editing.", "info");
                    }
                });
            }

            function deleteDraft(id) {
                swal({
                    title: "Are you sure?",
                    text: "Delete this draft?",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                }).then(function (willDelete) {
                    if (willDelete) {
                        PageMethods.DeleteDraft(id, function (res) {
                            if (res.error) swal("Error", res.error, "error");
                            else {
                                swal("Deleted", "Draft deleted", "success");
                                LoadWaitingList();
                            }
                        });
                    }
                });
            }

            function clearForm() {
                $("#hf_DraftId").val("");
                $("#txt_DriverName").val("");
                onDriverChange();
                $("#cmb_Vehicle").val("");
                clearBaseline();
                $("#txt_FromLocation").val("");
                $("#txt_ToLocation").val("");
                initDateTimePickers();
                $("#txt_EndKm").val("");
                $("#txt_FuelAdded").val("0");
                $("#txt_RemainingFuel").val("");
                $("#cmb_FuelType").val("diesel");
                $("#txt_PricePerLitre").val("");
                $("#cmb_Branch").val("");
                $("#txt_MileageReason").val("");
                expensesList = [];
                renderExpenses();
                $("#btn_Save").attr("disabled", false);
            }

            function onFuelTypeChange() {
                var type = $("#cmb_FuelType").val();
                if (type && fuelPrices[type]) {
                    $("#txt_PricePerLitre").val(fuelPrices[type].toFixed(2));
                }
            }
        </script>
    </asp:Content>

    <asp:Content ID="Content2" ContentPlaceHolderID="ctnForm" runat="Server">
        <input type="hidden" id="hf_DraftId" />
        <input type="hidden" id="hf_StartKm" />
        <input type="hidden" id="hf_AvailableFuel" />
        <input type="hidden" id="hf_TankCapacity" />

        <div class="content-wrapper">
            <section class="content-header">
                <h1>Vehicle Trip Entry
                    <small>Driver Log Book</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="../General/Dashboard.aspx"><i class="fa fa-dashboard"></i>Home</a></li>
                    <li class="active">Trip Entry</li>
                </ol>
            </section>

            <section class="content">
                <div class="row">
                    <!-- Form column -->
                    <div class="col-md-8">
                        <div class="box box-primary">
                            <div class="box-body">
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="txt_DriverName">Driver Name *</label>
                                        <input type="text" id="txt_DriverName" class="form-control"
                                            placeholder="e.g. Parthiban (or 'fuel log')" onkeyup="onDriverChange()" />
                                        <p class="help-block small">Type 'fuel log' to enter a fuel refill baseline
                                            record.</p>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="cmb_Vehicle">Select Vehicle *</label>
                                        <select id="cmb_Vehicle" class="form-control"
                                            onchange="onVehicleChange()"></select>
                                    </div>
                                </div>

                                <!-- Vehicle baselines -->
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="baseline-card">
                                            <span id="baseline_loading" style="display:none;"
                                                class="pull-right text-muted small"><i
                                                    class="fa fa-refresh fa-spin"></i> Fetching...</span>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="baseline-title">Starting KM</div>
                                                    <div class="baseline-value" id="lbl_StartKm">0</div>
                                                </div>
                                                <div class="col-md-4" style="display:none;">
                                                    <div class="baseline-title">Est. Available Fuel</div>
                                                    <div class="baseline-value" id="lbl_AvailableFuel">0 L</div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="baseline-title">Expected Mileage</div>
                                                    <div class="baseline-value" id="lbl_ExpectedMileage">N/A</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="txt_FromLocation">From Location *</label>
                                        <input type="text" id="txt_FromLocation" class="form-control text-uppercase"
                                            placeholder="e.g. ADMIN OFFICE" />
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="txt_ToLocation">ToLocation *</label>
                                        <input type="text" id="txt_ToLocation" class="form-control text-uppercase"
                                            placeholder="e.g. FACTORY GATE 1" />
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="txt_StartDateTime">Start Date & Time *</label>
                                        <input type="datetime-local" id="txt_StartDateTime" class="form-control" />
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="txt_EndDateTime">End Date & Time</label>
                                        <input type="datetime-local" id="txt_EndDateTime" class="form-control" />
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="txt_EndKm">End Odometer KM *</label>
                                        <input type="number" id="txt_EndKm" class="form-control"
                                            placeholder="Odometer Check-in Reading" />
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="txt_FuelAdded">Fuel Added (Litres)</label>
                                        <input type="number" step="0.01" id="txt_FuelAdded" class="form-control"
                                            value="0" />
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-6" id="div_RemainingFuel" style="display:none;">
                                        <label for="txt_RemainingFuel">Remaining Fuel (Litres)</label>
                                        <input type="number" step="0.1" id="txt_RemainingFuel" class="form-control"
                                            placeholder="Remaining fuel in tank" />
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="cmb_Branch">Reporting Branch Location</label>
                                        <select id="cmb_Branch" class="form-control"></select>
                                    </div>
                                </div>

                                <!-- Fuel details section if adding fuel -->
                                <div id="div_FuelDetails" style="display:none;" class="row">
                                    <div class="form-group col-md-6">
                                        <label for="cmb_FuelType">Fuel Type</label>
                                        <select id="cmb_FuelType" class="form-control" onchange="onFuelTypeChange()">
                                            <option value="diesel">Diesel</option>
                                            <option value="petrol">Petrol</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="txt_PricePerLitre">Price per Litre (Rs)</label>
                                        <input type="number" step="0.01" id="txt_PricePerLitre" class="form-control" />
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <label for="txt_MileageReason">Odometer / Mileage Variance Reason</label>
                                        <textarea id="txt_MileageReason" class="form-control" rows="2"
                                            placeholder="Explain odometer variance or low mileage reasons if applicable..."></textarea>
                                    </div>
                                </div>

                                <!-- Expenses Form -->
                                <div class="box box-solid box-default" style="margin-top: 15px;">
                                    <div class="box-header with-border">
                                        <h4 class="box-title">Trip Expenses / Purchases</h4>
                                    </div>
                                    <div class="box-body">
                                        <div class="row">
                                            <div class="form-group col-md-3">
                                                <select id="cmb_ExpType" class="form-control">
                                                    <option value="">Select Type</option>
                                                    <option value="toll">Toll</option>
                                                    <option value="parking">Parking</option>
                                                    <option value="permit">Permit</option>
                                                    <option value="maintenance">Maintenance</option>
                                                    <option value="petrol">Petrol</option>
                                                    <option value="diesel">Diesel</option>
                                                    <option value="other">Other Expense</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-3">
                                                <input type="number" step="0.01" id="txt_ExpAmount" class="form-control"
                                                    placeholder="Amount (Rs)" />
                                            </div>
                                            <div class="form-group col-md-4">
                                                <input type="text" id="txt_ExpDesc" class="form-control"
                                                    placeholder="Expense note..." />
                                            </div>
                                            <div class="form-group col-md-2">
                                                <button type="button" class="btn btn-info btn-block"
                                                    onclick="addExpense()"><i class="fa fa-plus"></i> Add</button>
                                            </div>
                                        </div>
                                        <div id="div_ExpensesList" style="margin-top:10px;">
                                            <p class="text-muted small">No expenses added yet.</p>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="box-footer">
                                <button type="button" class="btn btn-default" onclick="clearForm()">Reset Form</button>
                                <button type="button" class="btn btn-warning" onclick="saveDraft()">Save to Waiting
                                    List</button>
                                <button type="button" id="btn_Save" class="btn btn-primary pull-right"
                                    onclick="saveLog()">Submit Log Book</button>
                            </div>
                        </div>
                    </div>

                    <!-- Right Waiting List Column -->
                    <div class="col-md-4" id="div_WaitingCard" style="display:none;">
                        <div class="box box-warning">
                            <div class="box-header with-border">
                                <h3 class="box-title">Waiting List Drafts</h3>
                            </div>
                            <div class="box-body no-padding" style="max-height: 500px; overflow-y: auto;">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Driver</th>
                                            <th>Vehicle</th>
                                            <th>Route</th>
                                            <th>Start Date</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody id="tbl_bdy_Waiting"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </asp:Content>