using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.Services;

public partial class Transaction_VehicleTrip : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null)
        {
            Response.Redirect("~/Login.aspx");
        }
    }

    private static string GetUsername()
    {
        return HttpContext.Current.Session["UserName"] != null ? HttpContext.Current.Session["UserName"].ToString() : "system";
    }

    [WebMethod]
    public static object GetVehicles()
    {
        return clsVehicleProfile.GetVehicles();
    }

    [WebMethod]
    public static object GetVehicleBaseline(string vehicleNumber)
    {
        return clsVehicleLog.GetVehicleBaseline(vehicleNumber);
    }

    [WebMethod(EnableSession = true)]
    public static object CreateVehicleLog(
        string driverName, string vehicleNumber, string fromLocation, string toLocation,
        string startDateTime, string endDateTime, double? endKm, double? fuelAdded, double? remainingFuel,
        string fuelType, double? pricePerLitre, string mileageReason, string branch, string branchName,
        List<clsVehicleLog.ExpenseInput> expenses, string correctedFromLogId, string draftId)
    {
        try
        {
            DateTime startDt;
            if (!clsDatabase.TryParseDate(startDateTime, out startDt))
            {
                return new { error = "Invalid start date format" };
            }
            DateTime? finalEndDt = null;
            if (!string.IsNullOrEmpty(endDateTime))
            {
                DateTime parsedEnd;
                if (clsDatabase.TryParseDate(endDateTime, out parsedEnd))
                {
                    finalEndDt = parsedEnd;
                }
            }

            string res = clsVehicleLog.CreateVehicleLog(
                driverName, vehicleNumber, fromLocation, toLocation, startDt, finalEndDt,
                endKm ?? 0.0, fuelAdded ?? 0.0, remainingFuel, fuelType, pricePerLitre, mileageReason,
                branch, branchName, expenses, correctedFromLogId, GetUsername(), string.IsNullOrEmpty(draftId) ? null : draftId
            );

            if (res.StartsWith("success:"))
            {
                string logId = res.Substring("success:".Length);
                var log = clsVehicleLog.GetLogById(logId);
                return new { success = true, log = log };
            }
            return new { error = res };
        }
        catch (Exception ex)
        {
            return new { error = ex.Message };
        }
    }

    [WebMethod(EnableSession = true)]
    public static object GetWaitingList()
    {
        return clsVehicleLog.GetWaitingList(GetUsername());
    }

    [WebMethod(EnableSession = true)]
    public static object SaveDraft(
        string draftId, string driverName, string vehicleNumber, string fromLocation, string toLocation,
        string startDateTime, string endDateTime, double? endKm, double? fuelAdded, double? remainingFuel,
        string fuelType, double? pricePerLitre, string branch, string branchName,
        List<clsVehicleLog.ExpenseInput> expenses, string correctedFromLogId)
    {
        DateTime? startDt = null;
        if (!string.IsNullOrEmpty(startDateTime))
        {
            DateTime parsedStart;
            if (clsDatabase.TryParseDate(startDateTime, out parsedStart))
            {
                startDt = parsedStart;
            }
        }

        DateTime? endDt = null;
        if (!string.IsNullOrEmpty(endDateTime))
        {
            DateTime parsedEnd;
            if (clsDatabase.TryParseDate(endDateTime, out parsedEnd))
            {
                endDt = parsedEnd;
            }
        }

        string res = clsVehicleLog.SaveDraft(
            draftId, driverName, vehicleNumber, fromLocation, toLocation,
            startDt, endDt, endKm, fuelAdded ?? 0.0, remainingFuel,
            fuelType, pricePerLitre, branch, branchName, expenses, correctedFromLogId, GetUsername()
        );

        if (res == "success") return new { success = true };
        return new { error = res };
    }

    [WebMethod(EnableSession = true)]
    public static object DeleteDraft(string id)
    {
        string res = clsVehicleLog.DeleteDraft(id, GetUsername());
        if (res == "success") return new { success = true };
        return new { error = res };
    }

    [WebMethod(EnableSession = true)]
    public static object SubmitDraft(string id)
    {
        string res = clsVehicleLog.SubmitDraft(id, GetUsername());
        if (res.StartsWith("success:"))
        {
            return new { success = true };
        }
        return new { error = res };
    }

    [WebMethod]
    public static object GetFuelPrices()
    {
        var dt = clsDatabase.GetDataTable("SELECT FuelType, PricePerLitre FROM FuelPrices");
        var result = new Dictionary<string, double>();
        foreach (DataRow row in dt.Rows)
        {
            result[row["FuelType"].ToString().ToLower()] = Convert.ToDouble(row["PricePerLitre"]);
        }
        return result;
    }

    [WebMethod]
    public static object GetBranches()
    {
        return clsBranch.GetBranches();
    }
}
