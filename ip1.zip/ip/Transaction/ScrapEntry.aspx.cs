using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;

public partial class Transaction_ScrapEntry : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null)
        {
            Response.Redirect("~/Login.aspx");
        }
    }

    private static string GetUsername()
    {
        return HttpContext.Current.Session["UserName"] != null ? HttpContext.Current.Session["UserName"].ToString() : "system";
    }

    private static string GetUserRole()
    {
        string editSession = HttpContext.Current.Session["EditSession"] != null ? HttpContext.Current.Session["EditSession"].ToString() : "none";
        string approvalSession = HttpContext.Current.Session["ApprovalSession"] != null ? HttpContext.Current.Session["ApprovalSession"].ToString() : "none";
        
        if (approvalSession == "inline")
        {
            if (HttpContext.Current.Session["UserName"] != null && HttpContext.Current.Session["UserName"].ToString().ToUpper() == "ADMIN") 
                return "admin";
            return "manager";
        }
        
        if (editSession == "inline")
        {
            return "pettycashier";
        }
        
        return "security";
    }

    [WebMethod]
    public static object GetProducts()
    {
        return clsScrapProduct.GetProducts();
    }

    [WebMethod]
    public static object GetBranches()
    {
        return clsBranch.GetBranches();
    }

    [WebMethod]
    public static bool GetBranchManualWeightSetting(string branchId)
    {
        if (string.IsNullOrEmpty(branchId)) return true;
        string key = "ManualWeight_Branch_" + branchId;
        object val = clsSystemSetting.GetSetting(key);
        return val == null || Convert.ToBoolean(val);
    }

    [WebMethod(EnableSession = true)]
    public static object GetEntries(string status, string date)
    {
        string role = GetUserRole();
        string username = GetUsername();
        return clsScrapEntry.GetEntries(status, date, username, role);
    }

    [WebMethod(EnableSession = true)]
    public static object VerifyScrapEntry(string id, double verifiedAmount, string proofDocumentBase64, string proofDocumentFileName)
    {
        string editSession = HttpContext.Current.Session["EditSession"] != null ? HttpContext.Current.Session["EditSession"].ToString() : "none";
        string role = GetUserRole();
        if (editSession != "inline" && role != "admin")
        {
            return new { error = "Unauthorized verification permission. Must have Edit policy rights." };
        }
        string res = clsScrapEntry.VerifyScrapEntry(id, verifiedAmount, proofDocumentBase64, proofDocumentFileName);
        if (res == "success") return new { success = true };
        return new { error = res };
    }

    [WebMethod(EnableSession = true)]
    public static object ApproveEntry(string id)
    {
        string approvalSession = HttpContext.Current.Session["ApprovalSession"] != null ? HttpContext.Current.Session["ApprovalSession"].ToString() : "none";
        string role = GetUserRole();
        if (approvalSession != "inline" && role != "admin")
        {
            return new { error = "Unauthorized approval permission. Must have Approval policy rights." };
        }
        string res = clsScrapEntry.ApproveEntry(id, GetUsername(), role);
        if (res == "success") return new { success = true };
        return new { error = res };
    }

    [WebMethod(EnableSession = true)]
    public static object RejectEntry(string id, string reason)
    {
        string approvalSession = HttpContext.Current.Session["ApprovalSession"] != null ? HttpContext.Current.Session["ApprovalSession"].ToString() : "none";
        string role = GetUserRole();
        if (approvalSession != "inline" && role != "admin")
        {
            return new { error = "Unauthorized approval permission. Must have Approval policy rights." };
        }
        string res = clsScrapEntry.RejectEntry(id, reason, GetUsername(), role);
        if (res == "success") return new { success = true };
        return new { error = res };
    }

    [WebMethod(EnableSession = true)]
    public static object QueryEntry(string id, string question)
    {
        string approvalSession = HttpContext.Current.Session["ApprovalSession"] != null ? HttpContext.Current.Session["ApprovalSession"].ToString() : "none";
        string role = GetUserRole();
        if (approvalSession != "inline" && role != "admin")
        {
            return new { error = "Unauthorized permission to query entries. Must have Approval policy rights." };
        }
        string res = clsScrapEntry.QueryEntry(id, question);
        if (res == "success") return new { success = true };
        return new { error = res };
    }

    [WebMethod(EnableSession = true)]
    public static object CreateScrapEntry(
        string companyName, string vehicleNumber, string ownerName, string branch, string branchName,
        string dateTime, string description, string itemsJson, string proofDocumentBase64, string proofDocumentFileName)
    {
        string role = GetUserRole();
        string username = GetUsername();

        string res = clsScrapEntry.CreateScrapEntry(
            companyName, vehicleNumber, ownerName, branch, branchName,
            dateTime, description, itemsJson, proofDocumentBase64, proofDocumentFileName, username, role
        );

        if (res.StartsWith("success:"))
        {
            return new { success = true, id = res.Substring("success:".Length) };
        }
        return new { error = res };
    }
}
