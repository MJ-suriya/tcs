using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

public class clsVehicleExpense
{
    public static string CreateExpense(string vehicleNumber, string expenseType, double amount, DateTime date, string description, string username)
    {
        if (string.IsNullOrWhiteSpace(vehicleNumber) || string.IsNullOrWhiteSpace(expenseType) || date == default(DateTime))
        {
            return "Vehicle number, expense type, amount, and date are required";
        }

        if (amount < 0)
        {
            return "Amount must be a non-negative number";
        }

        string newId = Guid.NewGuid().ToString();

        clsDatabase.ExecuteNonQuery(
            "INSERT INTO VehicleExpenses (Id, VehicleNumber, ExpenseType, Amount, Date, Description, Status, RejectReason, QueryQuestion, QueryAnswer, CreatedBy, CreatedAt) " +
            "VALUES (@Id, @VehicleNumber, @ExpenseType, @Amount, @Date, @Description, @Status, @RejectReason, @QueryQuestion, @QueryAnswer, @CreatedBy, @CreatedAt)",
            new SqlParameter("@Id", newId),
            new SqlParameter("@VehicleNumber", vehicleNumber.Trim().ToUpperInvariant()),
            new SqlParameter("@ExpenseType", expenseType.Trim().ToLowerInvariant()),
            new SqlParameter("@Amount", amount),
            new SqlParameter("@Date", date),
            new SqlParameter("@Description", description != null ? description.Trim() : ""),
            new SqlParameter("@Status", "pending"),
            new SqlParameter("@RejectReason", ""),
            new SqlParameter("@QueryQuestion", ""),
            new SqlParameter("@QueryAnswer", ""),
            new SqlParameter("@CreatedBy", username ?? "system"),
            new SqlParameter("@CreatedAt", DateTime.UtcNow)
        );

        return "success:" + newId;
    }

    public static List<object> GetExpenses(string vehicleNumber)
    {
        DataTable dt;
        if (!string.IsNullOrEmpty(vehicleNumber))
        {
            var alternativeList = clsVehicleProfile.GetAlternativeVehicleNumbers(vehicleNumber);
            string listClause = string.Join("','", alternativeList.ToArray());
            dt = clsDatabase.GetDataTable(
                string.Format("SELECT Id, VehicleNumber, ExpenseType, Amount, Date, Description, Status, RejectReason, QueryQuestion, QueryAnswer, CreatedBy, CreatedAt, ReviewedBy, ReviewedAt FROM VehicleExpenses WHERE VehicleNumber IN ('{0}') ORDER BY Date DESC, CreatedAt DESC", listClause)
            );
        }
        else
        {
            dt = clsDatabase.GetDataTable("SELECT Id, VehicleNumber, ExpenseType, Amount, Date, Description, Status, RejectReason, QueryQuestion, QueryAnswer, CreatedBy, CreatedAt, ReviewedBy, ReviewedAt FROM VehicleExpenses ORDER BY Date DESC, CreatedAt DESC");
        }

        var list = new List<object>();
        foreach (DataRow row in dt.Rows)
        {
            list.Add(new
            {
                _id = row["Id"].ToString(),
                id = row["Id"].ToString(),
                vehicleNumber = row["VehicleNumber"].ToString(),
                expenseType = row["ExpenseType"].ToString(),
                amount = Convert.ToDouble(row["Amount"]),
                date = Convert.ToDateTime(row["Date"]),
                description = row["Description"].ToString(),
                status = row["Status"].ToString(),
                rejectReason = row["RejectReason"].ToString(),
                queryQuestion = row["QueryQuestion"].ToString(),
                queryAnswer = row["QueryAnswer"].ToString(),
                createdBy = row["CreatedBy"].ToString(),
                createdAt = Convert.ToDateTime(row["CreatedAt"]),
                reviewedBy = row["ReviewedBy"] == DBNull.Value ? null : row["ReviewedBy"].ToString(),
                reviewedAt = row["ReviewedAt"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(row["ReviewedAt"])
            });
        }
        return list;
    }

    public static string DeleteExpense(string id)
    {
        int rows = clsDatabase.ExecuteNonQuery("DELETE FROM VehicleExpenses WHERE Id = @Id", new SqlParameter("@Id", id));
        if (rows == 0) return "Expense not found";
        return "success";
    }

    public static string ReviewExpense(string id, string action, string reason, string username)
    {
        var allowedActions = new List<string> { "approve", "reject", "query", "resolve" };
        var act = action.Trim().ToLowerInvariant();
        if (!allowedActions.Contains(act)) return "Invalid action";

        var dt = clsDatabase.GetDataTable("SELECT Status FROM VehicleExpenses WHERE Id = @Id", new SqlParameter("@Id", id));
        if (dt.Rows.Count == 0) return "Vehicle expense not found";

        string status = "pending";
        string rejectReason = "";
        string queryQuestion = "";
        string queryAnswer = "";

        if (act == "reject")
        {
            if (string.IsNullOrWhiteSpace(reason)) return "Rejection reason is required";
            status = "rejected";
            rejectReason = reason.Trim();
        }
        else if (act == "approve")
        {
            status = "approved";
            rejectReason = "";
        }
        else if (act == "query")
        {
            if (string.IsNullOrWhiteSpace(reason)) return "Query question is required";
            status = "queried";
            queryQuestion = reason.Trim();
            queryAnswer = ""; // reset answer
        }
        else if (act == "resolve")
        {
            status = "approved";
        }

        clsDatabase.ExecuteNonQuery(
            "UPDATE VehicleExpenses SET Status = @Status, RejectReason = @RejectReason, QueryQuestion = @QueryQuestion, QueryAnswer = @QueryAnswer, ReviewedBy = @ReviewedBy, ReviewedAt = @ReviewedAt WHERE Id = @Id",
            new SqlParameter("@Status", status),
            new SqlParameter("@RejectReason", rejectReason),
            new SqlParameter("@QueryQuestion", queryQuestion),
            new SqlParameter("@QueryAnswer", queryAnswer),
            new SqlParameter("@ReviewedBy", username ?? "system"),
            new SqlParameter("@ReviewedAt", DateTime.UtcNow),
            new SqlParameter("@Id", id)
        );

        return "success";
    }

    public static string AnswerQuery(string id, string answer)
    {
        if (string.IsNullOrWhiteSpace(answer)) return "Answer is required";

        var dt = clsDatabase.GetDataTable("SELECT Status FROM VehicleExpenses WHERE Id = @Id", new SqlParameter("@Id", id));
        if (dt.Rows.Count == 0) return "Vehicle expense not found";

        string status = dt.Rows[0]["Status"].ToString();
        if (status != "queried") return "Expense is not in queried status";

        clsDatabase.ExecuteNonQuery(
            "UPDATE VehicleExpenses SET Status = @Status, QueryAnswer = @QueryAnswer WHERE Id = @Id",
            new SqlParameter("@Status", "answered"),
            new SqlParameter("@QueryAnswer", answer.Trim()),
            new SqlParameter("@Id", id)
        );

        return "success";
    }
}
