using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

public class clsScrapProduct
{
    public static List<object> GetProducts()
    {
        var dt = clsDatabase.GetDataTable("SELECT Id, Name, PricePerKg, CreatedBy, CreatedAt, UpdatedAt FROM ScrapProducts ORDER BY Name");
        var list = new List<object>();
        foreach (DataRow row in dt.Rows)
        {
            list.Add(new
            {
                _id = row["Id"].ToString(),
                id = row["Id"].ToString(),
                name = row["Name"].ToString(),
                pricePerKg = Convert.ToDouble(row["PricePerKg"]),
                createdBy = row["CreatedBy"] == DBNull.Value ? "" : row["CreatedBy"].ToString(),
                createdAt = Convert.ToDateTime(row["CreatedAt"]),
                updatedAt = Convert.ToDateTime(row["UpdatedAt"])
            });
        }
        return list;
    }

    public static string CreateProduct(string name, double pricePerKg, string username)
    {
        var nameTrim = name.Trim();
        if (string.IsNullOrEmpty(nameTrim)) return "Name is required";

        var count = (int)clsDatabase.ExecuteScalar("SELECT COUNT(*) FROM ScrapProducts WHERE LOWER(Name) = LOWER(@Name)", 
            new SqlParameter("@Name", nameTrim));
        if (count > 0) return "Product name already exists";

        string id = Guid.NewGuid().ToString();
        clsDatabase.ExecuteNonQuery(
            "INSERT INTO ScrapProducts (Id, Name, PricePerKg, CreatedBy, CreatedAt, UpdatedAt) VALUES (@Id, @Name, @PricePerKg, @CreatedBy, @CreatedAt, @UpdatedAt)",
            new SqlParameter("@Id", id),
            new SqlParameter("@Name", nameTrim),
            new SqlParameter("@PricePerKg", pricePerKg),
            new SqlParameter("@CreatedBy", username ?? "system"),
            new SqlParameter("@CreatedAt", DateTime.UtcNow),
            new SqlParameter("@UpdatedAt", DateTime.UtcNow)
        );

        return "success:" + id;
    }

    public static string UpdateProductPrice(string id, double pricePerKg)
    {
        int rows = clsDatabase.ExecuteNonQuery(
            "UPDATE ScrapProducts SET PricePerKg = @PricePerKg, UpdatedAt = @UpdatedAt WHERE Id = @Id",
            new SqlParameter("@PricePerKg", pricePerKg),
            new SqlParameter("@UpdatedAt", DateTime.UtcNow),
            new SqlParameter("@Id", id)
        );

        if (rows == 0) return "Scrap product not found";
        return "success";
    }

    public static string DeleteProduct(string id)
    {
        int rows = clsDatabase.ExecuteNonQuery("DELETE FROM ScrapProducts WHERE Id = @Id", new SqlParameter("@Id", id));
        if (rows == 0) return "Scrap product not found";
        return "success";
    }
}
