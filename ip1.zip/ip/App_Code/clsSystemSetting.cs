using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.Script.Serialization;

public class clsSystemSetting
{
    public static object GetSetting(string key)
    {
        var result = clsDatabase.ExecuteScalar("SELECT Value FROM SystemSettings WHERE [Key] = @Key", new SqlParameter("@Key", key));
        if (result == null || result == DBNull.Value)
        {
            if (key == "enableSecurityScrapEntry" || key == "allowSecurityChangeStartDate")
            {
                return false;
            }
            return null;
        }

        string json = result.ToString();
        try
        {
            var serializer = new JavaScriptSerializer();
            return serializer.DeserializeObject(json);
        }
        catch
        {
            return false;
        }
    }

    public static string UpdateSetting(string key, object value)
    {
        if (string.IsNullOrWhiteSpace(key)) return "Key is required";

        var serializer = new JavaScriptSerializer();
        string jsonVal = serializer.Serialize(value);

        var count = (int)clsDatabase.ExecuteScalar("SELECT COUNT(*) FROM SystemSettings WHERE [Key] = @Key", new SqlParameter("@Key", key));

        if (count == 0)
        {
            clsDatabase.ExecuteNonQuery(
                "INSERT INTO SystemSettings ([Key], Value, UpdatedAt) VALUES (@Key, @Value, @UpdatedAt)",
                new SqlParameter("@Key", key),
                new SqlParameter("@Value", jsonVal),
                new SqlParameter("@UpdatedAt", DateTime.UtcNow)
            );
        }
        else
        {
            clsDatabase.ExecuteNonQuery(
                "UPDATE SystemSettings SET Value = @Value, UpdatedAt = @UpdatedAt WHERE [Key] = @Key",
                new SqlParameter("@Value", jsonVal),
                new SqlParameter("@UpdatedAt", DateTime.UtcNow),
                new SqlParameter("@Key", key)
            );
        }

        return "success";
    }
}
