using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

public class clsBranch
{
    public static List<object> GetBranches()
    {
        var dt = clsDatabase.GetDataTable("SELECT FactoryId AS Id, FactoryName AS Name FROM FactoryMaster WHERE FactoryName IS NOT NULL AND FactoryName != '' ORDER BY FactoryName");
        var list = new List<object>();
        foreach (DataRow row in dt.Rows)
        {
            list.Add(new
            {
                _id = row["Id"].ToString(),
                id = row["Id"].ToString(),
                name = row["Name"].ToString(),
                createdBy = "system",
                createdAt = DateTime.UtcNow,
                updatedAt = DateTime.UtcNow
            });
        }
        return list;
    }

    public static string CreateBranch(string name, string createdBy)
    {
        var nameTrim = name.Trim();
        var count = (int)clsDatabase.ExecuteScalar("SELECT COUNT(*) FROM Branches WHERE LOWER(Name) = LOWER(@Name)", 
            new SqlParameter("@Name", nameTrim));
        if (count > 0) return "Branch already exists";

        var id = Guid.NewGuid().ToString();
        clsDatabase.ExecuteNonQuery(
            "INSERT INTO Branches (Id, Name, CreatedBy, CreatedAt, UpdatedAt) VALUES (@Id, @Name, @CreatedBy, @CreatedAt, @UpdatedAt)",
            new SqlParameter("@Id", id),
            new SqlParameter("@Name", nameTrim),
            new SqlParameter("@CreatedBy", createdBy ?? "system"),
            new SqlParameter("@CreatedAt", DateTime.UtcNow),
            new SqlParameter("@UpdatedAt", DateTime.UtcNow)
        );

        return "success:" + id;
    }

    public static string UpdateBranch(string id, string name)
    {
        var nameTrim = name.Trim();
        var count = (int)clsDatabase.ExecuteScalar("SELECT COUNT(*) FROM Branches WHERE LOWER(Name) = LOWER(@Name) AND Id != @Id", 
            new SqlParameter("@Name", nameTrim), new SqlParameter("@Id", id));
        if (count > 0) return "Branch already exists";

        int rows = clsDatabase.ExecuteNonQuery(
            "UPDATE Branches SET Name = @Name, UpdatedAt = @UpdatedAt WHERE Id = @Id",
            new SqlParameter("@Name", nameTrim),
            new SqlParameter("@UpdatedAt", DateTime.UtcNow),
            new SqlParameter("@Id", id)
        );

        if (rows == 0) return "Branch not found";
        return "success";
    }

    public static string DeleteBranch(string id)
    {
        int rows = clsDatabase.ExecuteNonQuery("DELETE FROM Branches WHERE Id = @Id", new SqlParameter("@Id", id));
        if (rows == 0) return "Branch not found";
        return "success";
    }
}
