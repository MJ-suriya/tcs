using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

public class clsVehicleProfile
{
    private static readonly string[] DEFAULT_VEHICLES = { "TN01AB1234", "TN02CD5678", "TN03EF9012" };

    public static bool MatchVehicleNumbers(string v1, string v2)
    {
        if (string.IsNullOrEmpty(v1) || string.IsNullOrEmpty(v2)) return false;

        var cleanV1 = v1.Trim().ToLowerInvariant();
        var cleanV2 = v2.Trim().ToLowerInvariant();

        if (cleanV1 == cleanV2) return true;

        var stripped1 = Regex.Replace(cleanV1, @"\s+", "");
        var stripped2 = Regex.Replace(cleanV2, @"\s+", "");
        if (stripped1 == stripped2) return true;

        var digits1 = Regex.Replace(cleanV1, @"\D", "");
        var digits2 = Regex.Replace(cleanV2, @"\D", "");

        if (digits1 == digits2 && !string.IsNullOrEmpty(digits1))
        {
            var letters1 = Regex.Replace(cleanV1, @"[^a-z]", "");
            var letters2 = Regex.Replace(cleanV2, @"[^a-z]", "");

            if (letters1.Length == 2 && letters2.Length >= 2 && letters2.StartsWith(letters1)) return true;
            if (letters2.Length == 2 && letters1.Length >= 2 && letters1.StartsWith(letters2)) return true;
        }

        return false;
    }

    public static Dictionary<string, object> FindMatchedProfile(string vehicleNumber)
    {
        var normalized = vehicleNumber.Trim().ToUpperInvariant();
        if (string.IsNullOrEmpty(normalized)) return null;

        var dt = clsDatabase.GetDataTable("SELECT Id, VehicleNumber, ShortName, VehicleName, OpeningKm, OpeningFuel, TankCapacity, ExpectedMileage, OwnershipType, Status, CreatedBy, BranchId, BranchName, CreatedAt, UpdatedAt FROM VehicleProfiles WHERE VehicleNumber = @VehicleNumber",
            new SqlParameter("@VehicleNumber", normalized));

        if (dt.Rows.Count > 0) return RowToProfileDict(dt.Rows[0]);

        // Fallback match across all profiles
        var all = clsDatabase.GetDataTable("SELECT Id, VehicleNumber, ShortName, VehicleName, OpeningKm, OpeningFuel, TankCapacity, ExpectedMileage, OwnershipType, Status, CreatedBy, BranchId, BranchName, CreatedAt, UpdatedAt FROM VehicleProfiles");
        foreach (DataRow row in all.Rows)
        {
            if (MatchVehicleNumbers(row["VehicleNumber"].ToString(), normalized))
            {
                return RowToProfileDict(row);
            }
        }

        return null;
    }

    public static List<string> GetAlternativeVehicleNumbers(string vehicleNumber)
    {
        var normalized = vehicleNumber.Trim().ToUpperInvariant();
        if (string.IsNullOrEmpty(normalized)) return new List<string> { normalized };

        var profile = FindMatchedProfile(normalized);
        if (profile != null)
        {
            string pNum = profile["vehicleNumber"].ToString().ToUpperInvariant();
            if (pNum != normalized)
            {
                return new List<string> { normalized, pNum };
            }
        }

        return new List<string> { normalized };
    }

    private static Dictionary<string, object> RowToProfileDict(DataRow row)
    {
        return new Dictionary<string, object>
        {
            { "id", row["Id"].ToString() },
            { "vehicleNumber", row["VehicleNumber"].ToString() },
            { "shortName", row["ShortName"].ToString() },
            { "vehicleName", row["VehicleName"].ToString() },
            { "openingKm", Convert.ToDouble(row["OpeningKm"]) },
            { "openingFuel", Convert.ToDouble(row["OpeningFuel"]) },
            { "tankCapacity", Convert.ToDouble(row["TankCapacity"]) },
            { "expectedMileage", row["ExpectedMileage"] == DBNull.Value ? (double?)null : Convert.ToDouble(row["ExpectedMileage"]) },
            { "ownershipType", row["OwnershipType"].ToString() },
            { "status", row["Status"].ToString() },
            { "createdBy", row["CreatedBy"].ToString() },
            { "branchId", row["BranchId"] == DBNull.Value ? null : row["BranchId"].ToString() },
            { "branchName", row["BranchName"] == DBNull.Value ? "" : row["BranchName"].ToString() },
            { "createdAt", Convert.ToDateTime(row["CreatedAt"]) },
            { "updatedAt", Convert.ToDateTime(row["UpdatedAt"]) }
        };
    }

    public static List<Dictionary<string, object>> GetVehicles()
    {
        var dt = clsDatabase.GetDataTable("SELECT Id, VehicleNumber, ShortName, VehicleName, OpeningKm, OpeningFuel, TankCapacity, ExpectedMileage, Status, BranchId, BranchName, OwnershipType FROM VehicleProfiles ORDER BY VehicleNumber");
        var profiles = new List<Dictionary<string, object>>();
        var known = new HashSet<string>();

        foreach (DataRow row in dt.Rows)
        {
            string vNum = row["VehicleNumber"].ToString().ToUpperInvariant();
            known.Add(vNum);

            profiles.Add(new Dictionary<string, object>
            {
                { "_id", row["Id"].ToString() },
                { "id", row["Id"].ToString() },
                { "vehicleNumber", row["VehicleNumber"].ToString() },
                { "shortName", row["ShortName"].ToString() },
                { "vehicleName", row["VehicleName"].ToString() },
                { "openingKm", Convert.ToDouble(row["OpeningKm"]) },
                { "openingFuel", Convert.ToDouble(row["OpeningFuel"]) },
                { "tankCapacity", Convert.ToDouble(row["TankCapacity"]) },
                { "expectedMileage", row["ExpectedMileage"] == DBNull.Value ? (double?)null : Convert.ToDouble(row["ExpectedMileage"]) },
                { "status", row["Status"].ToString() },
                { "branch", row["BranchId"] == DBNull.Value ? null : row["BranchId"].ToString() },
                { "branchName", row["BranchName"] == DBNull.Value ? "" : row["BranchName"].ToString() },
                { "ownershipType", row["OwnershipType"].ToString() },
                { "isProfile", true }
            });
        }

        foreach (var v in DEFAULT_VEHICLES)
        {
            var upperV = v.ToUpperInvariant();
            if (!known.Contains(upperV))
            {
                profiles.Add(new Dictionary<string, object>
                {
                    { "_id", upperV },
                    { "id", upperV },
                    { "vehicleNumber", upperV },
                    { "shortName", "" },
                    { "vehicleName", "" },
                    { "openingKm", 0.0 },
                    { "openingFuel", 0.0 },
                    { "tankCapacity", 0.0 },
                    { "expectedMileage", (double?)null },
                    { "status", "active" },
                    { "branch", (string)null },
                    { "branchName", "" },
                    { "ownershipType", "own" },
                    { "isProfile", false }
                });
            }
        }

        // Sort profiles alphabetically by vehicleNumber
        profiles.Sort((x, y) => {
            string vx = x["vehicleNumber"].ToString();
            string vy = y["vehicleNumber"].ToString();
            return string.Compare(vx, vy, StringComparison.OrdinalIgnoreCase);
        });

        return profiles;
    }

    public static string GetNextShortName()
    {
        var dt = clsDatabase.GetDataTable("SELECT ShortName FROM VehicleProfiles");
        int maxNum = 0;
        foreach (DataRow row in dt.Rows)
        {
            var shortName = row["ShortName"].ToString();
            var match = Regex.Match(shortName, @"^v(\d+)$");
            if (match.Success)
            {
                int num;
                if (int.TryParse(match.Groups[1].Value, out num))
                {
                    if (num > maxNum) maxNum = num;
                }
            }
        }
        return "v" + (maxNum + 1);
    }

    public static string CreateOrUpdateVehicleProfile(
        string vehicleNumber, string shortName, string vehicleName, 
        double openingKm, double tankCapacity, double? expectedMileage, 
        string status, string branchId, string branchName, string ownershipType, string createdBy)
    {
        var normalizedVehicle = vehicleNumber.Trim().ToUpperInvariant();
        if (string.IsNullOrEmpty(normalizedVehicle)) return "Vehicle number is required";

        string sName = string.IsNullOrEmpty(shortName) ? GetNextShortName() : shortName.Trim();
        string vName = string.IsNullOrEmpty(vehicleName) ? "" : vehicleName.Trim();
        if (string.IsNullOrEmpty(vName)) return "Vehicle name is required";

        if (openingKm < 0) return "Opening KM must be zero or positive";
        if (tankCapacity < 0) return "Tank capacity must be zero or positive";
        if (expectedMileage.HasValue && expectedMileage.Value <= 0) return "Expected mileage must be positive when provided";

        var statusVal = status == "inactive" ? "inactive" : "active";
        var ownType = ownershipType == "rental" ? "rental" : "own";

        // Check duplicate shortname
        var dupCount = (int)clsDatabase.ExecuteScalar(
            "SELECT COUNT(*) FROM VehicleProfiles WHERE ShortName = @ShortName AND VehicleNumber != @VehicleNumber",
            new SqlParameter("@ShortName", sName),
            new SqlParameter("@VehicleNumber", normalizedVehicle)
        );
        if (dupCount > 0) return "Short Name already exists";

        // Check if profile already exists
        var existingId = clsDatabase.ExecuteScalar(
            "SELECT Id FROM VehicleProfiles WHERE VehicleNumber = @VehicleNumber",
            new SqlParameter("@VehicleNumber", normalizedVehicle)) as string;

        if (existingId == null)
        {
            // INSERT
            string newId = Guid.NewGuid().ToString();
            clsDatabase.ExecuteNonQuery(
                "INSERT INTO VehicleProfiles (Id, VehicleNumber, ShortName, VehicleName, OpeningKm, OpeningFuel, TankCapacity, ExpectedMileage, OwnershipType, Status, CreatedBy, BranchId, BranchName, CreatedAt, UpdatedAt) " +
                "VALUES (@Id, @VehicleNumber, @ShortName, @VehicleName, @OpeningKm, @OpeningFuel, @TankCapacity, @ExpectedMileage, @OwnershipType, @Status, @CreatedBy, @BranchId, @BranchName, @CreatedAt, @UpdatedAt)",
                new SqlParameter("@Id", newId),
                new SqlParameter("@VehicleNumber", normalizedVehicle),
                new SqlParameter("@ShortName", sName),
                new SqlParameter("@VehicleName", vName),
                new SqlParameter("@OpeningKm", openingKm),
                new SqlParameter("@OpeningFuel", SqlDbType.Float) { Value = 0.0 }, // openingFuel
                new SqlParameter("@TankCapacity", tankCapacity),
                new SqlParameter("@ExpectedMileage", expectedMileage.HasValue ? (object)expectedMileage.Value : DBNull.Value),
                new SqlParameter("@OwnershipType", ownType),
                new SqlParameter("@Status", statusVal),
                new SqlParameter("@CreatedBy", createdBy ?? "system"),
                new SqlParameter("@BranchId", string.IsNullOrEmpty(branchId) ? DBNull.Value : (object)branchId),
                new SqlParameter("@BranchName", string.IsNullOrEmpty(branchName) ? DBNull.Value : (object)branchName),
                new SqlParameter("@CreatedAt", DateTime.UtcNow),
                new SqlParameter("@UpdatedAt", DateTime.UtcNow)
            );
        }
        else
        {
            // UPDATE
            clsDatabase.ExecuteNonQuery(
                "UPDATE VehicleProfiles SET ShortName = @ShortName, VehicleName = @VehicleName, OpeningKm = @OpeningKm, TankCapacity = @TankCapacity, ExpectedMileage = @ExpectedMileage, OwnershipType = @OwnershipType, Status = @Status, BranchId = @BranchId, BranchName = @BranchName, UpdatedAt = @UpdatedAt " +
                "WHERE Id = @Id",
                new SqlParameter("@ShortName", sName),
                new SqlParameter("@VehicleName", vName),
                new SqlParameter("@OpeningKm", openingKm),
                new SqlParameter("@TankCapacity", tankCapacity),
                new SqlParameter("@ExpectedMileage", expectedMileage.HasValue ? (object)expectedMileage.Value : DBNull.Value),
                new SqlParameter("@OwnershipType", ownType),
                new SqlParameter("@Status", statusVal),
                new SqlParameter("@BranchId", string.IsNullOrEmpty(branchId) ? DBNull.Value : (object)branchId),
                new SqlParameter("@BranchName", string.IsNullOrEmpty(branchName) ? DBNull.Value : (object)branchName),
                new SqlParameter("@UpdatedAt", DateTime.UtcNow),
                new SqlParameter("@Id", existingId)
            );
        }

        return "success";
    }

    public static string DeleteVehicleProfile(string vehicleNumber)
    {
        var normalized = vehicleNumber.Trim().ToUpperInvariant();
        if (string.IsNullOrEmpty(normalized)) return "Vehicle number is required";

        int rows = clsDatabase.ExecuteNonQuery("DELETE FROM VehicleProfiles WHERE VehicleNumber = @VehicleNumber",
            new SqlParameter("@VehicleNumber", normalized));

        if (rows == 0) return "Vehicle profile not found";

        // Resequence remaining short names matching v1, v2...
        ResequenceVehicleShortNames();

        return "success";
    }

    private static void ResequenceVehicleShortNames()
    {
        var dt = clsDatabase.GetDataTable("SELECT Id, ShortName FROM VehicleProfiles ORDER BY CreatedAt");
        var seqProfiles = new List<string>(); // List of IDs that match v\d+

        foreach (DataRow row in dt.Rows)
        {
            var sName = row["ShortName"].ToString();
            if (Regex.IsMatch(sName, @"^v\d+$"))
            {
                seqProfiles.Add(row["Id"].ToString());
            }
        }

        // Rename to temporary names
        for (int i = 0; i < seqProfiles.Count; i++)
        {
            string tempName = "_temp_seq_" + i + "_" + DateTime.UtcNow.Ticks;
            clsDatabase.ExecuteNonQuery("UPDATE VehicleProfiles SET ShortName = @ShortName WHERE Id = @Id",
                new SqlParameter("@ShortName", tempName), new SqlParameter("@Id", seqProfiles[i]));
        }

        // Rename to final sequential names v1, v2, v3...
        for (int i = 0; i < seqProfiles.Count; i++)
        {
            string seqName = "v" + (i + 1);
            clsDatabase.ExecuteNonQuery("UPDATE VehicleProfiles SET ShortName = @ShortName WHERE Id = @Id",
                new SqlParameter("@ShortName", seqName), new SqlParameter("@Id", seqProfiles[i]));
        }
    }

    public static void SyncVehicleProfileOpeningKm(string vehicleNumber)
    {
        try
        {
            var normalizedVehicle = vehicleNumber.Trim().ToUpperInvariant();
            if (string.IsNullOrEmpty(normalizedVehicle)) return;

            var profile = FindMatchedProfile(normalizedVehicle);
            if (profile == null) return;

            var vehicleList = GetAlternativeVehicleNumbers(normalizedVehicle);
            string listClause = string.Join("','", vehicleList.ToArray());

            // Find last non-rejected log
            var dt = clsDatabase.GetDataTable(
                string.Format("SELECT TOP 1 EndKm FROM VehicleLogs WHERE VehicleNumber IN ('{0}') AND Status != 'rejected' ORDER BY EndDateTime DESC, CreatedAt DESC", listClause)
            );

            if (dt.Rows.Count > 0)
            {
                double lastEndKm = Convert.ToDouble(dt.Rows[0]["EndKm"]);
                clsDatabase.ExecuteNonQuery("UPDATE VehicleProfiles SET OpeningKm = @OpeningKm WHERE Id = @Id",
                    new SqlParameter("@OpeningKm", lastEndKm), new SqlParameter("@Id", profile["id"].ToString()));
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Failed to sync opening KM: " + ex.Message);
        }
    }
}
