using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web;

public static class clsDatabase
{
    private static bool _dbInitialized = false;
    private static readonly object _dbLock = new object();

    public static string GetConnectionString()
    {
        var connSetting = ConfigurationManager.ConnectionStrings["ConnectionString"];
        return connSetting != null ? connSetting.ConnectionString 
            : @"Data Source=192.168.50.32,1433; Initial Catalog=TESTVMS;User ID=sa;Password=D@!vel3484;TrustServerCertificate=True";
    }

    public static bool TryParseDate(string dateStr, out DateTime parsedDate)
    {
        parsedDate = DateTime.MinValue;
        if (string.IsNullOrEmpty(dateStr)) return false;

        // Try standard TryParse first
        if (DateTime.TryParse(dateStr, out parsedDate)) return true;

        // Try explicit format with InvariantCulture
        string[] formats = { 
            "d-MMM-yyyy h:mm tt", 
            "d-MMM-yyyy hh:mm tt", 
            "d-MMM-yyyy h:m tt",
            "dd-MMM-yyyy hh:mm tt",
            "dd-MMM-yyyy h:mm tt"
        };
        return DateTime.TryParseExact(dateStr, formats, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out parsedDate);
    }

    public static SqlConnection GetConnection()
    {
        InitializeDatabaseLazy();
        var conn = new SqlConnection(GetConnectionString());
        conn.Open();
        return conn;
    }

    private static void SanitizeParameters(SqlParameter[] parameters)
    {
        if (parameters == null) return;
        foreach (var p in parameters)
        {
            if (p.Value is DateTime)
            {
                DateTime dt = (DateTime)p.Value;
                if (dt < new DateTime(1753, 1, 1))
                {
                    p.Value = new DateTime(1753, 1, 1);
                }
            }
        }
    }

    public static DataTable GetDataTable(string query, params SqlParameter[] parameters)
    {
        InitializeDatabaseLazy();
        SanitizeParameters(parameters);
        using (var conn = new SqlConnection(GetConnectionString()))
        {
            using (var cmd = new SqlCommand(query, conn))
            {
                if (parameters != null)
                {
                    cmd.Parameters.AddRange(parameters);
                }
                using (var da = new SqlDataAdapter(cmd))
                {
                    var dt = new DataTable();
                    da.Fill(dt);
                    return dt;
                }
            }
        }
    }

    public static int ExecuteNonQuery(string query, params SqlParameter[] parameters)
    {
        InitializeDatabaseLazy();
        SanitizeParameters(parameters);
        try
        {
            using (var conn = new SqlConnection(GetConnectionString()))
            {
                conn.Open();
                using (var cmd = new SqlCommand(query, conn))
                {
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    
                    try
                    {
                        string logPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "db_query_log.txt");
                        using (var writer = System.IO.File.AppendText(logPath))
                        {
                            writer.WriteLine("--- EXECUTE NON QUERY ---");
                            writer.WriteLine("Time: " + DateTime.Now.ToString());
                            writer.WriteLine("Query: " + query);
                            if (parameters != null)
                            {
                                foreach (var p in parameters)
                                {
                                    writer.WriteLine(string.Format("Param: {0} = {1} ({2})", p.ParameterName, p.Value ?? "null", p.Value != null ? p.Value.GetType().Name : "null"));
                                }
                            }
                            writer.WriteLine();
                        }
                    }
                    catch { }

                    return cmd.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            try
            {
                string logPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "db_query_log.txt");
                using (var writer = System.IO.File.AppendText(logPath))
                {
                    writer.WriteLine("--- ERROR NON QUERY ---");
                    writer.WriteLine("Time: " + DateTime.Now.ToString());
                    writer.WriteLine("Error: " + ex.ToString());
                    writer.WriteLine();
                }
            }
            catch { }
            throw;
        }
    }

    public static object ExecuteScalar(string query, params SqlParameter[] parameters)
    {
        InitializeDatabaseLazy();
        SanitizeParameters(parameters);
        try
        {
            using (var conn = new SqlConnection(GetConnectionString()))
            {
                conn.Open();
                using (var cmd = new SqlCommand(query, conn))
                {
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }

                    try
                    {
                        string logPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "db_query_log.txt");
                        using (var writer = System.IO.File.AppendText(logPath))
                        {
                            writer.WriteLine("--- EXECUTE SCALAR ---");
                            writer.WriteLine("Time: " + DateTime.Now.ToString());
                            writer.WriteLine("Query: " + query);
                            if (parameters != null)
                            {
                                foreach (var p in parameters)
                                {
                                    writer.WriteLine(string.Format("Param: {0} = {1} ({2})", p.ParameterName, p.Value ?? "null", p.Value != null ? p.Value.GetType().Name : "null"));
                                }
                            }
                            writer.WriteLine();
                        }
                    }
                    catch { }

                    return cmd.ExecuteScalar();
                }
            }
        }
        catch (Exception ex)
        {
            try
            {
                string logPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "db_query_log.txt");
                using (var writer = System.IO.File.AppendText(logPath))
                {
                    writer.WriteLine("--- ERROR SCALAR ---");
                    writer.WriteLine("Time: " + DateTime.Now.ToString());
                    writer.WriteLine("Error: " + ex.ToString());
                    writer.WriteLine();
                }
            }
            catch { }
            throw;
        }
    }

    public static void InitializeDatabaseLazy()
    {
        if (_dbInitialized) return;
        lock (_dbLock)
        {
            if (_dbInitialized) return;
            try
            {
                using (var conn = new SqlConnection(GetConnectionString()))
                {
                    conn.Open();

                    // Create Tables
                    string createTablesSql = @"
                    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[VehicleProfiles]') AND type in (N'U'))
                    CREATE TABLE [VehicleProfiles] (
                        [Id] VARCHAR(50) PRIMARY KEY,
                        [VehicleNumber] NVARCHAR(50) NOT NULL UNIQUE,
                        [ShortName] NVARCHAR(50) NOT NULL UNIQUE,
                        [VehicleName] NVARCHAR(100) NOT NULL,
                        [OpeningKm] FLOAT NOT NULL,
                        [OpeningFuel] FLOAT NOT NULL,
                        [TankCapacity] FLOAT NOT NULL,
                        [ExpectedMileage] FLOAT NULL,
                        [OwnershipType] NVARCHAR(50) NOT NULL,
                        [Status] NVARCHAR(50) NOT NULL,
                        [CreatedBy] NVARCHAR(100) NULL,
                        [BranchId] VARCHAR(50) NULL,
                        [BranchName] NVARCHAR(100) NULL,
                        [CreatedAt] DATETIME NOT NULL,
                        [UpdatedAt] DATETIME NOT NULL
                    );

                    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[VehicleExpenses]') AND type in (N'U'))
                    CREATE TABLE [VehicleExpenses] (
                        [Id] VARCHAR(50) PRIMARY KEY,
                        [VehicleNumber] NVARCHAR(50) NOT NULL,
                        [ExpenseType] NVARCHAR(100) NOT NULL,
                        [Amount] FLOAT NOT NULL,
                        [Date] DATETIME NOT NULL,
                        [Description] NVARCHAR(MAX) NOT NULL,
                        [Status] NVARCHAR(50) NOT NULL,
                        [RejectReason] NVARCHAR(MAX) NOT NULL,
                        [QueryQuestion] NVARCHAR(MAX) NOT NULL,
                        [QueryAnswer] NVARCHAR(MAX) NOT NULL,
                        [CreatedBy] NVARCHAR(100) NULL,
                        [CreatedAt] DATETIME NOT NULL,
                        [ReviewedBy] NVARCHAR(100) NULL,
                        [ReviewedAt] DATETIME NULL
                    );

                    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[VehicleLogs]') AND type in (N'U'))
                    CREATE TABLE [VehicleLogs] (
                        [Id] VARCHAR(50) PRIMARY KEY,
                        [DriverName] NVARCHAR(100) NOT NULL,
                        [VehicleNumber] NVARCHAR(50) NOT NULL,
                        [FromLocation] NVARCHAR(255) NOT NULL,
                        [ToLocation] NVARCHAR(255) NOT NULL,
                        [StartDateTime] DATETIME NOT NULL,
                        [EndDateTime] DATETIME NOT NULL,
                        [StartKm] FLOAT NOT NULL,
                        [EndKm] FLOAT NOT NULL,
                        [DistanceTravelled] FLOAT NOT NULL,
                        [AvailableFuel] FLOAT NOT NULL,
                        [FuelAdded] FLOAT NOT NULL,
                        [RemainingFuel] FLOAT NOT NULL,
                        [FuelFillDate] DATETIME NULL,
                        [FuelUsed] FLOAT NOT NULL,
                        [Mileage] FLOAT NULL,
                        [MileageReason] NVARCHAR(MAX) NOT NULL,
                        [IsLowFuel] BIT NOT NULL,
                        [FuelType] NVARCHAR(50) NULL,
                        [PricePerLitre] FLOAT NULL,
                        [CorrectedFromLogId] VARCHAR(50) NULL,
                        [CorrectedByLogId] VARCHAR(50) NULL,
                        [Status] NVARCHAR(50) NOT NULL,
                        [RejectReason] NVARCHAR(MAX) NOT NULL,
                        [QueryQuestion] NVARCHAR(MAX) NOT NULL,
                        [QueryAnswer] NVARCHAR(MAX) NOT NULL,
                        [CreatedBy] NVARCHAR(100) NOT NULL,
                        [ReviewedBy] NVARCHAR(100) NULL,
                        [ReviewedAt] DATETIME NULL,
                        [BranchId] VARCHAR(50) NULL,
                        [BranchName] NVARCHAR(100) NULL,
                        [CreatedAt] DATETIME NOT NULL,
                        [UpdatedAt] DATETIME NOT NULL
                    );

                    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[VehicleLogExpenses]') AND type in (N'U'))
                    CREATE TABLE [VehicleLogExpenses] (
                        [Id] VARCHAR(50) PRIMARY KEY,
                        [VehicleLogId] VARCHAR(50) NOT NULL FOREIGN KEY REFERENCES [VehicleLogs](Id) ON DELETE CASCADE,
                        [ExpenseType] NVARCHAR(100) NOT NULL,
                        [Amount] FLOAT NOT NULL,
                        [Date] DATETIME NOT NULL,
                        [Description] NVARCHAR(MAX) NOT NULL
                    );

                    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[VehicleLogDrafts]') AND type in (N'U'))
                    CREATE TABLE [VehicleLogDrafts] (
                        [Id] VARCHAR(50) PRIMARY KEY,
                        [DriverName] NVARCHAR(100) NOT NULL,
                        [VehicleNumber] NVARCHAR(50) NOT NULL,
                        [FromLocation] NVARCHAR(255) NOT NULL,
                        [ToLocation] NVARCHAR(255) NOT NULL,
                        [StartDateTime] DATETIME NULL,
                        [EndDateTime] DATETIME NULL,
                        [EndKm] FLOAT NULL,
                        [FuelAdded] FLOAT NOT NULL,
                        [RemainingFuel] FLOAT NULL,
                        [FuelType] NVARCHAR(50) NULL,
                        [PricePerLitre] FLOAT NULL,
                        [CorrectedFromLogId] VARCHAR(50) NULL,
                        [CreatedBy] NVARCHAR(100) NOT NULL,
                        [BranchId] VARCHAR(50) NULL,
                        [BranchName] NVARCHAR(100) NULL,
                        [CreatedAt] DATETIME NOT NULL,
                        [UpdatedAt] DATETIME NOT NULL
                    );

                    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[VehicleLogDraftExpenses]') AND type in (N'U'))
                    CREATE TABLE [VehicleLogDraftExpenses] (
                        [Id] VARCHAR(50) PRIMARY KEY,
                        [VehicleLogDraftId] VARCHAR(50) NOT NULL FOREIGN KEY REFERENCES [VehicleLogDrafts](Id) ON DELETE CASCADE,
                        [ExpenseType] NVARCHAR(100) NOT NULL,
                        [Amount] FLOAT NOT NULL,
                        [Date] DATETIME NOT NULL,
                        [Description] NVARCHAR(MAX) NOT NULL
                    );

                    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[FuelPrices]') AND type in (N'U'))
                    CREATE TABLE [FuelPrices] (
                        [FuelType] NVARCHAR(50) PRIMARY KEY,
                        [PricePerLitre] FLOAT NOT NULL,
                        [CreatedAt] DATETIME NOT NULL,
                        [UpdatedAt] DATETIME NOT NULL
                    );

                    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[ScrapProducts]') AND type in (N'U'))
                    CREATE TABLE [ScrapProducts] (
                        [Id] VARCHAR(50) PRIMARY KEY,
                        [Name] NVARCHAR(100) NOT NULL UNIQUE,
                        [PricePerKg] FLOAT NOT NULL,
                        [CreatedBy] NVARCHAR(100) NULL,
                        [CreatedAt] DATETIME NOT NULL,
                        [UpdatedAt] DATETIME NOT NULL
                    );

                    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[ScrapEntries]') AND type in (N'U'))
                    CREATE TABLE [ScrapEntries] (
                        [Id] VARCHAR(50) PRIMARY KEY,
                        [CompanyName] NVARCHAR(150) NOT NULL,
                        [VehicleNumber] NVARCHAR(50) NOT NULL,
                        [OwnerName] NVARCHAR(150) NOT NULL,
                        [Status] NVARCHAR(50) NOT NULL,
                        [PettyCashierVerifiedAmount] FLOAT NULL,
                        [RejectReason] NVARCHAR(MAX) NOT NULL DEFAULT '',
                        [QueryQuestion] NVARCHAR(MAX) NOT NULL DEFAULT '',
                        [QueryAnswer] NVARCHAR(MAX) NOT NULL DEFAULT '',
                        [ProofDocument] NVARCHAR(255) NULL,
                        [CreatedBy] NVARCHAR(100) NOT NULL,
                        [BranchId] VARCHAR(50) NULL,
                        [BranchName] NVARCHAR(100) NULL,
                        [CreatedAt] DATETIME NOT NULL,
                        [UpdatedAt] DATETIME NOT NULL,
                        [ReviewedBy] NVARCHAR(100) NULL,
                        [ReviewedByRole] NVARCHAR(50) NULL,
                        [ReviewedAt] DATETIME NULL
                    );

                    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[ScrapEntryItems]') AND type in (N'U'))
                    CREATE TABLE [ScrapEntryItems] (
                        [Id] VARCHAR(50) PRIMARY KEY,
                        [ScrapEntryId] VARCHAR(50) NOT NULL FOREIGN KEY REFERENCES [ScrapEntries](Id) ON DELETE CASCADE,
                        [ProductId] VARCHAR(50) NOT NULL,
                        [ProductName] NVARCHAR(100) NOT NULL,
                        [Weight] FLOAT NOT NULL,
                        [PricePerKg] FLOAT NOT NULL,
                        [TotalAmount] FLOAT NOT NULL
                    );

                    IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[SystemSettings]') AND type in (N'U'))
                    CREATE TABLE [SystemSettings] (
                        [Key] NVARCHAR(100) PRIMARY KEY,
                        [Value] NVARCHAR(MAX) NOT NULL,
                        [UpdatedAt] DATETIME NOT NULL
                    );
                    ";

                    using (var cmd = new SqlCommand(createTablesSql, conn))
                    {
                        cmd.ExecuteNonQuery();
                    }

                    // Seed Default Fuel Prices (Petrol: 102.50, Diesel: 94.20)
                    bool hasPetrol = false;
                    using (var cmd = new SqlCommand("SELECT COUNT(*) FROM FuelPrices WHERE FuelType = 'petrol'", conn))
                    {
                        hasPetrol = ((int)cmd.ExecuteScalar()) > 0;
                    }
                    if (!hasPetrol)
                    {
                        using (var cmd = new SqlCommand("INSERT INTO FuelPrices (FuelType, PricePerLitre, CreatedAt, UpdatedAt) VALUES ('petrol', 102.50, @CreatedAt, @UpdatedAt)", conn))
                        {
                            cmd.Parameters.AddWithValue("@CreatedAt", DateTime.UtcNow);
                            cmd.Parameters.AddWithValue("@UpdatedAt", DateTime.UtcNow);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    bool hasDiesel = false;
                    using (var cmd = new SqlCommand("SELECT COUNT(*) FROM FuelPrices WHERE FuelType = 'diesel'", conn))
                    {
                        hasDiesel = ((int)cmd.ExecuteScalar()) > 0;
                    }
                    if (!hasDiesel)
                    {
                        using (var cmd = new SqlCommand("INSERT INTO FuelPrices (FuelType, PricePerLitre, CreatedAt, UpdatedAt) VALUES ('diesel', 94.20, @CreatedAt, @UpdatedAt)", conn))
                        {
                            cmd.Parameters.AddWithValue("@CreatedAt", DateTime.UtcNow);
                            cmd.Parameters.AddWithValue("@UpdatedAt", DateTime.UtcNow);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    // Ensure uploads folder exists
                    string uploadsFolder;
                    if (HttpContext.Current != null && HttpContext.Current.Server != null)
                    {
                        uploadsFolder = HttpContext.Current.Server.MapPath("~/uploads/scrap");
                    }
                    else
                    {
                        uploadsFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "uploads", "scrap");
                    }
                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }
                }

                _dbInitialized = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Database seeding failed: " + ex.Message);
            }
        }
    }
}
