<%@ Page Title="" Language="C#" MasterPageFile="~/General/Master.master" AutoEventWireup="true"
    CodeFile="ScrapProductMaster.aspx.cs" Inherits="Master_ScrapProductMaster" %>

    <asp:Content ID="Content1" ContentPlaceHolderID="ctnHead" runat="Server">
        <script class="text/javascript">
            window.onload = function() {
                getTbleDet();
                loadWeighbridgeSettings();
            };

            function masterLoad(Mode, id, name, price) {
                $("#modal-default").modal('show');
                $("#hf_Mode").val(Mode);
                $("#btn_Submit").attr("disabled", false);

                if (Mode == 'A') {
                    $("#modal_title").text("Add Scrap Product");
                    $("#txt_ProductName").val("").attr("disabled", false);
                    $("#txt_PricePerKg").val("0.00");
                    $("#hf_ProductId").val("");
                } else {
                    $("#modal_title").text("Edit Product Price");
                    $("#txt_ProductName").val(name).attr("disabled", true);
                    $("#txt_PricePerKg").val(price);
                    $("#hf_ProductId").val(id);
                }
            }

            function mandatoryValidation() {
                $("#btn_Submit").attr("disabled", true);
                var name = $("#txt_ProductName").val().trim();
                var price = parseFloat($("#txt_PricePerKg").val());

                if (name.length === 0) {
                    swal("Attention!", "Enter Product Name", "warning");
                    $("#btn_Submit").attr("disabled", false);
                    $("#txt_ProductName").focus();
                    return;
                }
                if (isNaN(price) || price < 0) {
                    swal("Attention!", "Enter valid price per kg", "warning");
                    $("#btn_Submit").attr("disabled", false);
                    $("#txt_PricePerKg").focus();
                    return;
                }

                var Mode = $("#hf_Mode").val();
                if (Mode == 'A') {
                    PageMethods.CreateProduct(name, price, function (response) {
                        if (response.error) {
                            swal("Error", response.error, "error");
                            $("#btn_Submit").attr("disabled", false);
                        } else {
                            swal("Success", "Scrap product added successfully!", "success");
                            $("#modal-default").modal('hide');
                            getTbleDet();
                        }
                    });
                } else {
                    var id = $("#hf_ProductId").val();
                    PageMethods.UpdateProductPrice(id, price, function (response) {
                        if (response.error) {
                            swal("Error", response.error, "error");
                            $("#btn_Submit").attr("disabled", false);
                        } else {
                            swal("Success", "Scrap product price updated successfully!", "success");
                            $("#modal-default").modal('hide');
                            getTbleDet();
                        }
                    });
                }
            }

            function getTbleDet() {
                if ($.fn.DataTable.isDataTable('#tbl_ScrapProducts')) {
                    $("#tbl_ScrapProducts").DataTable().destroy();
                }
                $("#tbl_bdy_ScrapProducts").html("");

                PageMethods.GetProducts(function (response) {
                    if (response && response.length > 0) {
                        $.each(response, function (key, val) {
                            var actionsHtml = '<a href="#" onclick="editProduct(\'' + val.id + '\',\'' + val.name.replace(/'/g, "\\'") + '\',' + val.pricePerKg + ')" class="btn btn-default btn-xs" style="margin-right: 5px;"><i class="fa fa-pencil"></i></a>'
                                + '<a href="#" onclick="deleteProduct(\'' + val.id + '\',\'' + val.name.replace(/'/g, "\\'") + '\')" class="btn btn-default btn-xs"><i class="fa fa-trash"></i></a>';

                            var row = '<tr style="font-size:smaller;text-align:left;">'
                                + '<td style="vertical-align:center;text-align:center;">' + (key + 1) + '</td>'
                                + '<td style="vertical-align:center;font-weight:bold;text-transform:uppercase;">' + val.name + '</td>'
                                + '<td style="vertical-align:center;font-weight:bold;color:green;text-align:right;">Rs ' + val.pricePerKg.toFixed(2) + ' / Kg</td>'
                                + '<td style="text-align:center;">' + actionsHtml + '</td>'
                                + '</tr>';

                            $("#tbl_bdy_ScrapProducts").append(row);
                        });

                        $('#tbl_ScrapProducts').DataTable({
                            'paging': true,
                            'lengthChange': true,
                            'searching': true,
                            'ordering': true,
                            'info': true,
                            'autoWidth': false
                        });
                    }
                });
            }

            function editProduct(id, name, price) {
                masterLoad('E', id, name, price);
            }

            function loadWeighbridgeSettings() {
                if ($.fn.DataTable.isDataTable('#tbl_WeighbridgeSettings')) {
                    $("#tbl_WeighbridgeSettings").DataTable().destroy();
                }
                $("#tbl_bdy_WeighbridgeSettings").html("");

                PageMethods.GetWeighbridgeSettings(function (response) {
                    if (response && response.length > 0) {
                        $.each(response, function (key, val) {
                            var checked = val.allowManualWeight ? 'checked="checked"' : '';
                            var checkboxHtml = '<input type="checkbox" ' + checked + ' onchange="updateWeighbridgeSetting(\'' + val.id + '\', this)" style="cursor:pointer;" />';
                            
                            var row = '<tr style="font-size:smaller;text-align:left;">'
                                + '<td style="text-align:center;vertical-align:middle;">' + (key + 1) + '</td>'
                                + '<td style="font-weight:bold;text-transform:uppercase;vertical-align:middle;">' + val.name + '</td>'
                                + '<td style="text-align:center;vertical-align:middle;">' + checkboxHtml + '</td>'
                                + '</tr>';
                                
                            $("#tbl_bdy_WeighbridgeSettings").append(row);
                        });

                        $('#tbl_WeighbridgeSettings').DataTable({
                            'paging': true,
                            'lengthChange': true,
                            'searching': true,
                            'ordering': true,
                            'info': true,
                            'autoWidth': false
                        });
                    }
                });
            }

            function updateWeighbridgeSetting(branchId, chk) {
                var isChecked = $(chk).is(":checked");
                PageMethods.UpdateBranchManualWeightSetting(branchId, isChecked, function (response) {
                    if (response.error) {
                        swal("Error", response.error, "error");
                        $(chk).prop("checked", !isChecked);
                    }
                });
            }

            function deleteProduct(id, name) {
                swal({
                    title: "Are you sure?",
                    text: "Do you want to delete product " + name + "?",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                }).then(function (willDelete) {
                    if (willDelete) {
                        PageMethods.DeleteProduct(id, function (response) {
                            if (response.error) {
                                swal("Error", response.error, "error");
                            } else {
                                swal("Deleted!", "Scrap product has been deleted.", "success");
                                getTbleDet();
                            }
                        });
                    }
                });
            }
        </script>
    </asp:Content>

    <asp:Content ID="Content2" ContentPlaceHolderID="ctnForm" runat="Server">
        <input type="hidden" id="hf_Mode" />
        <input type="hidden" id="hf_ProductId" />
        <div class="content-wrapper">
            <section class="content-header">
                <h1>Scrap Product Master
                    <small>Pricing & Configuration</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="../General/Dashboard.aspx"><i class="fa fa-dashboard"></i>Home</a></li>
                    <li class="active">Scrap Products</li>
                    <li><a href="#" onclick="masterLoad('A')"><i class="fa fa-plus"></i>Add Scrap Product</a></li>
                </ol>
            </section>

            <section class="content">
                <div class="row">
                    <!-- Products column -->
                    <div class="col-xs-12 col-md-6">
                        <div class="box box-primary">
                            <div class="box-header with-border">
                                <h3 class="box-title">Products Price List</h3>
                            </div>
                            <div class="box-body">
                                <table id="tbl_ScrapProducts" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th style="text-align: center; width: 1%">#</th>
                                            <th style="text-align: center; width: 50%">Product Name</th>
                                            <th style="text-align: center; width: 30%">Price Per Kilogram</th>
                                            <th style="text-align: center; width: 19%">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tbl_bdy_ScrapProducts"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Weighbridge Settings column -->
                    <div class="col-xs-12 col-md-6">
                        <div class="box box-success">
                            <div class="box-header with-border">
                                <h3 class="box-title">Weighbridge Location Settings</h3>
                            </div>
                            <div class="box-body">
                                <table id="tbl_WeighbridgeSettings" class="table table-bordered table-hover" style="width: 100%;">
                                    <thead>
                                        <tr>
                                            <th style="text-align: center; width: 1%">#</th>
                                            <th style="text-align: center; width: 55%">Branch / Factory Location</th>
                                            <th style="text-align: center; width: 44%">Allow Manual Weight Entry</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tbl_bdy_WeighbridgeSettings"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Add/Edit Modal -->
                <div id="modal-default" class="modal fade" role="dialog">
                    <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title" id="modal_title">Scrap Product</h4>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="txt_ProductName">Product Name *</label>
                                    <input type="text" id="txt_ProductName" class="form-control text-uppercase"
                                        placeholder="e.g. COPPER WIRE" maxlength="100" />
                                </div>
                                <div class="form-group">
                                    <label for="txt_PricePerKg">Price per Kg (Rs) *</label>
                                    <input type="number" step="0.01" id="txt_PricePerKg" class="form-control"
                                        value="0.00" />
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left"
                                    data-dismiss="modal">Close</button>
                                <button type="button" id="btn_Submit" class="btn btn-primary"
                                    onclick="mandatoryValidation()">Save Product</button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </asp:Content>