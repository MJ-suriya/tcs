using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.Services;

public partial class Master_ScrapProductMaster : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null)
        {
            Response.Redirect("~/Login.aspx");
        }
    }

    [WebMethod]
    public static object GetProducts()
    {
        return clsScrapProduct.GetProducts();
    }

    [WebMethod(EnableSession = true)]
    public static object CreateProduct(string name, double pricePerKg)
    {
        string username = HttpContext.Current.Session["UserName"] != null ? HttpContext.Current.Session["UserName"].ToString() : "system";
        string res = clsScrapProduct.CreateProduct(name, pricePerKg, username);
        if (res.StartsWith("success:"))
        {
            string newId = res.Substring("success:".Length);
            return new { success = true, id = newId };
        }
        return new { error = res };
    }

    [WebMethod]
    public static object UpdateProductPrice(string id, double pricePerKg)
    {
        string res = clsScrapProduct.UpdateProductPrice(id, pricePerKg);
        if (res == "success") return new { success = true };
        return new { error = res };
    }

    [WebMethod]
    public static object DeleteProduct(string id)
    {
        string res = clsScrapProduct.DeleteProduct(id);
        if (res == "success") return new { success = true };
        return new { error = res };
    }

    [WebMethod]
    public static object GetWeighbridgeSettings()
    {
        var dt = clsDatabase.GetDataTable("SELECT FactoryId AS Id, FactoryName AS Name FROM FactoryMaster WHERE FactoryName IS NOT NULL AND FactoryName != '' ORDER BY FactoryName");
        var list = new List<object>();
        foreach (DataRow row in dt.Rows)
        {
            string branchId = row["Id"].ToString();
            string name = row["Name"].ToString();
            string key = "ManualWeight_Branch_" + branchId;
            object val = clsSystemSetting.GetSetting(key);
            bool isManualAllowed = val == null || Convert.ToBoolean(val);
            list.Add(new
            {
                id = branchId,
                name = name,
                allowManualWeight = isManualAllowed
            });
        }
        return list;
    }

    [WebMethod]
    public static object UpdateBranchManualWeightSetting(string branchId, bool isManualAllowed)
    {
        string key = "ManualWeight_Branch_" + branchId;
        string res = clsSystemSetting.UpdateSetting(key, isManualAllowed);
        if (res == "success") return new { success = true };
        return new { error = res };
     }
}
