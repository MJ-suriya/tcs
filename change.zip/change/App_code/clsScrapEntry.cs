using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web;
using System.Web.Script.Serialization;

public class clsScrapEntry
{
    public class ScrapItemInput
    {
        public string productId { get; set; }
        public double weight { get; set; }
    }

    public static List<object> GetEntries(string status, string fromDate, string toDate, string username, string userRole)
    {
        var parameters = new List<SqlParameter>();
        string sql = "SELECT Id, CompanyName, VehicleNumber, OwnerName, Status, PettyCashierVerifiedAmount, RejectReason, QueryQuestion, QueryAnswer, ProofDocument, CreatedBy, BranchId, BranchName, CreatedAt, UpdatedAt, ReviewedBy, ReviewedByRole, ReviewedAt FROM ScrapEntries WHERE 1=1";

        if (!string.IsNullOrEmpty(status))
        {
            if (status == "pending")
            {
                sql += " AND (Status = 'pending_pettycashier' OR Status = 'pending_manager' OR Status = 'queried')";
            }
            else
            {
                sql += " AND Status = @Status";
                parameters.Add(new SqlParameter("@Status", status));
            }
        }

        // Role filtering
        if (userRole == "security" || userRole == "pettycashier")
        {
            var userBranch = clsDatabase.ExecuteScalar("SELECT BranchId FROM Users WHERE Username = @Username", new SqlParameter("@Username", username)) as string;
            if (!string.IsNullOrEmpty(userBranch))
            {
                sql += " AND BranchId = @BranchId";
                parameters.Add(new SqlParameter("@BranchId", userBranch));
            }
            else
            {
                sql += " AND CreatedBy = @CreatedBy";
                parameters.Add(new SqlParameter("@CreatedBy", username));
            }
        }

        if (!string.IsNullOrEmpty(fromDate))
        {
            DateTime parsedFrom;
            if (clsDatabase.TryParseDate(fromDate, out parsedFrom))
            {
                sql += " AND CreatedAt >= @FromDate";
                parameters.Add(new SqlParameter("@FromDate", parsedFrom.Date));
            }
        }

        if (!string.IsNullOrEmpty(toDate))
        {
            DateTime parsedTo;
            if (clsDatabase.TryParseDate(toDate, out parsedTo))
            {
                sql += " AND CreatedAt <= @ToDate";
                parameters.Add(new SqlParameter("@ToDate", parsedTo.Date.AddDays(1).AddTicks(-1)));
            }
        }

        sql += " ORDER BY CreatedAt DESC";

        var dt = clsDatabase.GetDataTable(sql, parameters.ToArray());
        var result = new List<object>();

        foreach (DataRow row in dt.Rows)
        {
            string entryId = row["Id"].ToString();

            // Fetch items
            var itemsDt = clsDatabase.GetDataTable("SELECT ProductId, ProductName, Weight, PricePerKg, TotalAmount FROM ScrapEntryItems WHERE ScrapEntryId = @EntryId",
                new SqlParameter("@EntryId", entryId));
            
            var itemsList = new List<object>();
            var productNamesList = new List<string>();
            double totalAmountVal = 0;
            
            string firstProductId = "";
            double firstWeight = 0.0;
            double firstPricePerKg = 0.0;
            
            if (itemsDt.Rows.Count > 0)
            {
                firstProductId = itemsDt.Rows[0]["ProductId"].ToString();
                firstWeight = Convert.ToDouble(itemsDt.Rows[0]["Weight"]);
                firstPricePerKg = Convert.ToDouble(itemsDt.Rows[0]["PricePerKg"]);
            }

            foreach (DataRow itemRow in itemsDt.Rows)
            {
                var itemTotal = Convert.ToDouble(itemRow["TotalAmount"]);
                totalAmountVal += itemTotal;
                string pName = itemRow["ProductName"].ToString();
                productNamesList.Add(pName);
                
                itemsList.Add(new
                {
                    productId = itemRow["ProductId"].ToString(),
                    productName = pName,
                    weight = Convert.ToDouble(itemRow["Weight"]),
                    pricePerKg = Convert.ToDouble(itemRow["PricePerKg"]),
                    totalAmount = itemTotal
                });
            }
            
            string mergedProductNames = string.Join(", ", productNamesList);

            result.Add(new
            {
                _id = entryId,
                id = entryId,
                companyName = row["CompanyName"].ToString(),
                vehicleNumber = row["VehicleNumber"].ToString(),
                ownerName = row["OwnerName"].ToString(),
                productId = firstProductId,
                productName = mergedProductNames,
                weight = firstWeight,
                pricePerKg = firstPricePerKg,
                items = itemsList,
                totalAmount = totalAmountVal,
                status = row["Status"].ToString(),
                pettyCashierVerifiedAmount = row["PettyCashierVerifiedAmount"] == DBNull.Value ? (double?)null : Convert.ToDouble(row["PettyCashierVerifiedAmount"]),
                rejectReason = row["RejectReason"].ToString(),
                queryQuestion = row["QueryQuestion"].ToString(),
                queryAnswer = row["QueryAnswer"].ToString(),
                proofDocument = row["ProofDocument"] == DBNull.Value ? null : row["ProofDocument"].ToString(),
                createdBy = row["CreatedBy"].ToString(),
                branch = row["BranchId"] == DBNull.Value ? null : row["BranchId"].ToString(),
                branchName = row["BranchName"] == DBNull.Value ? "" : row["BranchName"].ToString(),
                createdAt = Convert.ToDateTime(row["CreatedAt"]).ToString("yyyy-MM-ddTHH:mm:ss"),
                updatedAt = Convert.ToDateTime(row["UpdatedAt"]).ToString("yyyy-MM-ddTHH:mm:ss"),
                reviewedBy = row["ReviewedBy"] == DBNull.Value ? null : row["ReviewedBy"].ToString(),
                reviewedByRole = row["ReviewedByRole"] == DBNull.Value ? "" : row["ReviewedByRole"].ToString(),
                reviewedAt = row["ReviewedAt"] == DBNull.Value ? null : Convert.ToDateTime(row["ReviewedAt"]).ToString("yyyy-MM-ddTHH:mm:ss")
            });
        }

        return result;
    }

    public static string CreateScrapEntry(
        string companyName, string vehicleNumber, string ownerName, string branchId, string branchName,
        string dateTime, string description, string itemsJson, string proofDocumentBase64, string proofDocumentFileName,
        string username, string userRole)
    {
        List<ScrapItemInput> itemsInput = null;
        var serializer = new JavaScriptSerializer();
        if (!string.IsNullOrEmpty(itemsJson))
        {
            try
            {
                itemsInput = serializer.Deserialize<List<ScrapItemInput>>(itemsJson);
            }
            catch
            {
                return "Invalid items format";
            }
        }

        if (string.IsNullOrWhiteSpace(companyName) || string.IsNullOrWhiteSpace(vehicleNumber) || itemsInput == null || itemsInput.Count == 0)
        {
            return "Company Name, Vehicle Number, and at least one Product are required";
        }

        var resolvedItems = new List<Dictionary<string, object>>();
        double grandTotal = 0;

        foreach (var item in itemsInput)
        {
            if (string.IsNullOrEmpty(item.productId) || item.weight <= 0)
            {
                return "Each item must have a product and a positive weight";
            }

            var prodDt = clsDatabase.GetDataTable("SELECT Name, PricePerKg FROM ScrapProducts WHERE Id = @Id", new SqlParameter("@Id", item.productId));
            if (prodDt.Rows.Count == 0)
            {
                return "Product not found: " + item.productId;
            }

            var prodRow = prodDt.Rows[0];
            double price = Convert.ToDouble(prodRow["PricePerKg"]);
            double itemTotal = Math.Round(item.weight * price, 2);
            grandTotal += itemTotal;

            resolvedItems.Add(new Dictionary<string, object>
            {
                { "productId", item.productId },
                { "productName", prodRow["Name"].ToString() },
                { "weight", item.weight },
                { "pricePerKg", price },
                { "totalAmount", itemTotal }
            });
        }

        var firstItem = resolvedItems[0];
        bool isPetty = userRole == "pettycashier";

        DateTime entryDate = DateTime.UtcNow;
        if (!string.IsNullOrEmpty(dateTime))
        {
            DateTime parsed;
            if (clsDatabase.TryParseDate(dateTime, out parsed))
            {
                entryDate = parsed;
            }
        }

        string newEntryId = Guid.NewGuid().ToString();
        string savedProofPath = null;

        // Handle Base64 Upload
        if (isPetty && !string.IsNullOrEmpty(proofDocumentBase64))
        {
            try
            {
                string base64Data = proofDocumentBase64;
                if (base64Data.Contains(","))
                {
                    base64Data = base64Data.Substring(base64Data.IndexOf(",") + 1);
                }
                byte[] fileBytes = Convert.FromBase64String(base64Data);
                string ext = Path.GetExtension(proofDocumentFileName);
                string uniqueName = string.Format("{0}_{1}{2}", DateTime.UtcNow.Ticks, Guid.NewGuid().ToString().Substring(0, 8), ext);
                string uploadDir = HttpContext.Current.Server.MapPath("~/uploads/scrap");
                if (!Directory.Exists(uploadDir))
                {
                    Directory.CreateDirectory(uploadDir);
                }
                string filePath = Path.Combine(uploadDir, uniqueName);
                File.WriteAllBytes(filePath, fileBytes);
                savedProofPath = "uploads/scrap/" + uniqueName;
            }
            catch (Exception ex)
            {
                return "File upload failed: " + ex.Message;
            }
        }

        using (var conn = clsDatabase.GetConnection())
        {
            using (var trans = conn.BeginTransaction())
            {
                try
                {
                    string sql =
                        "INSERT INTO ScrapEntries (Id, CompanyName, VehicleNumber, OwnerName, Status, PettyCashierVerifiedAmount, RejectReason, QueryQuestion, QueryAnswer, ProofDocument, CreatedBy, BranchId, BranchName, CreatedAt, UpdatedAt, ReviewedBy, ReviewedByRole, ReviewedAt) " +
                        "VALUES (@Id, @CompanyName, @VehicleNumber, @OwnerName, @Status, @VerifiedAmount, '', '', '', @ProofDocument, @CreatedBy, @BranchId, @BranchName, @CreatedAt, @UpdatedAt, NULL, NULL, NULL)";

                    using (var cmd = new SqlCommand(sql, conn, trans))
                    {
                        cmd.Parameters.AddWithValue("@Id", newEntryId);
                        cmd.Parameters.AddWithValue("@CompanyName", companyName.Trim());
                        cmd.Parameters.AddWithValue("@VehicleNumber", vehicleNumber.Trim().ToUpperInvariant());
                        cmd.Parameters.AddWithValue("@OwnerName", string.IsNullOrEmpty(ownerName) ? "—" : ownerName.Trim());
                        cmd.Parameters.AddWithValue("@Status", isPetty ? "pending_manager" : "pending_pettycashier");
                        cmd.Parameters.AddWithValue("@VerifiedAmount", isPetty ? (object)Math.Round(grandTotal, 2) : DBNull.Value);
                        cmd.Parameters.AddWithValue("@ProofDocument", (object)savedProofPath ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("@CreatedBy", username);
                        cmd.Parameters.AddWithValue("@BranchId", string.IsNullOrEmpty(branchId) ? DBNull.Value : (object)branchId);
                        cmd.Parameters.AddWithValue("@BranchName", string.IsNullOrEmpty(branchName) ? DBNull.Value : (object)branchName);
                        cmd.Parameters.AddWithValue("@CreatedAt", entryDate);
                        cmd.Parameters.AddWithValue("@UpdatedAt", DateTime.UtcNow);

                        cmd.ExecuteNonQuery();
                    }

                    // Insert resolved items
                    foreach (var item in resolvedItems)
                    {
                        string itemSql = "INSERT INTO ScrapEntryItems (Id, ScrapEntryId, ProductId, ProductName, Weight, PricePerKg, TotalAmount) VALUES (@Id, @ScrapEntryId, @ProductId, @ProductName, @Weight, @PricePerKg, @TotalAmount)";
                        using (var cmd = new SqlCommand(itemSql, conn, trans))
                        {
                            cmd.Parameters.AddWithValue("@Id", Guid.NewGuid().ToString());
                            cmd.Parameters.AddWithValue("@ScrapEntryId", newEntryId);
                            cmd.Parameters.AddWithValue("@ProductId", item["productId"].ToString());
                            cmd.Parameters.AddWithValue("@ProductName", item["productName"].ToString());
                            cmd.Parameters.AddWithValue("@Weight", item["weight"]);
                            cmd.Parameters.AddWithValue("@PricePerKg", item["pricePerKg"]);
                            cmd.Parameters.AddWithValue("@TotalAmount", item["totalAmount"]);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    trans.Commit();
                }
                catch (Exception)
                {
                    trans.Rollback();
                    throw;
                }
            }
        }

        return "success:" + newEntryId;
    }

    public static string VerifyScrapEntry(string id, double verifiedAmount, string proofDocumentBase64, string proofDocumentFileName)
    {
        var entryDt = clsDatabase.GetDataTable("SELECT Status FROM ScrapEntries WHERE Id = @Id", new SqlParameter("@Id", id));
        if (entryDt.Rows.Count == 0) return "Entry not found";

        var row = entryDt.Rows[0];
        if (row["Status"].ToString() != "pending_pettycashier")
        {
            return "Entry is not pending petty cashier verification";
        }

        var amountObj = clsDatabase.ExecuteScalar("SELECT ISNULL(SUM(TotalAmount), 0) FROM ScrapEntryItems WHERE ScrapEntryId = @Id", new SqlParameter("@Id", id));
        double total = Convert.ToDouble(amountObj);
        if (Math.Abs(verifiedAmount - total) > 0.01)
        {
            return "Entered amount does not match the scrap entry total amount";
        }

        string savedProofPath = null;
        if (!string.IsNullOrEmpty(proofDocumentBase64))
        {
            try
            {
                string base64Data = proofDocumentBase64;
                if (base64Data.Contains(","))
                {
                    base64Data = base64Data.Substring(base64Data.IndexOf(",") + 1);
                }
                byte[] fileBytes = Convert.FromBase64String(base64Data);
                string ext = Path.GetExtension(proofDocumentFileName);
                string uniqueName = string.Format("{0}_{1}{2}", DateTime.UtcNow.Ticks, Guid.NewGuid().ToString().Substring(0, 8), ext);
                string uploadDir = HttpContext.Current.Server.MapPath("~/uploads/scrap");
                if (!Directory.Exists(uploadDir))
                {
                    Directory.CreateDirectory(uploadDir);
                }
                string filePath = Path.Combine(uploadDir, uniqueName);
                File.WriteAllBytes(filePath, fileBytes);
                savedProofPath = "uploads/scrap/" + uniqueName;
            }
            catch (Exception ex)
            {
                return "File upload failed: " + ex.Message;
            }
        }

        string updateSql = "UPDATE ScrapEntries SET PettyCashierVerifiedAmount = @VerifiedAmount, Status = 'pending_manager', UpdatedAt = @UpdatedAt";
        var parameters = new List<SqlParameter>
        {
            new SqlParameter("@VerifiedAmount", verifiedAmount),
            new SqlParameter("@UpdatedAt", DateTime.UtcNow),
            new SqlParameter("@Id", id)
        };

        if (savedProofPath != null)
        {
            updateSql += ", ProofDocument = @ProofDocument";
            parameters.Add(new SqlParameter("@ProofDocument", savedProofPath));
        }

        updateSql += " WHERE Id = @Id AND Status = 'pending_pettycashier'";

        int rows = clsDatabase.ExecuteNonQuery(updateSql, parameters.ToArray());
        if (rows == 0) return "Entry not found or already verified";
        return "success";
    }

    public static string QueryEntry(string id, string question)
    {
        if (string.IsNullOrWhiteSpace(question)) return "Query question is required";

        int rows = clsDatabase.ExecuteNonQuery(
            "UPDATE ScrapEntries SET Status = 'queried', QueryQuestion = @Question, QueryAnswer = '', UpdatedAt = @UpdatedAt WHERE Id = @Id AND Status = 'pending_manager'",
            new SqlParameter("@Question", question.Trim()),
            new SqlParameter("@UpdatedAt", DateTime.UtcNow),
            new SqlParameter("@Id", id)
        );

        if (rows == 0) return "Entry not found or not in pending manager status";
        return "success";
    }

    public static string AnswerEntryQuery(string id, string answer)
    {
        if (string.IsNullOrWhiteSpace(answer)) return "Answer is required";

        int rows = clsDatabase.ExecuteNonQuery(
            "UPDATE ScrapEntries SET Status = 'pending_manager', QueryAnswer = @Answer, UpdatedAt = @UpdatedAt WHERE Id = @Id AND Status = 'queried'",
            new SqlParameter("@Answer", answer.Trim()),
            new SqlParameter("@UpdatedAt", DateTime.UtcNow),
            new SqlParameter("@Id", id)
        );

        if (rows == 0) return "Entry not found or not in queried status";
        return "success";
    }

    public static string ApproveEntry(string id, string username, string userRole)
    {
        int rows = clsDatabase.ExecuteNonQuery(
            "UPDATE ScrapEntries SET Status = 'approved', ReviewedBy = @ReviewedBy, ReviewedByRole = @ReviewedRole, ReviewedAt = @ReviewedAt, UpdatedAt = @UpdatedAt WHERE Id = @Id AND Status = 'pending_manager'",
            new SqlParameter("@ReviewedBy", username),
            new SqlParameter("@ReviewedRole", userRole),
            new SqlParameter("@ReviewedAt", DateTime.UtcNow),
            new SqlParameter("@UpdatedAt", DateTime.UtcNow),
            new SqlParameter("@Id", id)
        );

        if (rows == 0) return "Entry not found or not in pending manager status";
        return "success";
    }

    public static string RejectEntry(string id, string reason, string username, string userRole)
    {
        int rows = clsDatabase.ExecuteNonQuery(
            "UPDATE ScrapEntries SET Status = 'rejected', RejectReason = @Reason, ReviewedBy = @ReviewedBy, ReviewedByRole = @ReviewedRole, ReviewedAt = @ReviewedAt, UpdatedAt = @UpdatedAt WHERE Id = @Id AND Status = 'pending_manager'",
            new SqlParameter("@Reason", reason ?? ""),
            new SqlParameter("@ReviewedBy", username),
            new SqlParameter("@ReviewedRole", userRole),
            new SqlParameter("@ReviewedAt", DateTime.UtcNow),
            new SqlParameter("@UpdatedAt", DateTime.UtcNow),
            new SqlParameter("@Id", id)
        );

        if (rows == 0) return "Entry not found or not in pending manager status";
        return "success";
    }

    public static object GetDashboard(string username, string userRole)
    {
        var parameters = new List<SqlParameter>();
        string sqlCount = "SELECT COUNT(*) FROM ScrapEntries WHERE 1=1";
        string sqlPending = "SELECT COUNT(*) FROM ScrapEntries WHERE (Status = 'pending_pettycashier' OR Status = 'pending_manager' OR Status = 'queried')";
        string sqlApproved = "SELECT COUNT(*) FROM ScrapEntries WHERE Status = 'approved'";
        string sqlSum = "SELECT ISNULL(SUM(PettyCashierVerifiedAmount), 0) FROM ScrapEntries WHERE Status = 'approved'";

        if (userRole != "admin")
        {
            var branchId = clsDatabase.ExecuteScalar("SELECT BranchId FROM Users WHERE Username = @Username", new SqlParameter("@Username", username)) as string;
            if (!string.IsNullOrEmpty(branchId))
            {
                string filter = " AND BranchId = @BranchId";
                sqlCount += filter;
                sqlPending += filter;
                sqlApproved += filter;
                sqlSum += filter;
                parameters.Add(new SqlParameter("@BranchId", branchId));
            }
        }

        int totalEntries = (int)clsDatabase.ExecuteScalar(sqlCount, CopyParameters(parameters));
        int pendingApprovals = (int)clsDatabase.ExecuteScalar(sqlPending, CopyParameters(parameters));
        int approvedEntries = (int)clsDatabase.ExecuteScalar(sqlApproved, CopyParameters(parameters));
        double totalScrapValue = Convert.ToDouble(clsDatabase.ExecuteScalar(sqlSum, CopyParameters(parameters)));

        return new
        {
            totalEntries = totalEntries,
            pendingApprovals = pendingApprovals,
            approvedEntries = approvedEntries,
            totalScrapValue = Math.Round(totalScrapValue, 2)
        };
    }

    private static SqlParameter[] CopyParameters(List<SqlParameter> parameters)
    {
        var copy = new SqlParameter[parameters.Count];
        for (int i = 0; i < parameters.Count; i++)
        {
            copy[i] = new SqlParameter(parameters[i].ParameterName, parameters[i].Value);
        }
        return copy;
    }
}
