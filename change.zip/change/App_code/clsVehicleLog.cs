using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

public class clsVehicleLog
{
    public class ExpenseInput
    {
        public string expenseType { get; set; }
        public double amount { get; set; }
        public string date { get; set; }
        public string description { get; set; }
    }

    public static Dictionary<string, object> GetVehicleBaseline(string vehicleNumber)
    {
        var normalizedVehicle = vehicleNumber.Trim().ToUpperInvariant();
        if (string.IsNullOrEmpty(normalizedVehicle))
        {
            return new Dictionary<string, object>
            {
                { "startKm", 0.0 },
                { "availableFuel", 0.0 },
                { "expectedMileage", (double?)null },
                { "tankCapacity", 0.0 },
                { "previousFuelOdometer", 0.0 },
                { "tripDistanceSum", 0.0 },
                { "approxFuelUsed", 0.0 },
                { "lastApprovedEndDateTime", (DateTime?)null }
            };
        }

        var profile = clsVehicleProfile.FindMatchedProfile(normalizedVehicle);
        var vehicleList = clsVehicleProfile.GetAlternativeVehicleNumbers(normalizedVehicle);
        string listClause = string.Join("','", vehicleList.ToArray());

        // Last non-rejected log
        var lastApprovedDt = clsDatabase.GetDataTable(
            string.Format("SELECT TOP 1 EndKm, RemainingFuel, EndDateTime FROM VehicleLogs WHERE VehicleNumber IN ('{0}') AND Status != 'rejected' ORDER BY EndDateTime DESC, CreatedAt DESC", listClause)
        );

        // Last non-rejected fuel log (fuelAdded > 0)
        var lastFuelLogDt = clsDatabase.GetDataTable(
            string.Format("SELECT TOP 1 StartDateTime, EndKm FROM VehicleLogs WHERE VehicleNumber IN ('{0}') AND Status != 'rejected' AND FuelAdded > 0 ORDER BY StartDateTime DESC, CreatedAt DESC", listClause)
        );

        double profileOpeningKm = profile != null ? Convert.ToDouble(profile["openingKm"]) : 0.0;
        double profileOpeningFuel = profile != null ? Convert.ToDouble(profile["openingFuel"]) : 0.0;
        double profileTankCapacity = profile != null ? Convert.ToDouble(profile["tankCapacity"]) : 0.0;
        double? profileExpectedMileage = profile != null ? (double?)profile["expectedMileage"] : null;

        double previousFuelOdometer = profileOpeningKm;
        DateTime lastFuelLogDate = DateTime.MinValue;

        if (lastFuelLogDt.Rows.Count > 0)
        {
            previousFuelOdometer = Convert.ToDouble(lastFuelLogDt.Rows[0]["EndKm"]);
            lastFuelLogDate = Convert.ToDateTime(lastFuelLogDt.Rows[0]["StartDateTime"]);
        }
        else
        {
            // If no prior fuel logs exist, fall back to the very first trip's StartKm to capture all distance travelled
            var oldestLogDt = clsDatabase.GetDataTable(
                string.Format("SELECT TOP 1 StartKm FROM VehicleLogs WHERE VehicleNumber IN ('{0}') ORDER BY StartDateTime ASC, CreatedAt ASC", listClause)
            );
            if (oldestLogDt.Rows.Count > 0)
            {
                previousFuelOdometer = Convert.ToDouble(oldestLogDt.Rows[0]["StartKm"]);
            }
        }

        // Find all non-rejected trip logs with fuelAdded == 0 after lastFuelLogDate
        var tripsDt = clsDatabase.GetDataTable(
            string.Format("SELECT DistanceTravelled FROM VehicleLogs WHERE VehicleNumber IN ('{0}') AND Status != 'rejected' AND FuelAdded = 0 AND StartDateTime > @LastFuelDate", listClause),
            new SqlParameter("@LastFuelDate", lastFuelLogDate)
        );

        double tripDistanceSum = 0.0;
        foreach (DataRow row in tripsDt.Rows)
        {
            tripDistanceSum += Convert.ToDouble(row["DistanceTravelled"]);
        }

        double approxFuelUsed = (profileExpectedMileage.HasValue && profileExpectedMileage.Value > 0)
            ? Math.Round(tripDistanceSum / profileExpectedMileage.Value, 2)
            : 0.0;

        if (lastApprovedDt.Rows.Count == 0)
        {
            double capacity = profileTankCapacity;
            return new Dictionary<string, object>
            {
                { "startKm", profileOpeningKm },
                { "availableFuel", capacity > 0 ? capacity : profileOpeningFuel },
                { "expectedMileage", profileExpectedMileage },
                { "tankCapacity", capacity },
                { "previousFuelOdometer", previousFuelOdometer },
                { "tripDistanceSum", tripDistanceSum },
                { "approxFuelUsed", approxFuelUsed },
                { "lastApprovedEndDateTime", (DateTime?)null }
            };
        }

        var lastApprovedRow = lastApprovedDt.Rows[0];
        return new Dictionary<string, object>
        {
            { "startKm", Convert.ToDouble(lastApprovedRow["EndKm"]) },
            { "availableFuel", Convert.ToDouble(lastApprovedRow["RemainingFuel"]) },
            { "expectedMileage", profileExpectedMileage },
            { "tankCapacity", profileTankCapacity },
            { "previousFuelOdometer", previousFuelOdometer },
            { "tripDistanceSum", tripDistanceSum },
            { "approxFuelUsed", approxFuelUsed },
            { "lastApprovedEndDateTime", (DateTime?)Convert.ToDateTime(lastApprovedRow["EndDateTime"]) }
        };
    }

    public static string CreateVehicleLog(
        string driverName, string vehicleNumber, string fromLocation, string toLocation,
        DateTime startDateTime, DateTime? endDateTime, double endKm, double fuelAdded, double? remainingFuel,
        string fuelType, double? pricePerLitre, string mileageReason, string branchId, string branchName,
        List<ExpenseInput> expenses, string correctedFromLogId, string username, string draftId)
    {
        try
        {
            if (string.IsNullOrEmpty(driverName) || string.IsNullOrEmpty(vehicleNumber) ||
                string.IsNullOrEmpty(fromLocation) || string.IsNullOrEmpty(toLocation) || startDateTime == default(DateTime))
            {
                return "Driver, vehicle, locations, and date/time fields are required";
            }

            // Get baseline
            var baseline = GetVehicleBaseline(vehicleNumber);

            double baselineStartKm = Convert.ToDouble(baseline["startKm"]);
            double baselineAvailableFuel = Convert.ToDouble(baseline["availableFuel"]);
            double baselineTankCapacity = Convert.ToDouble(baseline["tankCapacity"]);
            DateTime? lastApprovedEndDateTime = baseline["lastApprovedEndDateTime"] as DateTime?;

            DateTime endDt = endDateTime ?? startDateTime;
            if (endDateTime.HasValue && endDateTime.Value < startDateTime)
            {
                return "End Date & Time cannot be before Start Date & Time";
            }

            if (lastApprovedEndDateTime.HasValue && startDateTime < lastApprovedEndDateTime.Value)
            {
                string formattedLastEnd = lastApprovedEndDateTime.Value.ToString("dd-MMM-yyyy hh:mm tt");
                return string.Format("Start Date & Time cannot be before the last approved trip's end Date & Time ({0})", formattedLastEnd);
            }

            if (endKm < baselineStartKm)
            {
                return string.Format("End KM must be greater than or equal to start KM ({0})", baselineStartKm);
            }

            bool isFuelLog = driverName.Trim().ToLowerInvariant() == "fuel log";

            double tripDistance = endKm - baselineStartKm;
            double finalRemainingFuel = 0.0;
            double fuelUsed = 0.0;
            double? mileage = null;
            bool isLowFuel = false;
            DateTime? fuelFillDate = null;

            bool hasFuelAdded = fuelAdded > 0;

            if (hasFuelAdded)
            {
                fuelFillDate = endDt;
                double tankCap = baselineTankCapacity > 0 ? baselineTankCapacity : 35.0;
                finalRemainingFuel = tankCap;
                fuelUsed = fuelAdded;

                double prevOdo = Convert.ToDouble(baseline["previousFuelOdometer"]);
                double totalDistanceSinceLastFuel = endKm - prevOdo;
                if (fuelAdded > 0)
                {
                    mileage = Math.Round(totalDistanceSinceLastFuel / fuelAdded, 2);
                }
            }
            else
            {
                if (remainingFuel.HasValue && remainingFuel.Value < 0)
                {
                    return "Remaining fuel must be zero or positive";
                }

                if (remainingFuel.HasValue)
                {
                    fuelUsed = baselineAvailableFuel - remainingFuel.Value;
                    if (fuelUsed < 0) fuelUsed = 0.0;
                    finalRemainingFuel = remainingFuel.Value;
                    fuelUsed = Math.Round(fuelUsed, 2);
                }
                else
                {
                    // Estimate fuel used based on standard (expected) mileage
                    double? expectedMileage = baseline["expectedMileage"] != null ? (double?)baseline["expectedMileage"] : null;
                    double estimatedFuelUsed = (expectedMileage.HasValue && expectedMileage.Value > 0)
                        ? (tripDistance / expectedMileage.Value)
                        : 0.0;

                    fuelUsed = Math.Round(estimatedFuelUsed, 2);
                    finalRemainingFuel = baselineAvailableFuel - fuelUsed;
                    if (finalRemainingFuel < 0) finalRemainingFuel = 0.0;
                    mileage = null; // No actual mileage for intermediate trip logs without manual fuel reading
                }

                double tankCap = baselineTankCapacity > 0 ? baselineTankCapacity : 35.0;
                if (finalRemainingFuel > tankCap) finalRemainingFuel = tankCap;

                isLowFuel = finalRemainingFuel <= 2.0;
            }

            string newLogId = Guid.NewGuid().ToString();

            using (var conn = clsDatabase.GetConnection())
            {
                using (var trans = conn.BeginTransaction())
                {
                    try
                    {
                        // Insert main log
                        string insertLogSql =
                            "INSERT INTO VehicleLogs (Id, DriverName, VehicleNumber, FromLocation, ToLocation, StartDateTime, EndDateTime, StartKm, EndKm, DistanceTravelled, AvailableFuel, FuelAdded, RemainingFuel, FuelFillDate, FuelUsed, Mileage, MileageReason, IsLowFuel, FuelType, PricePerLitre, CorrectedFromLogId, CorrectedByLogId, Status, RejectReason, QueryQuestion, QueryAnswer, CreatedBy, BranchId, BranchName, CreatedAt, UpdatedAt) " +
                            "VALUES (@Id, @DriverName, @VehicleNumber, @FromLocation, @ToLocation, @StartDateTime, @EndDateTime, @StartKm, @EndKm, @DistanceTravelled, @AvailableFuel, @FuelAdded, @RemainingFuel, @FuelFillDate, @FuelUsed, @Mileage, @MileageReason, @IsLowFuel, @FuelType, @PricePerLitre, @CorrectedFromLogId, NULL, 'pending', '', '', '', @CreatedBy, @BranchId, @BranchName, @CreatedAt, @UpdatedAt)";

                        using (var cmd = new SqlCommand(insertLogSql, conn, trans))
                        {
                            cmd.Parameters.AddWithValue("@Id", newLogId);
                            cmd.Parameters.AddWithValue("@DriverName", driverName.Trim());
                            cmd.Parameters.AddWithValue("@VehicleNumber", vehicleNumber.Trim().ToUpperInvariant());
                            cmd.Parameters.AddWithValue("@FromLocation", fromLocation.Trim());
                            cmd.Parameters.AddWithValue("@ToLocation", toLocation.Trim());
                            cmd.Parameters.AddWithValue("@StartDateTime", startDateTime);
                            cmd.Parameters.AddWithValue("@EndDateTime", endDt);
                            cmd.Parameters.AddWithValue("@StartKm", baselineStartKm);
                            cmd.Parameters.AddWithValue("@EndKm", endKm);
                            cmd.Parameters.AddWithValue("@DistanceTravelled", tripDistance);
                            cmd.Parameters.AddWithValue("@AvailableFuel", baselineAvailableFuel);
                            cmd.Parameters.AddWithValue("@FuelAdded", fuelAdded);
                            cmd.Parameters.AddWithValue("@RemainingFuel", finalRemainingFuel);
                            cmd.Parameters.AddWithValue("@FuelFillDate", (object)fuelFillDate ?? DBNull.Value);
                            cmd.Parameters.AddWithValue("@FuelUsed", fuelUsed);
                            cmd.Parameters.AddWithValue("@Mileage", mileage.HasValue ? (object)mileage.Value : DBNull.Value);
                            cmd.Parameters.AddWithValue("@MileageReason", mileageReason != null ? mileageReason.Trim() : "");
                            cmd.Parameters.AddWithValue("@IsLowFuel", isLowFuel);
                            cmd.Parameters.AddWithValue("@FuelType", string.IsNullOrEmpty(fuelType) ? DBNull.Value : (object)fuelType);
                            cmd.Parameters.AddWithValue("@PricePerLitre", pricePerLitre.HasValue ? (object)pricePerLitre.Value : DBNull.Value);
                            cmd.Parameters.AddWithValue("@CorrectedFromLogId", string.IsNullOrEmpty(correctedFromLogId) ? DBNull.Value : (object)correctedFromLogId);
                            cmd.Parameters.AddWithValue("@CreatedBy", username ?? "security");
                            cmd.Parameters.AddWithValue("@BranchId", string.IsNullOrEmpty(branchId) ? DBNull.Value : (object)branchId);
                            cmd.Parameters.AddWithValue("@BranchName", string.IsNullOrEmpty(branchName) ? DBNull.Value : (object)branchName);
                            cmd.Parameters.AddWithValue("@CreatedAt", DateTime.UtcNow);
                            cmd.Parameters.AddWithValue("@UpdatedAt", DateTime.UtcNow);

                            cmd.ExecuteNonQuery();
                        }

                        // Insert expenses
                        if (expenses != null && expenses.Count > 0)
                        {
                            foreach (var exp in expenses)
                            {
                                string expSql = "INSERT INTO VehicleLogExpenses (Id, VehicleLogId, ExpenseType, Amount, Date, Description) VALUES (@Id, @VehicleLogId, @ExpenseType, @Amount, @Date, @Description)";
                                using (var cmd = new SqlCommand(expSql, conn, trans))
                                {
                                    cmd.Parameters.AddWithValue("@Id", Guid.NewGuid().ToString());
                                    cmd.Parameters.AddWithValue("@VehicleLogId", newLogId);
                                    cmd.Parameters.AddWithValue("@ExpenseType", exp.expenseType.Trim().ToLowerInvariant());
                                    cmd.Parameters.AddWithValue("@Amount", exp.amount);
                                    DateTime expDtVal;
                                    if (!clsDatabase.TryParseDate(exp.date, out expDtVal))
                                    {
                                        expDtVal = DateTime.UtcNow;
                                    }
                                    cmd.Parameters.AddWithValue("@Date", expDtVal);
                                    cmd.Parameters.AddWithValue("@Description", exp.description != null ? exp.description.Trim() : "");
                                    cmd.ExecuteNonQuery();
                                }
                            }
                        }

                        // Add fuel cost to expenses if fuel was added and price is set
                        if (fuelAdded > 0 && pricePerLitre.HasValue && pricePerLitre.Value > 0)
                        {
                            double fuelCost = Math.Round(fuelAdded * pricePerLitre.Value, 2);
                            string expSql = "INSERT INTO VehicleLogExpenses (Id, VehicleLogId, ExpenseType, Amount, Date, Description) VALUES (@Id, @VehicleLogId, @ExpenseType, @Amount, @Date, @Description)";
                            using (var cmd = new SqlCommand(expSql, conn, trans))
                            {
                                cmd.Parameters.AddWithValue("@Id", Guid.NewGuid().ToString());
                                cmd.Parameters.AddWithValue("@VehicleLogId", newLogId);
                                cmd.Parameters.AddWithValue("@ExpenseType", string.IsNullOrEmpty(fuelType) ? "fuel" : fuelType.Trim().ToLowerInvariant());
                                cmd.Parameters.AddWithValue("@Amount", fuelCost);
                                cmd.Parameters.AddWithValue("@Date", endDt);
                                cmd.Parameters.AddWithValue("@Description", string.Format("Refilled {0:F2} L of {1} at ₹{2:F2}/L", fuelAdded, string.IsNullOrEmpty(fuelType) ? "fuel" : fuelType, pricePerLitre.Value));
                                cmd.ExecuteNonQuery();
                            }
                        }

                        // Handle corrections
                        if (!string.IsNullOrEmpty(correctedFromLogId))
                        {
                            string updateOrig = "UPDATE VehicleLogs SET CorrectedByLogId = @NewLogId WHERE Id = @OrigId AND Status = 'rejected' AND CreatedBy = @CreatedBy";
                            using (var cmd = new SqlCommand(updateOrig, conn, trans))
                            {
                                cmd.Parameters.AddWithValue("@NewLogId", newLogId);
                                cmd.Parameters.AddWithValue("@OrigId", correctedFromLogId);
                                cmd.Parameters.AddWithValue("@CreatedBy", username ?? "security");
                                cmd.ExecuteNonQuery();
                            }
                        }

                        // Delete draft if it was submitted
                        if (!string.IsNullOrEmpty(draftId))
                        {
                            string delDraft = "DELETE FROM VehicleLogDrafts WHERE Id = @DraftId AND CreatedBy = @CreatedBy";
                            using (var cmd = new SqlCommand(delDraft, conn, trans))
                            {
                                cmd.Parameters.AddWithValue("@DraftId", draftId);
                                cmd.Parameters.AddWithValue("@CreatedBy", username ?? "security");
                                cmd.ExecuteNonQuery();
                            }
                        }

                        trans.Commit();
                    }
                    catch (Exception)
                    {
                        trans.Rollback();
                        throw;
                    }
                }
            }

            // Copy Emergency Expenses (standalone expenses) and Sync Profile opening KM
            var finalLog = GetLogById(newLogId);
            CopyEmergencyExpenses(finalLog);
            clsVehicleProfile.SyncVehicleProfileOpeningKm(vehicleNumber);

            return "success:" + newLogId;
        }
        catch (Exception ex)
        {
            return ex.Message;
        }
    }

    private static void CopyEmergencyExpenses(Dictionary<string, object> log)
    {
        try
        {
            string logId = log["id"].ToString();
            var expensesDt = clsDatabase.GetDataTable("SELECT ExpenseType, Amount, Date, Description FROM VehicleLogExpenses WHERE VehicleLogId = @LogId",
                new SqlParameter("@LogId", logId));

            foreach (DataRow row in expensesDt.Rows)
            {
                string desc = row["Description"].ToString();
                if (string.IsNullOrEmpty(desc) || !desc.StartsWith("FUEL_ADDITION:"))
                {
                    clsDatabase.ExecuteNonQuery(
                        "INSERT INTO VehicleExpenses (Id, VehicleNumber, ExpenseType, Amount, Date, Description, Status, RejectReason, QueryQuestion, QueryAnswer, CreatedBy, CreatedAt) " +
                        "VALUES (@Id, @VehicleNumber, @ExpenseType, @Amount, @Date, @Description, 'pending', '', '', '', @CreatedBy, @CreatedAt)",
                        new SqlParameter("@Id", Guid.NewGuid().ToString()),
                        new SqlParameter("@VehicleNumber", log["vehicleNumber"].ToString()),
                        new SqlParameter("@ExpenseType", row["ExpenseType"].ToString()),
                        new SqlParameter("@Amount", Convert.ToDouble(row["Amount"])),
                        new SqlParameter("@Date", Convert.ToDateTime(row["Date"])),
                        new SqlParameter("@Description", desc),
                        new SqlParameter("@CreatedBy", log["createdBy"].ToString()),
                        new SqlParameter("@CreatedAt", DateTime.UtcNow)
                    );
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Failed to copy emergency expenses: " + ex.Message);
        }
    }

    public static Dictionary<string, object> GetLogById(string id)
    {
        var dt = clsDatabase.GetDataTable("SELECT Id, DriverName, VehicleNumber, FromLocation, ToLocation, StartDateTime, EndDateTime, StartKm, EndKm, DistanceTravelled, AvailableFuel, FuelAdded, RemainingFuel, FuelFillDate, FuelUsed, Mileage, MileageReason, IsLowFuel, FuelType, PricePerLitre, CorrectedFromLogId, CorrectedByLogId, Status, CreatedBy, ReviewedBy, ReviewedAt, BranchId, BranchName, CreatedAt, UpdatedAt FROM VehicleLogs WHERE Id = @Id",
            new SqlParameter("@Id", id));
        if (dt.Rows.Count == 0) return null;

        var row = dt.Rows[0];
        return new Dictionary<string, object>
        {
            { "id", row["Id"].ToString() },
            { "driverName", row["DriverName"].ToString() },
            { "vehicleNumber", row["VehicleNumber"].ToString() },
            { "createdBy", row["CreatedBy"].ToString() }
        };
    }

    public static List<object> GetWaitingList(string username)
    {
        var dt = clsDatabase.GetDataTable(
            "SELECT Id, DriverName, VehicleNumber, FromLocation, ToLocation, StartDateTime, EndDateTime, EndKm, FuelAdded, RemainingFuel, FuelType, PricePerLitre, CorrectedFromLogId, CreatedBy, BranchId, BranchName, CreatedAt, UpdatedAt FROM VehicleLogDrafts WHERE CreatedBy = @CreatedBy ORDER BY UpdatedAt DESC",
            new SqlParameter("@CreatedBy", username));

        var list = new List<object>();
        foreach (DataRow row in dt.Rows)
        {
            string draftId = row["Id"].ToString();

            // Fetch draft expenses
            var expDt = clsDatabase.GetDataTable("SELECT ExpenseType, Amount, Date, Description FROM VehicleLogDraftExpenses WHERE VehicleLogDraftId = @DraftId",
                new SqlParameter("@DraftId", draftId));
            var expenses = new List<object>();
            foreach (DataRow eRow in expDt.Rows)
            {
                expenses.Add(new
                {
                    expenseType = eRow["ExpenseType"].ToString(),
                    amount = Convert.ToDouble(eRow["Amount"]),
                    date = Convert.ToDateTime(eRow["Date"]),
                    description = eRow["Description"].ToString()
                });
            }

            list.Add(new
            {
                _id = draftId,
                id = draftId,
                driverName = row["DriverName"].ToString(),
                vehicleNumber = row["VehicleNumber"].ToString(),
                fromLocation = row["FromLocation"].ToString(),
                toLocation = row["ToLocation"].ToString(),
                startDateTime = row["StartDateTime"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(row["StartDateTime"]),
                endDateTime = row["EndDateTime"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(row["EndDateTime"]),
                endKm = row["EndKm"] == DBNull.Value ? (double?)null : Convert.ToDouble(row["EndKm"]),
                fuelAdded = Convert.ToDouble(row["FuelAdded"]),
                remainingFuel = row["RemainingFuel"] == DBNull.Value ? (double?)null : Convert.ToDouble(row["RemainingFuel"]),
                fuelType = row["FuelType"] == DBNull.Value ? null : row["FuelType"].ToString(),
                pricePerLitre = row["PricePerLitre"] == DBNull.Value ? (double?)null : Convert.ToDouble(row["PricePerLitre"]),
                correctedFromLogId = row["CorrectedFromLogId"] == DBNull.Value ? null : row["CorrectedFromLogId"].ToString(),
                createdBy = row["CreatedBy"].ToString(),
                branch = row["BranchId"] == DBNull.Value ? null : row["BranchId"].ToString(),
                branchName = row["BranchName"] == DBNull.Value ? "" : row["BranchName"].ToString(),
                expenses = expenses,
                createdAt = Convert.ToDateTime(row["CreatedAt"]),
                updatedAt = Convert.ToDateTime(row["UpdatedAt"])
            });
        }
        return list;
    }

    public static string SaveDraft(
        string draftId, string driverName, string vehicleNumber, string fromLocation, string toLocation,
        DateTime? startDateTime, DateTime? endDateTime, double? endKm, double fuelAdded, double? remainingFuel,
        string fuelType, double? pricePerLitre, string branchId, string branchName,
        List<ExpenseInput> expenses, string correctedFromLogId, string username)
    {
        if (endKm.HasValue && endKm.Value < 0)
        {
            return "End KM must be zero or positive";
        }

        string id = draftId;
        bool isNew = string.IsNullOrEmpty(draftId);

        if (isNew)
        {
            id = Guid.NewGuid().ToString();
        }
        else
        {
            // Verify owner
            var owner = clsDatabase.ExecuteScalar("SELECT CreatedBy FROM VehicleLogDrafts WHERE Id = @Id", new SqlParameter("@Id", draftId)) as string;
            if (owner == null) return "Waiting list entry not found";
            if (owner != username) return "Unauthorized";
        }

        using (var conn = clsDatabase.GetConnection())
        {
            using (var trans = conn.BeginTransaction())
            {
                try
                {
                    if (isNew)
                    {
                        string sql = "INSERT INTO VehicleLogDrafts (Id, DriverName, VehicleNumber, FromLocation, ToLocation, StartDateTime, EndDateTime, EndKm, FuelAdded, RemainingFuel, FuelType, PricePerLitre, CorrectedFromLogId, CreatedBy, BranchId, BranchName, CreatedAt, UpdatedAt) " +
                            "VALUES (@Id, @DriverName, @VehicleNumber, @FromLocation, @ToLocation, @StartDateTime, @EndDateTime, @EndKm, @FuelAdded, @RemainingFuel, @FuelType, @PricePerLitre, @CorrectedFromLogId, @CreatedBy, @BranchId, @BranchName, @CreatedAt, @UpdatedAt)";
                        using (var cmd = new SqlCommand(sql, conn, trans))
                        {
                            cmd.Parameters.AddWithValue("@Id", id);
                            cmd.Parameters.AddWithValue("@DriverName", driverName != null ? driverName.Trim() : "");
                            cmd.Parameters.AddWithValue("@VehicleNumber", vehicleNumber != null ? vehicleNumber.Trim().ToUpperInvariant() : "");
                            cmd.Parameters.AddWithValue("@FromLocation", fromLocation != null ? fromLocation.Trim() : "");
                            cmd.Parameters.AddWithValue("@ToLocation", toLocation != null ? toLocation.Trim() : "");
                            cmd.Parameters.AddWithValue("@StartDateTime", startDateTime.HasValue ? (object)startDateTime.Value : DBNull.Value);
                            cmd.Parameters.AddWithValue("@EndDateTime", endDateTime.HasValue ? (object)endDateTime.Value : DBNull.Value);
                            cmd.Parameters.AddWithValue("@EndKm", endKm.HasValue ? (object)endKm.Value : DBNull.Value);
                            cmd.Parameters.AddWithValue("@FuelAdded", fuelAdded);
                            cmd.Parameters.AddWithValue("@RemainingFuel", remainingFuel.HasValue ? (object)remainingFuel.Value : DBNull.Value);
                            cmd.Parameters.AddWithValue("@FuelType", string.IsNullOrEmpty(fuelType) ? DBNull.Value : (object)fuelType);
                            cmd.Parameters.AddWithValue("@PricePerLitre", pricePerLitre.HasValue ? (object)pricePerLitre.Value : DBNull.Value);
                            cmd.Parameters.AddWithValue("@CorrectedFromLogId", string.IsNullOrEmpty(correctedFromLogId) ? DBNull.Value : (object)correctedFromLogId);
                            cmd.Parameters.AddWithValue("@CreatedBy", username);
                            cmd.Parameters.AddWithValue("@BranchId", string.IsNullOrEmpty(branchId) ? DBNull.Value : (object)branchId);
                            cmd.Parameters.AddWithValue("@BranchName", string.IsNullOrEmpty(branchName) ? DBNull.Value : (object)branchName);
                            cmd.Parameters.AddWithValue("@CreatedAt", DateTime.UtcNow);
                            cmd.Parameters.AddWithValue("@UpdatedAt", DateTime.UtcNow);
                            cmd.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        string sql = "UPDATE VehicleLogDrafts SET DriverName = @DriverName, VehicleNumber = @VehicleNumber, FromLocation = @FromLocation, ToLocation = @ToLocation, StartDateTime = @StartDateTime, EndDateTime = @EndDateTime, EndKm = @EndKm, FuelAdded = @FuelAdded, RemainingFuel = @RemainingFuel, FuelType = @FuelType, PricePerLitre = @PricePerLitre, BranchId = @BranchId, BranchName = @BranchName, UpdatedAt = @UpdatedAt WHERE Id = @Id";
                        using (var cmd = new SqlCommand(sql, conn, trans))
                        {
                            cmd.Parameters.AddWithValue("@DriverName", driverName != null ? driverName.Trim() : "");
                            cmd.Parameters.AddWithValue("@VehicleNumber", vehicleNumber != null ? vehicleNumber.Trim().ToUpperInvariant() : "");
                            cmd.Parameters.AddWithValue("@FromLocation", fromLocation != null ? fromLocation.Trim() : "");
                            cmd.Parameters.AddWithValue("@ToLocation", toLocation != null ? toLocation.Trim() : "");
                            cmd.Parameters.AddWithValue("@StartDateTime", startDateTime.HasValue ? (object)startDateTime.Value : DBNull.Value);
                            cmd.Parameters.AddWithValue("@EndDateTime", endDateTime.HasValue ? (object)endDateTime.Value : DBNull.Value);
                            cmd.Parameters.AddWithValue("@EndKm", endKm.HasValue ? (object)endKm.Value : DBNull.Value);
                            cmd.Parameters.AddWithValue("@FuelAdded", fuelAdded);
                            cmd.Parameters.AddWithValue("@RemainingFuel", remainingFuel.HasValue ? (object)remainingFuel.Value : DBNull.Value);
                            cmd.Parameters.AddWithValue("@FuelType", string.IsNullOrEmpty(fuelType) ? DBNull.Value : (object)fuelType);
                            cmd.Parameters.AddWithValue("@PricePerLitre", pricePerLitre.HasValue ? (object)pricePerLitre.Value : DBNull.Value);
                            cmd.Parameters.AddWithValue("@BranchId", string.IsNullOrEmpty(branchId) ? DBNull.Value : (object)branchId);
                            cmd.Parameters.AddWithValue("@BranchName", string.IsNullOrEmpty(branchName) ? DBNull.Value : (object)branchName);
                            cmd.Parameters.AddWithValue("@UpdatedAt", DateTime.UtcNow);
                            cmd.Parameters.AddWithValue("@Id", id);
                            cmd.ExecuteNonQuery();
                        }

                        // Delete existing draft expenses
                        using (var cmd = new SqlCommand("DELETE FROM VehicleLogDraftExpenses WHERE VehicleLogDraftId = @DraftId", conn, trans))
                        {
                            cmd.Parameters.AddWithValue("@DraftId", id);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    // Insert draft expenses
                    if (expenses != null && expenses.Count > 0)
                    {
                        foreach (var exp in expenses)
                        {
                            string expSql = "INSERT INTO VehicleLogDraftExpenses (Id, VehicleLogDraftId, ExpenseType, Amount, Date, Description) VALUES (@Id, @DraftId, @ExpenseType, @Amount, @Date, @Description)";
                            using (var cmd = new SqlCommand(expSql, conn, trans))
                            {
                                cmd.Parameters.AddWithValue("@Id", Guid.NewGuid().ToString());
                                cmd.Parameters.AddWithValue("@DraftId", id);
                                cmd.Parameters.AddWithValue("@ExpenseType", exp.expenseType.Trim().ToLowerInvariant());
                                cmd.Parameters.AddWithValue("@Amount", exp.amount);
                                cmd.Parameters.AddWithValue("@Date", exp.date);
                                cmd.Parameters.AddWithValue("@Description", exp.description != null ? exp.description.Trim() : "");
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }

                    trans.Commit();
                }
                catch (Exception)
                {
                    trans.Rollback();
                    throw;
                }
            }
        }

        return "success";
    }

    public static string DeleteDraft(string id, string username)
    {
        int rows = clsDatabase.ExecuteNonQuery("DELETE FROM VehicleLogDrafts WHERE Id = @Id AND CreatedBy = @CreatedBy", 
            new SqlParameter("@Id", id), new SqlParameter("@CreatedBy", username));
        if (rows == 0) return "Waiting list entry not found";
        return "success";
    }

    public static string SubmitDraft(string id, string username)
    {
        // Fetch draft
        var draftDt = clsDatabase.GetDataTable("SELECT DriverName, VehicleNumber, FromLocation, ToLocation, StartDateTime, EndDateTime, EndKm, FuelAdded, RemainingFuel, FuelType, PricePerLitre, CorrectedFromLogId, BranchId, BranchName FROM VehicleLogDrafts WHERE Id = @Id AND CreatedBy = @CreatedBy",
            new SqlParameter("@Id", id), new SqlParameter("@CreatedBy", username));

        if (draftDt.Rows.Count == 0) return "Waiting list entry not found";
        var draftRow = draftDt.Rows[0];

        if (draftRow["EndKm"] == DBNull.Value || draftRow["StartDateTime"] == DBNull.Value)
        {
            return "Draft is incomplete (requires Start DateTime and End KM before submission)";
        }

        // Fetch draft expenses
        var expDt = clsDatabase.GetDataTable("SELECT ExpenseType, Amount, Date, Description FROM VehicleLogDraftExpenses WHERE VehicleLogDraftId = @DraftId",
            new SqlParameter("@DraftId", id));
        var expenses = new List<ExpenseInput>();
        foreach (DataRow row in expDt.Rows)
        {
            expenses.Add(new ExpenseInput
            {
                expenseType = row["ExpenseType"].ToString(),
                amount = Convert.ToDouble(row["Amount"]),
                date = row["Date"].ToString(),
                description = row["Description"].ToString()
            });
        }

        string result = CreateVehicleLog(
            draftRow["DriverName"].ToString(),
            draftRow["VehicleNumber"].ToString(),
            draftRow["FromLocation"].ToString(),
            draftRow["ToLocation"].ToString(),
            Convert.ToDateTime(draftRow["StartDateTime"]),
            draftRow["EndDateTime"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(draftRow["EndDateTime"]),
            Convert.ToDouble(draftRow["EndKm"]),
            Convert.ToDouble(draftRow["FuelAdded"]),
            draftRow["RemainingFuel"] == DBNull.Value ? (double?)null : Convert.ToDouble(draftRow["RemainingFuel"]),
            draftRow["FuelType"].ToString(),
            draftRow["PricePerLitre"] == DBNull.Value ? (double?)null : Convert.ToDouble(draftRow["PricePerLitre"]),
            "", // mileageReason empty on submit
            draftRow["BranchId"].ToString(),
            draftRow["BranchName"].ToString(),
            expenses,
            draftRow["CorrectedFromLogId"].ToString(),
            username,
            id // draftId to delete
        );

        return result;
    }

    public static List<object> GetLogs(string status, string vehicleNumber, string fromDate, string toDate, string username, string userRole)
    {
        var parameters = new List<SqlParameter>();
        string sql = "SELECT l.Id, l.DriverName, l.VehicleNumber, l.FromLocation, l.ToLocation, l.StartDateTime, l.EndDateTime, l.StartKm, l.EndKm, l.DistanceTravelled, l.AvailableFuel, l.FuelAdded, l.RemainingFuel, l.FuelFillDate, l.FuelUsed, l.Mileage, l.MileageReason, l.IsLowFuel, l.FuelType, l.PricePerLitre, l.CorrectedFromLogId, l.CorrectedByLogId, l.Status, l.RejectReason, l.QueryQuestion, l.QueryAnswer, l.CreatedBy, l.ReviewedBy, l.ReviewedAt, l.BranchId, l.BranchName, l.CreatedAt, l.UpdatedAt, p.ExpectedMileage FROM VehicleLogs l LEFT JOIN VehicleProfiles p ON l.VehicleNumber = p.VehicleNumber WHERE 1=1";

        if (!string.IsNullOrEmpty(status))
        {
            sql += " AND l.Status = @Status";
            parameters.Add(new SqlParameter("@Status", status));
        }

        if (!string.IsNullOrEmpty(vehicleNumber))
        {
            var list = clsVehicleProfile.GetAlternativeVehicleNumbers(vehicleNumber);
            sql += string.Format(" AND l.VehicleNumber IN ('{0}')", string.Join("','", list.ToArray()));
        }

        // Role based filtering for security
        if (userRole == "security")
        {
            // Fetch branch of security
            var branchIdObj = clsDatabase.ExecuteScalar("SELECT BranchId FROM Users WHERE Username = @Username", new SqlParameter("@Username", username));
            if (branchIdObj != null && branchIdObj != DBNull.Value && !string.IsNullOrEmpty(branchIdObj.ToString()))
            {
                sql += " AND l.BranchId = @BranchId";
                parameters.Add(new SqlParameter("@BranchId", branchIdObj.ToString()));
            }
            else
            {
                sql += " AND l.CreatedBy = @CreatedBy";
                parameters.Add(new SqlParameter("@CreatedBy", username));
            }
        }

        if (!string.IsNullOrEmpty(fromDate))
        {
            DateTime parsedFrom;
            if (clsDatabase.TryParseDate(fromDate, out parsedFrom))
            {
                sql += " AND l.StartDateTime >= @FromDate";
                parameters.Add(new SqlParameter("@FromDate", parsedFrom.Date));
            }
        }

        if (!string.IsNullOrEmpty(toDate))
        {
            DateTime parsedTo;
            if (clsDatabase.TryParseDate(toDate, out parsedTo))
            {
                sql += " AND l.StartDateTime <= @ToDate";
                parameters.Add(new SqlParameter("@ToDate", parsedTo.Date.AddDays(1).AddTicks(-1)));
            }
        }

        sql += " ORDER BY l.CreatedAt DESC";

        // Limit to 300 logs
        sql = sql.Replace("SELECT l.Id", "SELECT TOP 300 l.Id");

        var dt = clsDatabase.GetDataTable(sql, parameters.ToArray());
        var result = new List<object>();

        foreach (DataRow row in dt.Rows)
        {
            string logId = row["Id"].ToString();

            // Fetch expenses
            var expDt = clsDatabase.GetDataTable("SELECT ExpenseType, Amount, Date, Description FROM VehicleLogExpenses WHERE VehicleLogId = @LogId",
                new SqlParameter("@LogId", logId));
            var expenses = new List<object>();
            foreach (DataRow eRow in expDt.Rows)
            {
                expenses.Add(new
                {
                    expenseType = eRow["ExpenseType"].ToString(),
                    amount = Convert.ToDouble(eRow["Amount"]),
                    date = Convert.ToDateTime(eRow["Date"]),
                    description = eRow["Description"].ToString()
                });
            }

            result.Add(new
            {
                _id = logId,
                id = logId,
                driverName = row["DriverName"].ToString(),
                vehicleNumber = row["VehicleNumber"].ToString(),
                fromLocation = row["FromLocation"].ToString(),
                toLocation = row["ToLocation"].ToString(),
                startDateTime = Convert.ToDateTime(row["StartDateTime"]),
                endDateTime = Convert.ToDateTime(row["EndDateTime"]),
                startKm = Convert.ToDouble(row["StartKm"]),
                endKm = Convert.ToDouble(row["EndKm"]),
                distanceTravelled = Convert.ToDouble(row["DistanceTravelled"]),
                availableFuel = Convert.ToDouble(row["AvailableFuel"]),
                fuelAdded = Convert.ToDouble(row["FuelAdded"]),
                remainingFuel = Convert.ToDouble(row["RemainingFuel"]),
                fuelFillDate = row["FuelFillDate"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(row["FuelFillDate"]),
                fuelUsed = Convert.ToDouble(row["FuelUsed"]),
                mileage = row["Mileage"] == DBNull.Value ? (double?)null : Convert.ToDouble(row["Mileage"]),
                expectedMileage = row["ExpectedMileage"] == DBNull.Value ? (double?)null : Convert.ToDouble(row["ExpectedMileage"]),
                mileageReason = row["MileageReason"].ToString(),
                isLowFuel = Convert.ToBoolean(row["IsLowFuel"]),
                fuelType = row["FuelType"] == DBNull.Value ? null : row["FuelType"].ToString(),
                pricePerLitre = row["PricePerLitre"] == DBNull.Value ? (double?)null : Convert.ToDouble(row["PricePerLitre"]),
                correctedFromLogId = row["CorrectedFromLogId"] == DBNull.Value ? null : row["CorrectedFromLogId"].ToString(),
                correctedByLogId = row["CorrectedByLogId"] == DBNull.Value ? null : row["CorrectedByLogId"].ToString(),
                status = row["Status"].ToString(),
                rejectReason = row["RejectReason"].ToString(),
                queryQuestion = row["QueryQuestion"].ToString(),
                queryAnswer = row["QueryAnswer"].ToString(),
                createdBy = row["CreatedBy"].ToString(),
                reviewedBy = row["ReviewedBy"] == DBNull.Value ? null : row["ReviewedBy"].ToString(),
                reviewedAt = row["ReviewedAt"] == DBNull.Value ? (DateTime?)null : Convert.ToDateTime(row["ReviewedAt"]),
                branch = row["BranchId"] == DBNull.Value ? null : row["BranchId"].ToString(),
                branchName = row["BranchName"] == DBNull.Value ? "" : row["BranchName"].ToString(),
                expenses = expenses,
                createdAt = Convert.ToDateTime(row["CreatedAt"]),
                updatedAt = Convert.ToDateTime(row["UpdatedAt"])
            });
        }

        return result;
    }

    public static string ReviewVehicleLog(string id, string action, string reason, string username)
    {
        var allowedActions = new List<string> { "approve", "reject", "query", "resolve" };
        var act = action.Trim().ToLowerInvariant();
        if (!allowedActions.Contains(act)) return "Invalid action";

        var dt = clsDatabase.GetDataTable("SELECT Status, VehicleNumber, FuelAdded, StartDateTime FROM VehicleLogs WHERE Id = @Id", new SqlParameter("@Id", id));
        if (dt.Rows.Count == 0) return "Vehicle log not found";

        var row = dt.Rows[0];
        string status = "pending";
        string rejectReason = "";
        string queryQuestion = "";
        string queryAnswer = "";

        if (act == "reject")
        {
            if (string.IsNullOrWhiteSpace(reason)) return "Query reason is required";
            status = "rejected";
            rejectReason = reason.Trim();
        }
        else if (act == "approve")
        {
            status = "approved";
            rejectReason = "";
        }
        else if (act == "query")
        {
            if (string.IsNullOrWhiteSpace(reason)) return "Query question is required";
            status = "queried";
            queryQuestion = reason.Trim();
            queryAnswer = "";
        }
        else if (act == "resolve")
        {
            status = "approved";
        }

        clsDatabase.ExecuteNonQuery(
            "UPDATE VehicleLogs SET Status = @Status, RejectReason = @RejectReason, QueryQuestion = @QueryQuestion, QueryAnswer = @QueryAnswer, ReviewedBy = @ReviewedBy, ReviewedAt = @ReviewedAt, UpdatedAt = @UpdatedAt WHERE Id = @Id",
            new SqlParameter("@Status", status),
            new SqlParameter("@RejectReason", rejectReason),
            new SqlParameter("@QueryQuestion", queryQuestion),
            new SqlParameter("@QueryAnswer", queryAnswer),
            new SqlParameter("@ReviewedBy", username ?? "system"),
            new SqlParameter("@ReviewedAt", DateTime.UtcNow),
            new SqlParameter("@UpdatedAt", DateTime.UtcNow),
            new SqlParameter("@Id", id)
        );

        // Cascading approvals for fuel logs
        if ((status == "approved") && Convert.ToDouble(row["FuelAdded"]) > 0)
        {
            try
            {
                string vehicleNumber = row["VehicleNumber"].ToString();
                DateTime startDateTime = Convert.ToDateTime(row["StartDateTime"]);
                var altList = clsVehicleProfile.GetAlternativeVehicleNumbers(vehicleNumber);
                string altClause = string.Join("','", altList.ToArray());

                // Find previous approved fuel log
                var prevFuelLogDt = clsDatabase.GetDataTable(
                    string.Format("SELECT TOP 1 StartDateTime FROM VehicleLogs WHERE VehicleNumber IN ('{0}') AND Status = 'approved' AND FuelAdded > 0 AND StartDateTime < @StartDateTime ORDER BY StartDateTime DESC, CreatedAt DESC", altClause),
                    new SqlParameter("@StartDateTime", startDateTime)
                );

                string cascadeSql = string.Format("UPDATE VehicleLogs SET Status = 'approved', ReviewedBy = @ReviewedBy, ReviewedAt = @ReviewedAt WHERE VehicleNumber IN ('{0}') AND FuelAdded = 0", altClause);
                var cascadeParams = new List<SqlParameter>
                {
                    new SqlParameter("@ReviewedBy", username ?? "system"),
                    new SqlParameter("@ReviewedAt", DateTime.UtcNow),
                    new SqlParameter("@StartDateTime", startDateTime)
                };

                if (prevFuelLogDt.Rows.Count > 0)
                {
                    DateTime prevFuelDate = Convert.ToDateTime(prevFuelLogDt.Rows[0]["StartDateTime"]);
                    cascadeSql += " AND StartDateTime > @PrevFuelDate AND StartDateTime <= @StartDateTime";
                    cascadeParams.Add(new SqlParameter("@PrevFuelDate", prevFuelDate));
                }
                else
                {
                    cascadeSql += " AND StartDateTime <= @StartDateTime";
                }

                clsDatabase.ExecuteNonQuery(cascadeSql, cascadeParams.ToArray());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Cascading approval error: " + ex.Message);
            }
        }

        clsVehicleProfile.SyncVehicleProfileOpeningKm(row["VehicleNumber"].ToString());

        return "success";
    }

    public static string AnswerQuery(string id, string answer)
    {
        if (string.IsNullOrWhiteSpace(answer)) return "Answer is required";

        var dt = clsDatabase.GetDataTable("SELECT Status FROM VehicleLogs WHERE Id = @Id", new SqlParameter("@Id", id));
        if (dt.Rows.Count == 0) return "Vehicle log not found";

        string status = dt.Rows[0]["Status"].ToString();
        if (status != "queried") return "Log is not in queried status";

        clsDatabase.ExecuteNonQuery(
            "UPDATE VehicleLogs SET Status = 'answered', QueryAnswer = @Answer, UpdatedAt = @UpdatedAt WHERE Id = @Id",
            new SqlParameter("@Answer", answer.Trim()),
            new SqlParameter("@UpdatedAt", DateTime.UtcNow),
            new SqlParameter("@Id", id)
        );

        return "success";
    }

    public static List<Dictionary<string, object>> GetReports()
    {
        var approvedLogs = clsDatabase.GetDataTable("SELECT l.VehicleNumber, l.DistanceTravelled, l.FuelUsed, l.IsLowFuel, (SELECT ISNULL(SUM(Amount), 0) FROM VehicleLogExpenses e WHERE e.VehicleLogId = l.Id) as LogExpTotal FROM VehicleLogs l WHERE l.Status = 'approved'");
        var standaloneExpenses = clsDatabase.GetDataTable("SELECT VehicleNumber, Amount FROM VehicleExpenses");

        var grouped = new Dictionary<string, Dictionary<string, double>>();

        // helper to ensure dictionary key exists
        Action<string> checkKey = (vNum) => {
            if (!grouped.ContainsKey(vNum))
            {
                grouped[vNum] = new Dictionary<string, double>
                {
                    { "totalDistance", 0.0 },
                    { "totalFuelUsed", 0.0 },
                    { "totalExpenses", 0.0 },
                    { "lowFuelCount", 0.0 },
                    { "tripCount", 0.0 }
                };
            }
        };

        foreach (DataRow row in approvedLogs.Rows)
        {
            string vNum = row["VehicleNumber"].ToString().ToUpperInvariant();
            checkKey(vNum);

            grouped[vNum]["totalDistance"] += Convert.ToDouble(row["DistanceTravelled"]);
            grouped[vNum]["totalFuelUsed"] += Convert.ToDouble(row["FuelUsed"]);
            grouped[vNum]["totalExpenses"] += Convert.ToDouble(row["LogExpTotal"]);
            grouped[vNum]["lowFuelCount"] += Convert.ToBoolean(row["IsLowFuel"]) ? 1.0 : 0.0;
            grouped[vNum]["tripCount"] += 1.0;
        }

        foreach (DataRow row in standaloneExpenses.Rows)
        {
            string vNum = row["VehicleNumber"].ToString().ToUpperInvariant();
            checkKey(vNum);

            grouped[vNum]["totalExpenses"] += Convert.ToDouble(row["Amount"]);
        }

        var rowsList = new List<Dictionary<string, object>>();
        foreach (var kp in grouped)
        {
            double dist = kp.Value["totalDistance"];
            double fuel = kp.Value["totalFuelUsed"];
            double? avgMileage = null;
            if (fuel > 0)
            {
                avgMileage = Math.Round(dist / fuel, 2);
            }

            rowsList.Add(new Dictionary<string, object>
            {
                { "vehicleNumber", kp.Key },
                { "totalDistance", dist },
                { "totalFuelUsed", fuel },
                { "totalExpenses", kp.Value["totalExpenses"] },
                { "avgMileage", avgMileage },
                { "lowFuelCount", (int)kp.Value["lowFuelCount"] },
                { "tripCount", (int)kp.Value["tripCount"] }
            });
        }

        // Sort reports alphabetically by vehicleNumber
        rowsList.Sort((x, y) => {
            string vx = x["vehicleNumber"].ToString();
            string vy = y["vehicleNumber"].ToString();
            return string.Compare(vx, vy, StringComparison.OrdinalIgnoreCase);
        });

        return rowsList;
    }

    public static int GetPendingCount()
    {
        var result = clsDatabase.ExecuteScalar("SELECT COUNT(*) FROM VehicleLogs WHERE Status = 'queried' OR Status = 'answered'");
        return Convert.ToInt32(result);
    }
}
