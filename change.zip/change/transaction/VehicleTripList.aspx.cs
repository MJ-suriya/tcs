using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Services;

public partial class Transaction_VehicleTripList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserId"] == null)
        {
            Response.Redirect("~/Login.aspx");
        }
    }

    private static string GetUsername()
    {
        return HttpContext.Current.Session["UserName"] != null ? HttpContext.Current.Session["UserName"].ToString() : "system";
    }

    private static string GetUserRole()
    {
        string editSession = HttpContext.Current.Session["EditSession"] != null ? HttpContext.Current.Session["EditSession"].ToString() : "none";
        string approvalSession = HttpContext.Current.Session["ApprovalSession"] != null ? HttpContext.Current.Session["ApprovalSession"].ToString() : "none";
        
        if (approvalSession == "inline")
        {
            if (HttpContext.Current.Session["UserName"] != null && HttpContext.Current.Session["UserName"].ToString().ToUpper() == "ADMIN") 
                return "admin";
            return "manager";
        }
        
        if (editSession == "inline")
        {
            return "pettycashier";
        }
        
        return "security";
    }

    [WebMethod(EnableSession = true)]
    public static object GetLogs(string status, string vehicleNumber, string fromDate, string toDate)
    {
        string role = GetUserRole();
        string username = GetUsername();
        return clsVehicleLog.GetLogs(status, vehicleNumber, fromDate, toDate, username, role);
    }

    [WebMethod(EnableSession = true)]
    public static object ReviewVehicleLog(string id, string action, string reason)
    {
        string approvalSession = HttpContext.Current.Session["ApprovalSession"] != null ? HttpContext.Current.Session["ApprovalSession"].ToString() : "none";
        string role = GetUserRole();
        if (approvalSession != "inline" && role != "admin")
        {
            return new { error = "Unauthorized review permission" };
        }
        string res = clsVehicleLog.ReviewVehicleLog(id, action, reason, GetUsername());
        if (res == "success") return new { success = true };
        return new { error = res };
    }

    [WebMethod(EnableSession = true)]
    public static object AnswerQuery(string id, string answer)
    {
        string res = clsVehicleLog.AnswerQuery(id, answer);
        if (res == "success") return new { success = true };
        return new { error = res };
    }

    [WebMethod]
    public static object GetVehicles()
    {
        return clsVehicleProfile.GetVehicles();
    }

    [WebMethod]
    public static object GetBranches()
    {
        return clsBranch.GetBranches();
    }
}
