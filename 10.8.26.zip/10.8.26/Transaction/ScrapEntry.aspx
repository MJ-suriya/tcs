<%@ Page Title="" Language="C#" MasterPageFile="~/General/Master.master" AutoEventWireup="true"
    CodeFile="ScrapEntry.aspx.cs" Inherits="Transaction_ScrapEntry" %>

    <asp:Content ID="Content1" ContentPlaceHolderID="ctnHead" runat="Server">
        <style>
            .scrap-item-row {
                margin-bottom: 5px;
                background: #fdfdfd;
                border: 1px solid #eee;
                padding: 8px;
                border-radius: 3px;
            }
        </style>
        <script class="text/javascript">
            var productsList = [];
            var selectedItems = [];
            var currentRole = '';
            var activeEntriesList = [];
            var hasEditPermission = '<%= Session["EditSession"] != null ? Session["EditSession"].ToString() : "none" %>';
            var hasApprovalPermission = '<%= Session["ApprovalSession"] != null ? Session["ApprovalSession"].ToString() : "none" %>';
            var isBranchManualWeightAllowed = true;

            window.onload = function () {
                initDateTime();
                LoadProducts();
                LoadBranches();
                getTbleDet();

                // Show uploader only if user has Edit or Approval policy rights
                if (hasEditPermission === 'inline' || hasApprovalPermission === 'inline') {
                    $("#div_ProofUpload").show();
                } else {
                    $("#div_ProofUpload").hide();
                }

                $("#cmb_Branch").on("change", onBranchChange);
            };

            function LoadBranches() {
                PageMethods.GetBranches(function (response) {
                    $("#cmb_Branch").html("<option value=''>System / Main</option>");
                    $("#filter_Branch").html("<option value=''>All Branches</option>");
                    if (response && response.length > 0) {
                        $.each(response, function (key, val) {
                            $("#cmb_Branch").append("<option value='" + val.id + "'>" + val.name + "</option>");
                            $("#filter_Branch").append("<option value='" + val.id + "'>" + val.name + "</option>");
                        });
                    }
                });
            }

            function LoadProducts(callback) {
                var branchId = $("#cmb_Branch").val();
                var currentSelectedProduct = $("#cmb_Product").val();
                PageMethods.GetProductsForBranch(branchId, function (response) {
                    productsList = response || [];
                    $("#cmb_Product").html("<option value=''>Select Product</option>");
                    if (productsList.length > 0) {
                        $.each(productsList, function (key, val) {
                            $("#cmb_Product").append("<option value='" + val.id + "'>" + val.name + "</option>");
                        });
                    }
                    if (currentSelectedProduct) {
                        $("#cmb_Product").val(currentSelectedProduct);
                    }
                    onProductChange();
                    if (callback) callback();
                });
            }

            function onBranchChange() {
                var branchId = $("#cmb_Branch").val();
                PageMethods.GetBranchManualWeightSetting(branchId, function (isAllowed) {
                    isBranchManualWeightAllowed = isAllowed;
                    LoadProducts();
                });
            }

            function onProductChange() {
                var pId = $("#cmb_Product").val();
                var matched = productsList.find(p => p.id === pId);
                if (matched) {
                    $("#lbl_PricePerKg").text("Rs " + matched.pricePerKg.toFixed(2));
                    if (isBranchManualWeightAllowed) {
                        $("#txt_Weight").prop("readonly", false).attr("placeholder", "Weight").val("");
                    } else {
                        $("#txt_Weight").prop("readonly", true).attr("placeholder", "COM Only").val("");
                    }
                } else {
                    $("#lbl_PricePerKg").text("Rs 0.00");
                    $("#txt_Weight").prop("readonly", false).attr("placeholder", "Weight").val("");
                }
            }

            var serialBuffer = "";
            async function readFromCOM() {
                if (!('serial' in navigator)) {
                    simulateCOMRead();
                    return;
                }

                let port;
                try {
                    const ports = await navigator.serial.getPorts();
                    if (ports.length > 0) {
                        port = ports[0];
                    } else {
                        port = await navigator.serial.requestPort();
                    }

                    try {
                        if (port.readable) {
                            const reader = port.readable.getReader();
                            reader.releaseLock();
                            await port.close();
                        }
                    } catch (e) {
                        console.log("Port close ignore:", e);
                    }

                    await port.open({ baudRate: 9600 });

                    const reader = port.readable.getReader();
                    const decoder = new TextDecoder("utf-8");

                    swal("Connecting", "Waiting for stable weight signal from scale machine...", "info");

                    serialBuffer = "";
                    let readTimeout = setTimeout(async () => {
                        try {
                            await reader.cancel();
                        } catch (e) { }
                        swal("Timeout", "No weight data received from the scale. Please check the cable connection and try again.", "warning");
                    }, 10000);

                    let foundWeight = false;
                    while (true) {
                        const { value, done } = await reader.read();
                        if (done) {
                            break;
                        }
                        if (value) {
                            const textChunk = decoder.decode(value);
                            serialBuffer += textChunk;
                            if (serialBuffer.indexOf('\n') !== -1 || serialBuffer.indexOf('\r') !== -1) {
                                const lines = serialBuffer.split(/[\r\n]+/);
                                serialBuffer = lines[lines.length - 1];

                                for (let i = 0; i < lines.length - 1; i++) {
                                    const cleanLine = lines[i].trim();
                                    if (cleanLine.length > 0) {
                                        const matches = cleanLine.match(/[0-9]+\.[0-9]+|[0-9]+/);
                                        if (matches) {
                                            const weight = parseFloat(matches[0]);
                                            if (!isNaN(weight) && weight > 0) {
                                                clearTimeout(readTimeout);
                                                $("#txt_Weight").val(weight.toFixed(2));
                                                swal("Success", "Weight of " + weight.toFixed(2) + " Kg read successfully!", "success");
                                                foundWeight = true;
                                                break;
                                            }
                                        }
                                    }
                                }
                                if (foundWeight) {
                                    break;
                                }
                            }
                        }
                    }

                    clearTimeout(readTimeout);
                    try {
                        reader.releaseLock();
                        await port.close();
                    } catch (e) {
                        console.error('Error closing port:', e);
                    }
                } catch (err) {
                    console.error('Serial port error:', err);
                    swal("Serial Port Error", "Could not connect to the weighing scale: " + err.message, "error");
                    if (port) {
                        try {
                            await port.close();
                        } catch (e) { }
                    }
                }
            }

            function simulateCOMRead() {
                var mockWeight = (Math.random() * 200 + 50).toFixed(2);
                $("#txt_Weight").val(mockWeight);
                swal("COM Simulated Read", "Browser Web Serial is not connected. Simulated weigh reading: " + mockWeight + " Kgs", "success");
            }

            function addScrapItem() {
                var pId = $("#cmb_Product").val();
                var weight = parseFloat($("#txt_Weight").val());

                if (!pId) {
                    swal("Attention", "Select product type", "warning");
                    return;
                }
                if (isNaN(weight) || weight <= 0) {
                    swal("Attention", "Enter valid weight", "warning");
                    return;
                }

                var matched = productsList.find(p => p.id === pId);
                if (!matched) return;

                // Check if already added
                var exists = selectedItems.find(item => item.productId === pId);
                if (exists) {
                    exists.weight += weight;
                } else {
                    selectedItems.push({
                        productId: pId,
                        productName: matched.name,
                        weight: weight,
                        pricePerKg: matched.pricePerKg
                    });
                }

                renderScrapItems();
                $("#cmb_Product").val("");
                $("#txt_Weight").val("");
                $("#lbl_PricePerKg").text("Rs 0.00");
            }

            function removeScrapItem(idx) {
                selectedItems.splice(idx, 1);
                renderScrapItems();
            }

            function renderScrapItems() {
                $("#div_ScrapItemsBdy").html("");
                var grandTotal = 0;
                if (selectedItems.length === 0) {
                    $("#div_ScrapItemsBdy").html("<tr><td colspan='5' class='text-muted text-center'>No items added.</td></tr>");
                    $("#lbl_GrandTotal").text("Rs 0.00");
                    return;
                }

                $.each(selectedItems, function (idx, item) {
                    var total = item.weight * item.pricePerKg;
                    grandTotal += total;

                    var row = '<tr>'
                        + '<td>' + (idx + 1) + '</td>'
                        + '<td class="text-uppercase"><strong>' + item.productName + '</strong></td>'
                        + '<td class="text-right">' + item.weight.toFixed(2) + ' Kg</td>'
                        + '<td class="text-right">Rs ' + item.pricePerKg.toFixed(2) + '</td>'
                        + '<td class="text-right"><strong>Rs ' + total.toFixed(2) + '</strong></td>'
                        + '<td style="text-align:center;"><button type="button" class="btn btn-danger btn-xs" onclick="removeScrapItem(' + idx + ')"><i class="fa fa-remove"></i></button></td>'
                        + '</tr>';
                    $("#div_ScrapItemsBdy").append(row);
                });

                $("#lbl_GrandTotal").text("Rs " + grandTotal.toFixed(2));
            }

            function submitScrapEntry() {
                $("#btn_Submit").attr("disabled", true);

                var company = $("#txt_CompanyName").val().trim();
                var vNum = $("#txt_VehicleNumber").val().trim();
                var owner = $("#txt_OwnerName").val().trim();
                var dt = $("#txt_DateTime").val();
                var desc = $("#txt_Description").val().trim();

                var branchId = $("#cmb_Branch").val();
                var branchName = branchId ? $("#cmb_Branch option:selected").text() : "";

                if (!company || !vNum || selectedItems.length === 0) {
                    swal("Attention", "Please fill in Company Name, Vehicle Number, and at least 1 scrap product.", "warning");
                    $("#btn_Submit").attr("disabled", false);
                    return;
                }

                var itemsJson = JSON.stringify(selectedItems);
                executeSubmit(company, vNum, owner, branchId, branchName, dt, desc, itemsJson, "", "");
            }

            function executeSubmit(company, vNum, owner, branchId, branchName, dt, desc, itemsJson, base64File, fileName) {
                PageMethods.CreateScrapEntry(
                    company, vNum, owner, branchId, branchName, dt, desc, itemsJson, base64File, fileName,
                    function (response) {
                        if (response.error) {
                            swal("Error", response.error, "error");
                            $("#btn_Submit").attr("disabled", false);
                        } else {
                            var successMsg = "Scrap entry recorded successfully! Sent for Verification.";
                            swal("Success", successMsg, "success");
                            clearForm();
                            getTbleDet();
                        }
                    }
                );
            }

            function initDateTime() {
                var now = new Date();
                var offset = now.getTimezoneOffset() * 60000;
                var localISOTime = new Date(now - offset).toISOString().slice(0, 16);
                $("#txt_DateTime").val(localISOTime);
            }

            function clearForm() {
                $("#txt_CompanyName").val("");
                $("#txt_VehicleNumber").val("");
                $("#txt_OwnerName").val("");
                initDateTime();
                $("#txt_Description").val("");
                $("#cmb_Branch").val("");
                selectedItems = [];
                renderScrapItems();
                $("#btn_Submit").attr("disabled", false);
            }

            function getTbleDet() {
                if ($.fn.DataTable.isDataTable('#tbl_Entries')) {
                    $("#tbl_Entries").DataTable().destroy();
                }
                $("#tbl_bdy_Entries").html('<tr><td colspan="8" style="text-align:center;padding:20px;font-weight:bold;color:#666;"><i class="fa fa-spinner fa-spin fa-2x"></i><br/>Loading records...</td></tr>');

                var status = $("#filter_Status").val();
                var fromDate = $("#filter_FromDate").val();
                var toDate = $("#filter_ToDate").val();
                var branchId = $("#filter_Branch").val();

                PageMethods.GetEntries(status, fromDate, toDate, function (response) {
                    activeEntriesList = response || [];
                    $("#tbl_bdy_Entries").html("");
                    if (response && response.length > 0) {
                        var filtered = response;
                        if (branchId) {
                            filtered = $.grep(response, function (item) {
                                return item.branch === branchId;
                            });
                        }
                        $.each(filtered, function (key, val) {
                            var dateStr = formatDate(val.createdAt);

                            var badgeClass = 'default';
                            if (val.status === 'approved') badgeClass = 'success';
                            else if (val.status === 'rejected') badgeClass = 'danger';
                            else if (val.status === 'pending_pettycashier' || val.status === 'pending_manager') badgeClass = 'warning';
                            else if (val.status === 'queried') badgeClass = 'danger';

                            var statusLabel = val.status.replace('pending_pettycashier', 'pending').replace('_', ' ').toUpperCase();
                            if ((val.status === 'approved' || val.status === 'rejected') && val.reviewedBy) {
                                statusLabel += ' (' + val.reviewedBy + ')';
                            }

                            var actionsHtml = '<button type="button" class="btn btn-default btn-xs" onclick="viewDetails(' + key + ')"><i class="fa fa-eye"></i> Details</button>';

                            // Verification action for Petty Cashier (requires Edit policy)
                            if (val.status === 'pending_pettycashier' && hasEditPermission === 'inline') {
                                actionsHtml += ' <button type="button" class="btn btn-warning btn-xs" onclick="openVerifyModal(\'' + val.id + '\',' + val.totalAmount + ')"><i class="fa fa-check-square-o"></i> Verify</button>';
                            } else if (val.status === 'queried') {
                                actionsHtml += ' <button type="button" class="btn btn-info btn-xs" onclick="openAnswerModal(\'' + val.id + '\',\'' + val.queryQuestion.replace(/'/g, "\\'") + '\')"><i class="fa fa-reply"></i> Answer</button>';
                            }

                            // Row print action
                            actionsHtml += ' <button type="button" class="btn btn-default btn-xs" onclick="printSingleRecord(' + key + ')"><i class="fa fa-print"></i> Print</button>';

                            var row = '<tr style="font-size:smaller;">'
                                + '<td style="text-align:center;">' + (key + 1) + '</td>'
                                + '<td><strong>' + val.companyName + '</strong></td>'
                                + '<td>' + val.vehicleNumber + '</td>'
                                + '<td>' + val.productName + '</td>'
                                + '<td style="text-align:right; font-weight:bold;">Rs ' + (val.pettyCashierVerifiedAmount ? val.pettyCashierVerifiedAmount.toFixed(2) : val.totalAmount.toFixed(2)) + '</td>'
                                + '<td>' + dateStr + '</td>'
                                + '<td style="text-align:center;"><span class="label label-' + badgeClass + '">' + statusLabel + '</span></td>'
                                + '<td style="text-align:center;">' + actionsHtml + '</td>'
                                + '</tr>';

                            $("#tbl_bdy_Entries").append(row);
                        });

                        $('#tbl_Entries').DataTable({
                            'paging': true,
                            'lengthChange': true,
                            'searching': true,
                            'ordering': true,
                            'info': true,
                            'autoWidth': false
                        });
                    }
                });
            }

            function formatDate(dateObj) {
                if (!dateObj) return "—";
                var d = new Date(dateObj);
                if (isNaN(d.getTime())) return "—";
                var datePart = d.getDate() + '/' + (d.getMonth() + 1) + '/' + d.getFullYear();
                var timePart = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                return datePart + ', ' + timePart;
            }

            function printSingleRecord(idx) {
                var entry = activeEntriesList[idx];
                if (!entry) return;

                var printWin = window.open('', '', 'width=800,height=600');
                printWin.document.write('<html><head><title>Print Scrap Entry</title>');
                printWin.document.write('<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">');
                printWin.document.write('<style>body{padding:30px;font-family:sans-serif;} .invoice-title{font-size:24px;font-weight:bold;margin-bottom:20px;text-transform:uppercase;color:#3c8dbc;border-bottom:2px solid #3c8dbc;padding-bottom:10px;} .meta-table{width:100%;margin-bottom:30px;} .meta-table th, .meta-table td{padding:8px 0;} .meta-table th{width:35%;text-align:left;} table.items-table{width:100%;border-collapse:collapse;} table.items-table th, table.items-table td{padding:10px;border:1px solid #ddd;text-align:left;} table.items-table th{background-color:#f5f5f5;}</style>');
                printWin.document.write('</head><body>');
                printWin.document.write('<div class="invoice-title">Scrap Entry Receipt</div>');
                printWin.document.write('<table class="meta-table">');
                printWin.document.write('<tr><th>Vendor / Company Name:</th><td>' + entry.companyName + '</td></tr>');
                printWin.document.write('<tr><th>Vehicle Number:</th><td>' + entry.vehicleNumber + '</td></tr>');
                printWin.document.write('<tr><th>Owner / Driver Name:</th><td>' + (entry.ownerName || '—') + '</td></tr>');
                printWin.document.write('<tr><th>Reporting Branch:</th><td>' + (entry.branchName || 'System / Main') + '</td></tr>');
                printWin.document.write('<tr><th>Date & Time Recorded:</th><td>' + formatDate(entry.createdAt) + '</td></tr>');
                var statusPrint = entry.status.replace('_', ' ').toUpperCase();
                if (entry.reviewedBy) {
                    statusPrint += ' (' + entry.reviewedBy + ')';
                }
                printWin.document.write('<tr><th>Status:</th><td>' + statusPrint + '</td></tr>');
                printWin.document.write('</table>');
                printWin.document.write('<h4>Materials List</h4>');
                printWin.document.write('<table class="items-table">');
                printWin.document.write('<thead><tr><th>#</th><th>Material Name</th><th style="text-align:right;">Weight</th><th style="text-align:right;">Price/Kg</th><th style="text-align:right;">Total Amount</th></tr></thead>');
                printWin.document.write('<tbody>');
                var grandTotal = 0;
                if (entry.items && entry.items.length > 0) {
                    $.each(entry.items, function (k, item) {
                        var total = item.weight * item.pricePerKg;
                        grandTotal += total;
                        printWin.document.write('<tr>');
                        printWin.document.write('<td>' + (k + 1) + '</td>');
                        printWin.document.write('<td>' + item.productName + '</td>');
                        printWin.document.write('<td style="text-align:right;">' + item.weight.toFixed(2) + ' Kg</td>');
                        printWin.document.write('<td style="text-align:right;">Rs ' + item.pricePerKg.toFixed(2) + '</td>');
                        printWin.document.write('<td style="text-align:right;">Rs ' + total.toFixed(2) + '</td>');
                        printWin.document.write('</tr>');
                    });
                } else {
                    printWin.document.write('<tr><td colspan="5" style="text-align:center;">No items recorded.</td></tr>');
                }
                printWin.document.write('</tbody>');
                var footerHtml = '<tr><th colspan="4" style="text-align:right;">By Total:</th><th style="text-align:right;color:green;">Rs ' + (entry.totalAmount || grandTotal).toFixed(2) + '</th></tr>';
                if (entry.pettyCashierVerifiedAmount && entry.pettyCashierVerifiedAmount > 0) {
                    footerHtml += '<tr><th colspan="4" style="text-align:right;">Grand Verified Total:</th><th style="text-align:right;color:blue;">Rs ' + entry.pettyCashierVerifiedAmount.toFixed(2) + '</th></tr>';
                }
                printWin.document.write('<tfoot>' + footerHtml + '</tfoot>');
                printWin.document.write('</table>');
                printWin.document.write('</body></html>');
                printWin.document.close();
                setTimeout(function () {
                    printWin.focus();
                    printWin.print();
                    printWin.close();
                }, 500);
            }

            function viewDetails(idx) {
                var entry = activeEntriesList[idx];
                if (!entry) return;

                $("#lbl_DetCompany").text(entry.companyName);
                $("#lbl_DetVehicle").text(entry.vehicleNumber);
                $("#lbl_DetOwner").text(entry.ownerName);
                $("#lbl_DetCreatedBy").text(entry.createdBy);
                $("#lbl_DetBranch").text(entry.branchName || "System / Main");
                $("#lbl_DetDate").text(new Date(entry.createdAt).toLocaleString());
                $("#lbl_DetTotal").text("Rs " + entry.totalAmount.toFixed(2));
                $("#lbl_DetVerifiedTotal").text(entry.pettyCashierVerifiedAmount ? ("Rs " + entry.pettyCashierVerifiedAmount.toFixed(2)) : "Pending Verification");
                var statusText = entry.status.replace('pending_pettycashier', 'pending').replace('_', ' ').toUpperCase();
                if (entry.reviewedBy) {
                    statusText += ' (' + entry.reviewedBy + ')';
                }
                $("#lbl_DetStatus").text(statusText);

                $("#lbl_DetRejectReason").text(entry.rejectReason || "None");
                $("#lbl_DetQuery").text(entry.queryQuestion || "None");
                $("#lbl_DetAnswer").text(entry.queryAnswer || "None");

                if (entry.proofDocument) {
                    var files = entry.proofDocument.split(';');
                    var html = '';
                    $.each(files, function (i, file) {
                        if (file.trim()) {
                            var filename = file.substring(file.lastIndexOf('/') + 1);
                            html += '<a href="../' + file.trim() + '" target="_blank" class="btn btn-default btn-xs" style="margin-right:5px; margin-bottom:5px;"><i class="fa fa-file-image-o"></i> View ' + filename + '</a> ';
                        }
                    });
                    $("#div_DetProof").html(html);
                } else {
                    $("#div_DetProof").text("No file uploaded");
                }

                // Render materials table
                $("#tbl_DetMaterialsBdy").html("");
                if (entry.items && entry.items.length > 0) {
                    $.each(entry.items, function (k, item) {
                        var total = item.weight * item.pricePerKg;
                        var itemRow = '<tr>'
                            + '<td>' + (k + 1) + '</td>'
                            + '<td class="text-uppercase"><strong>' + item.productName + '</strong></td>'
                            + '<td class="text-right">' + item.weight.toFixed(2) + ' Kg</td>'
                            + '<td class="text-right">Rs ' + item.pricePerKg.toFixed(2) + '</td>'
                            + '<td class="text-right">Rs ' + total.toFixed(2) + '</td>'
                            + '</tr>';
                        $("#tbl_DetMaterialsBdy").append(itemRow);
                    });
                }

                $("#modal-details").modal('show');
            }

            function reviewEntry(id, action, reason) {
                swal({
                    title: "Are you sure?",
                    text: "Do you want to " + action + " this scrap entry?",
                    icon: "info",
                    buttons: true
                }).then(function (willSubmit) {
                    if (willSubmit) {
                        if (action === 'approve') {
                            PageMethods.ApproveEntry(id, function (res) {
                                if (res.error) swal("Error", res.error, "error");
                                else {
                                    swal("Success", "Entry approved successfully!", "success");
                                    getTbleDet();
                                }
                            });
                        } else if (action === 'reject') {
                            PageMethods.RejectEntry(id, reason || "", function (res) {
                                if (res.error) swal("Error", res.error, "error");
                                else {
                                    swal("Success", "Entry rejected!", "success");
                                    $("#modal-review").modal('hide');
                                    getTbleDet();
                                }
                            });
                        } else if (action === 'query') {
                            PageMethods.QueryEntry(id, reason || "", function (res) {
                                if (res.error) swal("Error", res.error, "error");
                                else {
                                    swal("Success", "Query sent to vendor desk!", "success");
                                    $("#modal-review").modal('hide');
                                    getTbleDet();
                                }
                            });
                        }
                    }
                });
            }

            function openReviewModal(id, action) {
                $("#hf_ReviewEntryId").val(id);
                $("#hf_ReviewAction").val(action);

                if (action === 'reject') {
                    $("#modal_review_title").text("Reject Scrap Entry");
                    $("#lbl_ReviewReason").text("Enter Rejection Reason *");
                    $("#txt_ReviewReason").attr("placeholder", "Why is this scrap rejected?");
                } else {
                    $("#modal_review_title").text("Query Weighbridge Entry");
                    $("#lbl_ReviewReason").text("Enter Query Question *");
                    $("#txt_ReviewReason").attr("placeholder", "What details need clarification?");
                }

                $("#txt_ReviewReason").val("");
                $("#modal-review").modal('show');
            }

            function submitReviewReason() {
                var id = $("#hf_ReviewEntryId").val();
                var action = $("#hf_ReviewAction").val();
                var reason = $("#txt_ReviewReason").val().trim();

                if (reason.length === 0) {
                    swal("Attention", "Please provide a reason / question details.", "warning");
                    return;
                }

                reviewEntry(id, action, reason);
            }

            function openAnswerModal(id, queryText) {
                $("#hf_AnswerEntryId").val(id);
                $("#lbl_QueryQuestionText").text(queryText);
                $("#txt_QueryAnswer").val("");
                $("#modal-answer").modal('show');
            }

            function submitQueryAnswer() {
                var id = $("#hf_AnswerEntryId").val();
                var ans = $("#txt_QueryAnswer").val().trim();

                if (ans.length === 0) {
                    swal("Attention", "Please provide an answer reply", "warning");
                    return;
                }

                PageMethods.AnswerEntryQuery(id, ans, function (response) {
                    if (response.error) {
                        swal("Error", response.error, "error");
                    } else {
                        swal("Success", "Query answer submitted successfully!", "success");
                        $("#modal-answer").modal('hide');
                        getTbleDet();
                    }
                });
            }

             function closeVerifyPanel() {
                 $("#div_VerifyPanel").slideUp();
                 $("#hf_VerifyEntryId").val("");
                 $("#hf_VerifyExpectedAmount").val("");
                 $("#txt_VerifyAmount").val("");
                 var file1 = document.getElementById('file_VerifyProof1');
                 if (file1) file1.value = "";
                 var file2 = document.getElementById('file_VerifyProof2');
                 if (file2) file2.value = "";
                 $("#file_names_list").html("");
             }

            function openVerifyModal(id, expectedAmount) {
                $("#hf_VerifyEntryId").val(id);
                $("#hf_VerifyExpectedAmount").val(expectedAmount);
                $("#txt_VerifyAmount").val(expectedAmount.toFixed(2));
                var file1 = document.getElementById('file_VerifyProof1');
                if (file1) file1.value = "";
                var file2 = document.getElementById('file_VerifyProof2');
                if (file2) file2.value = "";
                $("#file_names_list").html("");
                $("#div_VerifyPanel").slideDown();
                $('html, body').animate({
                    scrollTop: $("#div_VerifyPanel").offset().top - 100
                }, 500);
            }

            function showSelectedFilesList() {
                var listContainer = $("#file_names_list");
                listContainer.html("");
                var count = 0;
                var namesHtml = "<strong>Selected Files:</strong><ol style='padding-left: 15px; margin-top: 5px;'>";

                var file1 = document.getElementById('file_VerifyProof1');
                if (file1 && file1.files && file1.files.length > 0) {
                    namesHtml += "<li>[Invoice] " + file1.files[0].name + " (" + (file1.files[0].size / 1024).toFixed(1) + " KB)</li>";
                    count++;
                }

                var file2 = document.getElementById('file_VerifyProof2');
                if (file2 && file2.files && file2.files.length > 0) {
                    namesHtml += "<li>[Other] " + file2.files[0].name + " (" + (file2.files[0].size / 1024).toFixed(1) + " KB)</li>";
                    count++;
                }

                namesHtml += "</ol>";
                if (count > 0) {
                    listContainer.html(namesHtml);
                }
            }

            function compressImage(file, callback) {
                if (!file.type.match(/image.*/)) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        callback(e.target.result);
                    };
                    reader.readAsDataURL(file);
                    return;
                }

                var reader = new FileReader();
                reader.onload = function (readerEvent) {
                    var image = new Image();
                    image.onload = function (imageEvent) {
                        var canvas = document.createElement('canvas');
                        var max_size = 1600;
                        var width = image.width;
                        var height = image.height;
                        if (width > height) {
                            if (width > max_size) {
                                height *= max_size / width;
                                width = max_size;
                            }
                        } else {
                            if (height > max_size) {
                                width *= max_size / height;
                                height = max_size;
                            }
                        }
                        canvas.width = width;
                        canvas.height = height;
                        var ctx = canvas.getContext('2d');
                        ctx.drawImage(image, 0, 0, width, height);
                        var dataUrl = canvas.toDataURL('image/jpeg', 0.7);
                        callback(dataUrl);
                    };
                    image.src = readerEvent.target.result;
                };
                reader.readAsDataURL(file);
            }

            function submitVerification() {
                var id = $("#hf_VerifyEntryId").val();
                var amt = parseFloat($("#txt_VerifyAmount").val());

                if (isNaN(amt) || amt <= 0) {
                    swal("Attention", "Please enter a valid verified amount.", "warning");
                    return;
                }

                var fileInput1 = document.getElementById('file_VerifyProof1');
                var fileInput2 = document.getElementById('file_VerifyProof2');

                if (!fileInput1 || !fileInput1.files || fileInput1.files.length === 0) {
                    swal("Attention", "Invoice Slip Document is mandatory.", "warning");
                    return;
                }

                var filesToLoad = [];
                filesToLoad.push(fileInput1.files[0]);

                if (fileInput2 && fileInput2.files && fileInput2.files.length > 0) {
                    filesToLoad.push(fileInput2.files[0]);
                }

                swal({
                    title: "Processing...",
                    text: "Please wait while we compress and upload files.",
                    icon: "info",
                    buttons: false,
                    closeOnClickOutside: false,
                    closeOnEsc: false
                });

                var filesData = [];
                var loadedCount = 0;
                var totalFiles = filesToLoad.length;

                for (var i = 0; i < totalFiles; i++) {
                    (function (file) {
                        compressImage(file, function (compressedBase64) {
                            var finalFileName = file.name;
                            if (file.type.match(/image.*/) && !finalFileName.toLowerCase().endsWith('.jpg') && !finalFileName.toLowerCase().endsWith('.jpeg')) {
                                finalFileName = finalFileName.substring(0, finalFileName.lastIndexOf('.')) + '.jpg';
                            }
                            filesData.push({
                                fileName: finalFileName,
                                base64Data: compressedBase64
                            });
                            loadedCount++;
                            if (loadedCount === totalFiles) {
                                executeVerification(id, amt, JSON.stringify(filesData));
                            }
                        });
                    })(filesToLoad[i]);
                }
            }

            function executeVerification(id, amt, filesJson) {
                PageMethods.VerifyScrapEntry(id, amt, filesJson, function (response) {
                    if (response.error) {
                        swal("Error", response.error, "error");
                    } else {
                        swal("Success", "Scrap entry verified and forwarded to Manager for approval!", "success")
                        .then(function () {
                            closeVerifyPanel();
                            getTbleDet();
                        });
                    }
                });
            }

            // Helper Abs value for float comparison
            Math.Abs = function (val) {
                return val < 0 ? -val : val;
            }
        </script>
    </asp:Content>

    <asp:Content ID="Content2" ContentPlaceHolderID="ctnForm" runat="Server">
        <input type="hidden" id="hf_ReviewEntryId" />
        <input type="hidden" id="hf_ReviewAction" />
        <input type="hidden" id="hf_AnswerEntryId" />
        <input type="hidden" id="hf_VerifyEntryId" />
        <input type="hidden" id="hf_VerifyExpectedAmount" />

        <div class="content-wrapper">
            <section class="content-header">
                <h1>Scrap Entry
                    <!-- <small>Weigh Bridge Recording</small> -->
                </h1>
                <ol class="breadcrumb">
                    <li><a href="../General/Dashboard.aspx"><i class="fa fa-dashboard"></i>Home</a></li>
                    <li class="active">Scrap Entries</li>
                </ol>
            </section>

            <section class="content">
                <!-- Form card -->
                <div id="div_FormCard" class="row">
                    <div class="col-md-7">
                        <div class="box box-primary">
                            <div class="box-header with-border">
                                <h3 class="box-title">Vendor & Vehicle details</h3>
                            </div>
                            <div class="box-body">
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="txt_CompanyName">Vendor / Company Name *</label>
                                        <input type="text" id="txt_CompanyName" class="form-control text-uppercase"
                                            placeholder="e.g. SRM TRADERS" maxlength="150" />
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="txt_VehicleNumber">Vehicle Number *</label>
                                        <input type="text" id="txt_VehicleNumber" class="form-control text-uppercase"
                                            placeholder="e.g. TN19XY9876" maxlength="50" />
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label for="txt_OwnerName">Owner / Driver Name</label>
                                        <input type="text" id="txt_OwnerName" class="form-control text-uppercase"
                                            placeholder="e.g. Muthu" maxlength="150" />
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="cmb_Branch">Reporting Branch Office</label>
                                        <select id="cmb_Branch" class="form-control"></select>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <label for="txt_DateTime">Date & Time *</label>
                                        <input type="datetime-local" id="txt_DateTime" class="form-control" />
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-12">
                                        <label for="txt_Description">Entry Notes / Remarks</label>
                                        <textarea id="txt_Description" class="form-control" rows="2"
                                            placeholder="Enter scrap specifications or vehicle check notes..."></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Products column -->
                    <div class="col-md-5">
                        <!-- Dynamic Product List -->
                        <div class="box box-success">
                            <div class="box-header with-border">
                                <h3 class="box-title">Scrap Materials Grid</h3>
                            </div>
                            <div class="box-body">
                                <div class="row">
                                    <div class="form-group col-md-5">
                                        <label>Product</label>
                                        <select id="cmb_Product" class="form-control"
                                            onchange="onProductChange()"></select>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <label>Weight (Kgs)</label>
                                        <div class="input-group">
                                            <input type="number" step="0.01" id="txt_Weight" class="form-control"
                                                placeholder="Weight" />
                                            <span class="input-group-btn">
                                                <button type="button" id="btn_COMRead" class="btn btn-primary"
                                                    onclick="readFromCOM()" title="Read from scale (COM Port)"><i
                                                        class="fa fa-refresh"></i> COM</button>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <label>Rate / Kg</label>
                                        <div style="font-size:16px; font-weight:bold; padding-top:5px; color:#3c8dbc;"
                                            id="lbl_PricePerKg">Rs 0.00</div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <button type="button" class="btn btn-success btn-block"
                                            onclick="addScrapItem()"><i class="fa fa-plus"></i> Add to Purchase
                                            list</button>
                                    </div>
                                </div>

                                <hr />

                                <!-- List Table -->
                                <table class="table table-striped table-bordered" style="margin-top:15px;">
                                    <thead>
                                        <tr>
                                            <th style="width:5%;">#</th>
                                            <th>Material</th>
                                            <th style="text-align:right;">Weight</th>
                                            <th style="text-align:right;">Rate</th>
                                            <th style="text-align:right;">Total</th>
                                            <th style="width:10%;"></th>
                                        </tr>
                                    </thead>
                                    <tbody id="div_ScrapItemsBdy">
                                        <tr>
                                            <td colspan="6" class="text-muted text-center">No items added.</td>
                                        </tr>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th colspan="4" style="text-align:right;">Estimated Total Amount:</th>
                                            <th style="text-align:right; font-size:15px; color:green;"
                                                id="lbl_GrandTotal">Rs 0.00</th>
                                            <th></th>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <div class="box-footer">
                                <button type="button" class="btn btn-default" onclick="clearForm()">Reset Grid</button>
                                <button type="button" id="btn_Submit" class="btn btn-primary pull-right"
                                    onclick="submitScrapEntry()">Submit Scrap Entry</button>
                            </div>
                        </div>
                    </div>
                </div>

                <hr style="border-top: 2px solid #ccc; margin: 30px 0;" />

                <h3>Purchase Scrap Logs Specification</h3>

                <!-- Filter Bar -->
                <div class="filter-box"
                    style="background-color: #fcfcfc; border: 1px solid #ddd; padding: 15px; margin-bottom: 20px; border-radius: 4px;">
                    <div class="row">
                        <div class="form-group col-md-2">
                            <label for="filter_Status">Filter Status</label>
                            <select id="filter_Status" class="form-control" onchange="getTbleDet()">
                                <option value="">All Statuses</option>
                                <option value="pending" selected>Pending Review</option>
                                <option value="approved">Approved Purchases</option>
                                <option value="rejected">Rejected Purchases</option>
                            </select>
                        </div>
                        <div class="form-group col-md-2">
                            <label for="filter_Branch">Filter Branch</label>
                            <select id="filter_Branch" class="form-control" onchange="getTbleDet()"></select>
                        </div>
                        <div class="form-group col-md-2">
                            <label for="filter_FromDate">From Date</label>
                            <input type="date" id="filter_FromDate" class="form-control" onchange="getTbleDet()" />
                        </div>
                        <div class="form-group col-md-2">
                            <label for="filter_ToDate">To Date</label>
                            <input type="date" id="filter_ToDate" class="form-control" onchange="getTbleDet()" />
                        </div>
                        <div class="form-group col-md-4">
                            <label>&nbsp;</label>
                            <button type="button" class="btn btn-primary btn-block" onclick="getTbleDet()"><i
                                    class="fa fa-refresh"></i> Refresh Records</button>
                        </div>
                    </div>

                    <!-- Inline Verification Panel -->
                    <div id="div_VerifyPanel" class="box box-warning"
                        style="display:none; margin-top:20px; border-top: 3px solid #f39c12; box-shadow: 0 4px 8px rgba(0,0,0,0.05);">
                        <div class="box-header with-border" style="background-color: #fafafa;">
                            <h3 class="box-title" style="font-weight: bold; color: #e08e0b;"><i
                                    class="fa fa-check-square-o"></i> Verify Scrap Entry Cash & Invoice</h3>
                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool" onclick="closeVerifyPanel()"><i
                                        class="fa fa-times" style="font-size: 16px;"></i></button>
                            </div>
                        </div>
                        <div class="box-body" style="padding: 20px;">
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="txt_VerifyAmount" style="font-size: 13px;">Confirm Net Total Verified
                                        Amount (Rs) *</label>
                                    <div class="input-group">
                                        <span class="input-group-addon"
                                            style="background-color: #eee; font-weight: bold;">Rs</span>
                                        <input type="number" step="0.01" id="txt_VerifyAmount"
                                            class="form-control input-lg" style="font-weight: bold; color: #333;" />
                                    </div>
                                    <p class="help-block small" style="color: #888;">Enter final verified amount.
                                        Pre-filled with expected amount.</p>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="file_VerifyProof1" style="font-size: 13px;">Upload Invoice Slip Document
                                        * (Mandatory)</label>
                                    <input type="file" id="file_VerifyProof1" class="form-control input-lg"
                                        accept="image/*,application/pdf" onchange="showSelectedFilesList()"
                                        style="padding: 5px;" />
                                </div>
                                <div class="form-group col-md-6" style="margin-top: 15px;">
                                    <label for="file_VerifyProof2" style="font-size: 13px;">Upload Other Proof Document
                                        (Optional)</label>
                                    <input type="file" id="file_VerifyProof2" class="form-control input-lg"
                                        accept="image/*,application/pdf" onchange="showSelectedFilesList()"
                                        style="padding: 5px;" />
                                    <div id="file_names_list" class="text-info small"
                                        style="margin-top: 10px; font-weight: bold;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer" style="background-color: #fafafa; padding: 15px 20px;">
                            <button type="button" class="btn btn-default" onclick="closeVerifyPanel()">Cancel</button>
                            <button type="button" class="btn btn-warning pull-right" onclick="submitVerification()"
                                style="font-weight: bold; padding: 6px 20px;"><i class="fa fa-save"></i> Verify &
                                Forward</button>
                        </div>
                    </div>

                    <!-- Grid Box -->
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="box box-primary">
                                <div class="box-body">
                                    <table id="tbl_Entries" class="table table-bordered table-hover">
                                        <thead>
                                            <tr>
                                                <th style="text-align: center; width: 1%">#</th>
                                                <th style="width: 25%">Company / Vendor</th>
                                                <th style="width: 15%">Vehicle Number</th>
                                                <th style="width: 15%">Main Product</th>
                                                <th style="width: 12%; text-align: right;">Total Price</th>
                                                <th style="width: 12%">Date & Time</th>
                                                <th style="width: 10%; text-align: center;">Status</th>
                                                <th style="width: 10%; text-align: center;">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody id="tbl_bdy_Entries"></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Details Modal -->
                    <div id="modal-details" class="modal fade" role="dialog">
                        <div class="modal-dialog modal-md">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title">Scrap Entry Specifications</h4>
                                </div>
                                <div class="modal-body">
                                    <table class="table table-bordered details-table">
                                        <tr>
                                            <th style="width: 35%; background-color: #f4f6f9;">Vendor / Company</th>
                                            <td id="lbl_DetCompany" style="font-weight:bold;"></td>
                                        </tr>
                                        <tr>
                                            <th style="background-color: #f4f6f9;">Vehicle Registration</th>
                                            <td id="lbl_DetVehicle"></td>
                                        </tr>
                                        <tr>
                                            <th style="background-color: #f4f6f9;">Owner / Driver</th>
                                            <td id="lbl_DetOwner"></td>
                                        </tr>
                                        <tr>
                                            <th style="background-color: #f4f6f9;">Estimated Total Price</th>
                                            <td id="lbl_DetTotal" style="color:green; font-weight:bold;"></td>
                                        </tr>
                                        <tr>
                                            <th style="background-color: #f4f6f9;">Verified Invoice Total</th>
                                            <td id="lbl_DetVerifiedTotal" style="color:blue; font-weight:bold;"></td>
                                        </tr>
                                        <tr>
                                            <th style="background-color: #f4f6f9;">Current Log Status</th>
                                            <td id="lbl_DetStatus" style="font-weight:bold;"></td>
                                        </tr>
                                        <tr>
                                            <th style="background-color: #f4f6f9;">Created By Account</th>
                                            <td id="lbl_DetCreatedBy"></td>
                                        </tr>
                                        <tr>
                                            <th style="background-color: #f4f6f9;">Reporting Branch</th>
                                            <td id="lbl_DetBranch"></td>
                                        </tr>
                                        <tr>
                                            <th style="background-color: #f4f6f9;">Date & Time Created</th>
                                            <td id="lbl_DetDate"></td>
                                        </tr>
                                        <tr>
                                            <th style="background-color: #f4f6f9;">Invoice Slip Document</th>
                                            <td id="div_DetProof"></td>
                                        </tr>
                                        <tr>
                                            <th style="background-color: #f4f6f9;">Review Rejection Reason</th>
                                            <td id="lbl_DetRejectReason" style="color:red;"></td>
                                        </tr>
                                        <tr>
                                            <th style="background-color: #f4f6f9;">Pending Query Question</th>
                                            <td id="lbl_DetQuery"></td>
                                        </tr>
                                        <tr>
                                            <th style="background-color: #f4f6f9;">Query Answer Response</th>
                                            <td id="lbl_DetAnswer"></td>
                                        </tr>
                                    </table>

                                    <!-- Items List Grid -->
                                    <div style="margin-top: 15px;">
                                        <h4>Materials Purchased</h4>
                                        <table class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Material Name</th>
                                                    <th style="text-align:right;">Weight (Kgs)</th>
                                                    <th style="text-align:right;">Rate / Kg</th>
                                                    <th style="text-align:right;">Total (Rs)</th>
                                                </tr>
                                            </thead>
                                            <tbody id="tbl_DetMaterialsBdy"></tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                            </div>



                            <!-- Review / Action dialog Modal -->
                            <div id="modal-review" class="modal fade" role="dialog">
                                <div class="modal-dialog modal-sm">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span></button>
                                            <h4 class="modal-title" id="modal_review_title">Review Action</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label id="lbl_ReviewReason">Reason *</label>
                                                <textarea id="txt_ReviewReason" class="form-control"
                                                    rows="3"></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default pull-left"
                                                data-dismiss="modal">Cancel</button>
                                            <button type="button" class="btn btn-primary"
                                                onclick="submitReviewReason()">Submit Review</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Answer Query Modal -->
                            <div id="modal-answer" class="modal fade" role="dialog">
                                <div class="modal-dialog modal-sm">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span></button>
                                            <h4 class="modal-title">Reply to Query</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="well well-sm">
                                                <strong>Query Question:</strong>
                                                <p id="lbl_QueryQuestionText" class="text-warning"></p>
                                            </div>
                                            <div class="form-group">
                                                <label for="txt_QueryAnswer">Query Answer *</label>
                                                <textarea id="txt_QueryAnswer" class="form-control" rows="3"
                                                    placeholder="Provide answer explanation..."></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default pull-left"
                                                data-dismiss="modal">Cancel</button>
                                            <button type="button" class="btn btn-primary"
                                                onclick="submitQueryAnswer()">Submit Reply</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

            </section>
        </div>
    </asp:Content>