<%@ Page Title="" Language="C#" MasterPageFile="~/General/Master.master" AutoEventWireup="true"
    CodeFile="VehicleTripList.aspx.cs" Inherits="Transaction_VehicleTripList" %>

    <asp:Content ID="Content1" ContentPlaceHolderID="ctnHead" runat="Server">
        <style>
            .filter-box {
                background-color: #fcfcfc;
                border: 1px solid #ddd;
                padding: 15px;
                margin-bottom: 20px;
                border-radius: 4px;
            }

            .log-details-table th {
                width: 35%;
                background-color: #f4f6f9;
            }
        </style>
        <script class="text/javascript">
            var currentRole = '';
            var activeLogsList = [];
            var hasApprovalPermission = '<%= Session["ApprovalSession"] != null ? Session["ApprovalSession"].ToString() : "none" %>';

            window.onload = function () {
                // Determine role dynamically from Session variable passed through page backend if needed
                // Or get it implicitly via server-side checks on load
                LoadVehiclesFilter();
                LoadBranchesFilter();
                getTbleDet();
            };

            function LoadVehiclesFilter() {
                PageMethods.GetVehicles(function (response) {
                    $("#filter_Vehicle").html("<option value=''>All Vehicles</option>");
                    if (response && response.length > 0) {
                        $.each(response, function (key, val) {
                            $("#filter_Vehicle").append("<option value='" + val.vehicleNumber + "'>" + val.vehicleNumber + "</option>");
                        });
                    }
                });
            }

            function LoadBranchesFilter() {
                PageMethods.GetBranches(function (response) {
                    $("#filter_Branch").html("<option value=''>All Branches</option>");
                    if (response && response.length > 0) {
                        $.each(response, function (key, val) {
                            $("#filter_Branch").append("<option value='" + val.id + "'>" + val.name + "</option>");
                        });
                    }
                });
            }

            function getTbleDet() {
                if ($.fn.DataTable.isDataTable('#tbl_Logs')) {
                    $("#tbl_Logs").DataTable().destroy();
                }
                $("#tbl_bdy_Logs").html("");

                var status = $("#filter_Status").val();
                var vNum = $("#filter_Vehicle").val();
                var fromDate = $("#filter_FromDate").val();
                var toDate = $("#filter_ToDate").val();
                var branchId = $("#filter_Branch").val();

                PageMethods.GetLogs(status, vNum, fromDate, toDate, function (response) {
                    activeLogsList = response || [];
                    if (response && response.length > 0) {
                        var filtered = response;
                        if (branchId) {
                            filtered = $.grep(response, function (item) {
                                return item.branch === branchId;
                            });
                        }
                        $.each(filtered, function (key, val) {
                            var start = formatDate(val.startDateTime);
                            var end = val.endDateTime ? formatDate(val.endDateTime) : '—';

                            var badgeClass = 'default';
                            if (val.status === 'approved') badgeClass = 'success';
                            else if (val.status === 'rejected') badgeClass = 'danger';
                            else if (val.status === 'queried') badgeClass = 'warning';
                            else if (val.status === 'answered') badgeClass = 'info';

                            var actionsHtml = '<button type="button" class="btn btn-default btn-xs" style="margin-right: 5px;" onclick="viewDetails(' + key + ')"><i class="fa fa-eye"></i> Details</button>';

                            // Show Approval/Query buttons if user has approval policy permission and status is pending, answered, or queried
                            if ((val.status === 'pending' || val.status === 'answered') && val.fuelAdded > 0 && hasApprovalPermission === 'inline') {
                                actionsHtml += ' <button type="button" class="btn btn-success btn-xs" style="margin-top: 5px;" onclick="reviewAction(\'' + val.id + '\', \'approve\')"><i class="fa fa-check"></i> Approve</button>'
                                    + ' <button type="button" class="btn btn-warning btn-xs" style="margin-top: 5px;" onclick="openReviewModal(\'' + val.id + '\', \'query\')"><i class="fa fa-question"></i> Query</button>'
                                    + ' <button type="button" class="btn btn-danger btn-xs" style="margin-top: 5px;" onclick="openReviewModal(\'' + val.id + '\', \'reject\')"><i class="fa fa-remove"></i> Reject</button>';
                            } else if (val.status === 'queried') {
                                actionsHtml += ' <button type="button" class="btn btn-info btn-xs" style="margin-right: 5px;" onclick="openAnswerModal(\'' + val.id + '\',\'' + val.queryQuestion.replace(/'/g, "\\'") + '\')"><i class="fa fa-reply"></i> Answer</button>';
                            }

                            var statusHtml = '<span class="label label-' + badgeClass + '">' + val.status.toUpperCase() + '</span>';
                            if (val.status === 'approved' && val.reviewedBy) {
                                statusHtml += '<br/><small style="color:#777; font-weight:bold;">by ' + val.reviewedBy + '</small>';
                            }

                            var row = '<tr style="font-size:smaller;">'
                                + '<td style="text-align:center;">' + (key + 1) + '</td>'
                                + '<td><strong>' + val.vehicleNumber + '</strong></td>'
                                + '<td>' + val.driverName + '</td>'
                                + '<td>' + val.fromLocation + ' &rarr; ' + val.toLocation + '</td>'
                                + '<td>Start: ' + start + '<br/>End: ' + end + '</td>'
                                + '<td style="text-align:right;">' + val.distanceTravelled + ' Km</td>'
                                + '<td style="text-align:right;">' + val.fuelAdded + ' L</td>'
                                + '<td style="text-align:right;">' + (val.mileage ? (val.mileage.toFixed(2) + ' Km/L' + (val.expectedMileage ? ' (Std: ' + val.expectedMileage + ')' : '')) : '') + '</td>'
                                + '<td style="text-align:center;">' + statusHtml
                                + (val.isLowFuel ? ' <br/><span class="label label-danger">LOW FUEL</span>' : '') + '</td>'
                                + '<td style="text-align:center;">' + actionsHtml + '</td>'
                                + '</tr>';

                            $("#tbl_bdy_Logs").append(row);
                        });

                        $('#tbl_Logs').DataTable({
                            'paging': true,
                            'lengthChange': true,
                            'searching': true,
                            'ordering': true,
                            'info': true,
                            'autoWidth': false
                        });
                    }
                });
            }

            function viewDetails(idx) {
                var log = activeLogsList[idx];
                if (!log) return;

                $("#lbl_DetVehicle").text(log.vehicleNumber);
                $("#lbl_DetDriver").text(log.driverName);
                $("#lbl_DetRoute").text(log.fromLocation + " to " + log.toLocation);
                $("#lbl_DetStart").text(formatDate(log.startDateTime));
                $("#lbl_DetEnd").text(log.endDateTime ? formatDate(log.endDateTime) : "N/A");
                $("#lbl_DetStartKm").text(log.startKm);
                $("#lbl_DetEndKm").text(log.endKm);
                $("#lbl_DetDistance").text(log.distanceTravelled + " KM");
                $("#lbl_DetFuelAvailable").text(log.availableFuel + " L");
                $("#lbl_DetFuelAdded").text(log.fuelAdded + " L");
                $("#lbl_DetFuelRemaining").text(log.remainingFuel + " L");
                $("#lbl_DetFuelUsed").text(log.fuelUsed + " L");
                $("#lbl_DetMileage").text(log.mileage ? (log.mileage.toFixed(2) + " KM/L" + (log.expectedMileage ? " (Std: " + log.expectedMileage + ")" : "")) : "N/A");
                var statusText = log.status.toUpperCase();
                if (log.status === 'approved' && log.reviewedBy) {
                    statusText += " (by " + log.reviewedBy + ")";
                }
                $("#lbl_DetStatus").text(statusText);
                $("#lbl_DetCreatedBy").text(log.createdBy);
                $("#lbl_DetLocation").text(log.branchName || "System / Main");

                $("#lbl_DetVarianceReason").text(log.mileageReason || "None");
                $("#lbl_DetRejectReason").text(log.rejectReason || "None");
                $("#lbl_DetQuery").text(log.queryQuestion || "None");
                $("#lbl_DetAnswer").text(log.queryAnswer || "None");

                // Render expenses list
                $("#tbl_DetExpensesBdy").html("");
                if (log.expenses && log.expenses.length > 0) {
                    $.each(log.expenses, function (k, exp) {
                        var expRow = '<tr>'
                            + '<td class="text-uppercase">' + exp.expenseType + '</td>'
                            + '<td class="text-right">Rs ' + exp.amount.toFixed(2) + '</td>'
                            + '<td>' + exp.description + '</td>'
                            + '</tr>';
                        $("#tbl_DetExpensesBdy").append(expRow);
                    });
                    $("#div_DetExpenses").show();
                } else {
                    $("#div_DetExpenses").hide();
                }

                $("#modal-details").modal('show');
            }

            function reviewAction(id, action, reason) {
                swal({
                    title: "Are you sure?",
                    text: "Do you want to " + action + " this vehicle log?",
                    icon: "info",
                    buttons: true
                }).then(function (willSubmit) {
                    if (willSubmit) {
                        PageMethods.ReviewVehicleLog(id, action, reason || "", function (response) {
                            if (response.error) {
                                swal("Error", response.error, "error");
                            } else {
                                swal("Success", "Log " + action + "d successfully!", "success");
                                $("#modal-review").modal('hide');
                                getTbleDet();
                            }
                        });
                    }
                });
            }

            function openReviewModal(id, action) {
                $("#hf_ReviewLogId").val(id);
                $("#hf_ReviewAction").val(action);

                if (action === 'reject') {
                    $("#modal_review_title").text("Reject Vehicle Log Book Entry");
                    $("#lbl_ReviewReason").text("Enter Rejection Reason *");
                    $("#txt_ReviewReason").attr("placeholder", "Why is this log rejected? (Odometer mistake, etc.)");
                } else {
                    $("#modal_review_title").text("Query Driver / Log Entry");
                    $("#lbl_ReviewReason").text("Enter Query Question *");
                    $("#txt_ReviewReason").attr("placeholder", "What details or proof do you need? (Enter query)");
                }

                $("#txt_ReviewReason").val("");
                $("#modal-review").modal('show');
            }

            function submitReviewReason() {
                var id = $("#hf_ReviewLogId").val();
                var action = $("#hf_ReviewAction").val();
                var reason = $("#txt_ReviewReason").val().trim();

                if (reason.length === 0) {
                    swal("Attention", "Please provide the reason / question description.", "warning");
                    return;
                }

                reviewAction(id, action, reason);
            }

            function openAnswerModal(id, queryText) {
                $("#hf_AnswerLogId").val(id);
                $("#lbl_QueryQuestionText").text(queryText);
                $("#txt_QueryAnswer").val("");
                $("#modal-answer").modal('show');
            }

            function submitQueryAnswer() {
                var id = $("#hf_AnswerLogId").val();
                var ans = $("#txt_QueryAnswer").val().trim();

                if (ans.length === 0) {
                    swal("Attention", "Please provide an answer reply", "warning");
                    return;
                }

                PageMethods.AnswerQuery(id, ans, function (response) {
                    if (response.error) {
                        swal("Error", response.error, "error");
                    } else {
                        swal("Success", "Query answer submitted successfully!", "success");
                        $("#modal-answer").modal('hide');
                        getTbleDet();
                    }
                });
            }

            function formatDate(dateObj) {
                if (!dateObj) return "—";
                var d = new Date(dateObj);
                if (isNaN(d.getTime())) return "—";
                var datePart = d.getDate() + '/' + (d.getMonth() + 1) + '/' + d.getFullYear();
                var timePart = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                return datePart + ', ' + timePart;
            }

            function printFilteredList() {
                var branchName = $("#filter_Branch option:selected").text() || "All Branches";
                var fromDate = $("#filter_FromDate").val() || "";
                var toDate = $("#filter_ToDate").val() || "";
                var statusText = $("#filter_Status option:selected").text() || "All Statuses";
                var vehicleText = $("#filter_Vehicle option:selected").text() || "All Vehicles";
                
                var dateRange = "All Dates";
                if (fromDate && toDate) {
                    dateRange = fromDate + " to " + toDate;
                } else if (fromDate) {
                    dateRange = "From " + fromDate;
                } else if (toDate) {
                    dateRange = "Up to " + toDate;
                }

                var printWin = window.open('', '', 'width=1000,height=600');
                var tableHtml = $("#tbl_Logs").clone();
                tableHtml.find("tr").each(function () {
                    $(this).find("th:last, td:last").remove();
                });

                printWin.document.write('<html><head><title>Print Vehicle Trip Logs</title>');
                printWin.document.write('<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">');
                printWin.document.write('<style>body{padding:20px;font-family:sans-serif;} .filter-info{margin-bottom:15px;padding:10px;background:#f9f9f9;border:1px solid #ddd;border-radius:4px;font-size:12px;} table{width:100%;border-collapse:collapse;} th,td{padding:8px;border:1px solid #ddd;text-align:left;} th{background-color:#f5f5f5;}</style>');
                printWin.document.write('</head><body>');
                printWin.document.write('<h2>Vehicle Trip Logs</h2>');
                printWin.document.write('<div class="filter-info">');
                printWin.document.write('<strong>Branch:</strong> ' + branchName + ' | ');
                printWin.document.write('<strong>Timings (Dates):</strong> ' + dateRange + ' | ');
                printWin.document.write('<strong>Status:</strong> ' + statusText + ' | ');
                printWin.document.write('<strong>Vehicle:</strong> ' + vehicleText);
                printWin.document.write('</div>');
                printWin.document.write(tableHtml[0].outerHTML);
                printWin.document.write('</body></html>');
                printWin.document.close();

                setTimeout(function () {
                    printWin.focus();
                    printWin.print();
                    printWin.close();
                }, 500);
            }
        </script>
    </asp:Content>

    <asp:Content ID="Content2" ContentPlaceHolderID="ctnForm" runat="Server">
        <input type="hidden" id="hf_ReviewLogId" />
        <input type="hidden" id="hf_ReviewAction" />
        <input type="hidden" id="hf_AnswerLogId" />

        <div class="content-wrapper">
            <section class="content-header">
                <h1>Vehicle Trip Logs
                    <small>Review & History</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="../General/Dashboard.aspx"><i class="fa fa-dashboard"></i>Home</a></li>
                    <li class="active">Trip Logs</li>
                </ol>
            </section>

            <section class="content">
                <!-- Filter Bar -->
                <div class="filter-box">
                    <div class="row">
                        <div class="form-group col-md-2">
                            <label for="filter_Status">Filter Status</label>
                            <select id="filter_Status" class="form-control" onchange="getTbleDet()">
                                <option value="">All Statuses</option>
                                <option value="pending" selected>Pending Review</option>
                                <option value="approved">Approved</option>
                                <option value="rejected">Rejected</option>
                                <option value="queried">Queried (Awaiting Answer)</option>
                                <option value="answered">Answered (Needs Re-evaluation)</option>
                            </select>
                        </div>
                        <div class="form-group col-md-2">
                            <label for="filter_Vehicle">Filter Vehicle</label>
                            <select id="filter_Vehicle" class="form-control" onchange="getTbleDet()"></select>
                        </div>
                        <div class="form-group col-md-2">
                            <label for="filter_Branch">Filter Branch</label>
                            <select id="filter_Branch" class="form-control" onchange="getTbleDet()"></select>
                        </div>
                        <div class="form-group col-md-2">
                            <label for="filter_FromDate">From Date</label>
                            <input type="date" id="filter_FromDate" class="form-control" onchange="getTbleDet()" />
                        </div>
                        <div class="form-group col-md-2">
                            <label for="filter_ToDate">To Date</label>
                            <input type="date" id="filter_ToDate" class="form-control" onchange="getTbleDet()" />
                        </div>
                        <div class="form-group col-md-2">
                            <label>&nbsp;</label>
                            <button type="button" class="btn btn-primary btn-block" onclick="getTbleDet()"><i
                                    class="fa fa-refresh"></i> Refresh</button>
                        </div>
                    </div>
                </div>

                <!-- Grid Box -->
                <div class="row">
                    <div class="col-xs-12">
                        <div class="box box-primary">
                            <div class="box-header with-border">
                                <h3 class="box-title">Vehicle Trip Logs</h3>
                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-default btn-sm"
                                        onclick="printFilteredList()"><i class="fa fa-print"></i> Print List</button>
                                </div>
                            </div>
                            <div class="box-body">
                                <table id="tbl_Logs" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th style="text-align: center; width: 1%">#</th>
                                            <th style="width: 10%">Vehicle</th>
                                            <th style="width: 15%">Driver</th>
                                            <th style="width: 20%">Route Route</th>
                                            <th style="width: 15%">Timings</th>
                                            <th style="width: 8%; text-align: right;">Distance</th>
                                            <th style="width: 8%; text-align: right;">Refill</th>
                                            <th style="width: 8%; text-align: right;">Mileage</th>
                                            <th style="width: 10%; text-align: center;">Status</th>
                                            <th style="width: 12%; text-align: center;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tbl_bdy_Logs"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Details Modal -->
                <div id="modal-details" class="modal fade" role="dialog">
                    <div class="modal-dialog modal-md">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">Trip Log Book Specifications</h4>
                            </div>
                            <div class="modal-body">
                                <table class="table table-bordered log-details-table">
                                    <tr>
                                        <th>Vehicle Profile</th>
                                        <td id="lbl_DetVehicle"></td>
                                    </tr>
                                    <tr>
                                        <th>Driver Name</th>
                                        <td id="lbl_DetDriver"></td>
                                    </tr>
                                    <tr>
                                        <th>Locations Route</th>
                                        <td id="lbl_DetRoute"></td>
                                    </tr>
                                    <tr>
                                        <th>Start Date & Time</th>
                                        <td id="lbl_DetStart"></td>
                                    </tr>
                                    <tr>
                                        <th>End Date & Time</th>
                                        <td id="lbl_DetEnd"></td>
                                    </tr>
                                    <tr>
                                        <th>Starting Odometer KM</th>
                                        <td id="lbl_DetStartKm"></td>
                                    </tr>
                                    <tr>
                                        <th>Ending Odometer KM</th>
                                        <td id="lbl_DetEndKm"></td>
                                    </tr>
                                    <tr>
                                        <th>Total Distance Travelled</th>
                                        <td id="lbl_DetDistance"></td>
                                    </tr>
                                    <tr>
                                        <th>Est. Fuel Before Trip</th>
                                        <td id="lbl_DetFuelAvailable"></td>
                                    </tr>
                                    <tr>
                                        <th>Fuel Added / Refilled</th>
                                        <td id="lbl_DetFuelAdded"></td>
                                    </tr>
                                    <tr>
                                        <th>Remaining Fuel Left</th>
                                        <td id="lbl_DetFuelRemaining"></td>
                                    </tr>
                                    <tr>
                                        <th>Total Fuel Consumed</th>
                                        <td id="lbl_DetFuelUsed"></td>
                                    </tr>
                                    <tr>
                                        <th>Calculated Odo Mileage</th>
                                        <td id="lbl_DetMileage"></td>
                                    </tr>
                                    <tr>
                                        <th>Reporting Office</th>
                                        <td id="lbl_DetLocation"></td>
                                    </tr>
                                    <tr>
                                        <th>Current Log Status</th>
                                        <td id="lbl_DetStatus" style="font-weight:bold;"></td>
                                    </tr>
                                    <tr>
                                        <th>Created By Account</th>
                                        <td id="lbl_DetCreatedBy"></td>
                                    </tr>
                                    <tr>
                                        <th>Odometer Mileage Variance</th>
                                        <td id="lbl_DetVarianceReason" style="color:orange;"></td>
                                    </tr>
                                    <tr>
                                        <th>Review Rejection reason</th>
                                        <td id="lbl_DetRejectReason" style="color:red;"></td>
                                    </tr>
                                    <tr>
                                        <th>Pending Query Question</th>
                                        <td id="lbl_DetQuery"></td>
                                    </tr>
                                    <tr>
                                        <th>Query Answer Response</th>
                                        <td id="lbl_DetAnswer"></td>
                                    </tr>
                                </table>

                                <!-- Details Log Expenses -->
                                <div id="div_DetExpenses" style="margin-top: 15px;">
                                    <h4>Trip Expenses Grid</h4>
                                    <table class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Type</th>
                                                <th style="text-align:right;">Amount (Rs)</th>
                                                <th>Notes / Remarks</th>
                                            </tr>
                                        </thead>
                                        <tbody id="tbl_DetExpensesBdy"></tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Review / Action dialog Modal -->
                <div id="modal-review" class="modal fade" role="dialog">
                    <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title" id="modal_review_title">Review Action</h4>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label id="lbl_ReviewReason">Reason *</label>
                                    <textarea id="txt_ReviewReason" class="form-control" rows="3"></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left"
                                    data-dismiss="modal">Cancel</button>
                                <button type="button" class="btn btn-primary" onclick="submitReviewReason()">Submit
                                    Review</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Answer Query Modal -->
                <div id="modal-answer" class="modal fade" role="dialog">
                    <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">Reply to Query</h4>
                            </div>
                            <div class="modal-body">
                                <div class="well well-sm">
                                    <strong>Query Question:</strong>
                                    <p id="lbl_QueryQuestionText" class="text-warning"></p>
                                </div>
                                <div class="form-group">
                                    <label for="txt_QueryAnswer">Query Answer *</label>
                                    <textarea id="txt_QueryAnswer" class="form-control" rows="3"
                                        placeholder="Provide answer explanation or document proof reference..."></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left"
                                    data-dismiss="modal">Cancel</button>
                                <button type="button" class="btn btn-primary" onclick="submitQueryAnswer()">Submit
                                    Reply</button>
                            </div>
                        </div>
                    </div>
                </div>

            </section>
        </div>
    </asp:Content>