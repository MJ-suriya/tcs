<%@ Page Title="" Language="C#" MasterPageFile="~/General/Master.master" AutoEventWireup="true"
    CodeFile="ScrapEntryList.aspx.cs" Inherits="Transaction_ScrapEntryList" %>

    <asp:Content ID="Content1" ContentPlaceHolderID="ctnHead" runat="Server">
        <style>
            .filter-box {
                background-color: #fcfcfc;
                border: 1px solid #ddd;
                padding: 15px;
                margin-bottom: 20px;
                border-radius: 4px;
            }

            .details-table th {
                width: 35%;
                background-color: #f4f6f9;
            }

            .setting-card {
                background-color: #ecf0f5;
                border: 1px solid #d2d6de;
                padding: 10px 15px;
                margin-bottom: 15px;
                border-radius: 3px;
            }
        </style>
        <script class="text/javascript">
            var activeEntriesList = [];
            var currentUserRole = '';
            var hasEditPermission = '<%= Session["EditSession"] != null ? Session["EditSession"].ToString() : "none" %>';
            var hasApprovalPermission = '<%= Session["ApprovalSession"] != null ? Session["ApprovalSession"].ToString() : "none" %>';

            window.onload = function () {
                LoadSystemSettings();
                LoadBranchesFilter();
                getTbleDet();
            };

            function LoadSystemSettings() {
                PageMethods.GetSystemSetting("enableSecurityScrapEntry", function (response) {
                    var isEnabled = response && response.value === true;
                    $("#chk_EnableSecurityScrap").prop("checked", isEnabled);
                });

                // Check role to display settings card
                PageMethods.GetEntries("", "", "", function (res) {
                    // Determine user role implicitly from response check or system method
                });

                // Let's run CheckSecurityStatus to get role
                PageMethods.GetSystemSetting("enableSecurityScrapEntry", function () {
                    // Dummy check to hit server session and identify role
                });
            }

            function LoadBranchesFilter() {
                PageMethods.GetBranches(function (response) {
                    $("#filter_Branch").html("<option value=''>All Branches</option>");
                    if (response && response.length > 0) {
                        $.each(response, function (key, val) {
                            $("#filter_Branch").append("<option value='" + val.id + "'>" + val.name + "</option>");
                        });
                    }
                });
            }

            function toggleSecurityScrap() {
                var val = $("#chk_EnableSecurityScrap").is(":checked");
                PageMethods.UpdateSystemSetting("enableSecurityScrapEntry", val, function (response) {
                    if (response.error) {
                        swal("Error", response.error, "error");
                        $("#chk_EnableSecurityScrap").prop("checked", !val);
                    } else {
                        swal("Success", "Security Scrap entry policy updated!", "success");
                    }
                });
            }

            function getTbleDet() {
                if ($.fn.DataTable.isDataTable('#tbl_Entries')) {
                    $("#tbl_Entries").DataTable().destroy();
                }
                $("#tbl_bdy_Entries").html('<tr><td colspan="8" style="text-align:center;padding:20px;font-weight:bold;color:#666;"><i class="fa fa-spinner fa-spin fa-2x"></i><br/>Loading records...</td></tr>');

                var status = $("#filter_Status").val();
                var fromDate = $("#filter_FromDate").val();
                var toDate = $("#filter_ToDate").val();
                var branchId = $("#filter_Branch").val();

                PageMethods.GetEntries(status, fromDate, toDate, function (response) {
                    activeEntriesList = response || [];
                    $("#tbl_bdy_Entries").html("");
                    if (response && response.length > 0) {
                        var filtered = response;
                        if (branchId) {
                            filtered = $.grep(response, function (item) {
                                return item.branch === branchId;
                            });
                        }
                        $.each(filtered, function (key, val) {
                            var dateStr = formatDate(val.createdAt);

                            var badgeClass = 'default';
                            if (val.status === 'approved') badgeClass = 'success';
                            else if (val.status === 'rejected') badgeClass = 'danger';
                            else if (val.status === 'pending_pettycashier' || val.status === 'pending_manager') badgeClass = 'warning';
                            else if (val.status === 'queried') badgeClass = 'danger';

                            var statusLabel = val.status.replace('pending_pettycashier', 'pending').replace('_', ' ').toUpperCase();
                            if ((val.status === 'approved' || val.status === 'rejected') && val.reviewedBy) {
                                statusLabel += ' (' + val.reviewedBy + ')';
                            }

                            var actionsHtml = '<button type="button" class="btn btn-default btn-xs" style="margin-right: 5px;" onclick="viewDetails(' + key + ')"><i class="fa fa-eye"></i> Details</button>';

                            // Verification/Approvals
                            if (val.status === 'pending_pettycashier' && hasEditPermission === 'inline') {
                                actionsHtml += ' <button type="button" class="btn btn-primary btn-xs" style="margin-right: 5px;" onclick="openVerifyModal(\'' + val.id + '\', ' + val.totalAmount + ')"><i class="fa fa-check-square-o"></i> Verify</button>';
                            } else if (val.status === 'pending_manager' && hasApprovalPermission === 'inline') {
                                actionsHtml += ' <button type="button" class="btn btn-success btn-xs" style="margin-top: 5px;" onclick="reviewEntry(\'' + val.id + '\', \'approve\')"><i class="fa fa-check"></i> Approve</button>'
                                    + ' <button type="button" class="btn btn-warning btn-xs" style="margin-top: 5px;" onclick="openReviewModal(\'' + val.id + '\', \'query\')"><i class="fa fa-question"></i> Query</button>'
                                    + ' <button type="button" class="btn btn-danger btn-xs" style="margin-top: 5px;" onclick="openReviewModal(\'' + val.id + '\', \'reject\')"><i class="fa fa-remove"></i> Reject</button>';
                            }

                            var row = '<tr style="font-size:smaller;">'
                                + '<td style="text-align:center;">' + (key + 1) + '</td>'
                                + '<td><strong>' + val.companyName + '</strong></td>'
                                + '<td>' + val.vehicleNumber + '</td>'
                                + '<td>' + val.productName + '</td>'
                                + '<td style="text-align:right; font-weight:bold;">Rs ' + (val.pettyCashierVerifiedAmount ? val.pettyCashierVerifiedAmount.toFixed(2) : val.totalAmount.toFixed(2)) + '</td>'
                                + '<td>' + dateStr + '</td>'
                                + '<td style="text-align:center;"><span class="label label-' + badgeClass + '">' + statusLabel + '</span></td>'
                                + '<td style="text-align:center;">' + actionsHtml + '</td>'
                                + '</tr>';

                            $("#tbl_bdy_Entries").append(row);
                        });

                        $('#tbl_Entries').DataTable({
                            'destroy': true,
                            'paging': true,
                            'lengthChange': true,
                            'searching': true,
                            'ordering': true,
                            'info': true,
                            'autoWidth': false
                        });
                    }
                });
            }

            function viewDetails(idx) {
                var entry = activeEntriesList[idx];
                if (!entry) return;

                $("#lbl_DetCompany").text(entry.companyName);
                $("#lbl_DetVehicle").text(entry.vehicleNumber);
                $("#lbl_DetOwner").text(entry.ownerName);
                $("#lbl_DetCreatedBy").text(entry.createdBy);
                $("#lbl_DetBranch").text(entry.branchName || "System / Main");
                $("#lbl_DetDate").text(formatDate(entry.createdAt));
                $("#lbl_DetTotal").text("Rs " + entry.totalAmount.toFixed(2));
                $("#lbl_DetVerifiedTotal").text(entry.pettyCashierVerifiedAmount ? ("Rs " + entry.pettyCashierVerifiedAmount.toFixed(2)) : "Pending Verification");
                var statusText = entry.status.replace('_', ' ').toUpperCase();
                if (entry.reviewedBy) {
                    statusText += ' (' + entry.reviewedBy + ')';
                }
                $("#lbl_DetStatus").text(statusText);

                $("#lbl_DetRejectReason").text(entry.rejectReason || "None");
                $("#lbl_DetQuery").text(entry.queryQuestion || "None");
                $("#lbl_DetAnswer").text(entry.queryAnswer || "None");

                if (entry.proofDocument) {
                    var files = entry.proofDocument.split(';');
                    var html = '';
                    $.each(files, function (i, file) {
                        if (file.trim()) {
                            var filename = file.substring(file.lastIndexOf('/') + 1);
                            html += '<a href="../' + file.trim() + '" target="_blank" class="btn btn-default btn-xs" style="margin-right:5px; margin-bottom:5px;"><i class="fa fa-file-image-o"></i> View ' + filename + '</a> ';
                        }
                    });
                    $("#div_DetProof").html(html);
                } else {
                    $("#div_DetProof").text("No file uploaded");
                }

                // Render materials table
                $("#tbl_DetMaterialsBdy").html("");
                if (entry.items && entry.items.length > 0) {
                    $.each(entry.items, function (k, item) {
                        var total = item.weight * item.pricePerKg;
                        var itemRow = '<tr>'
                            + '<td>' + (k + 1) + '</td>'
                            + '<td class="text-uppercase"><strong>' + item.productName + '</strong></td>'
                            + '<td class="text-right">' + item.weight.toFixed(2) + ' Kg</td>'
                            + '<td class="text-right">Rs ' + item.pricePerKg.toFixed(2) + '</td>'
                            + '<td class="text-right">Rs ' + total.toFixed(2) + '</td>'
                            + '</tr>';
                        $("#tbl_DetMaterialsBdy").append(itemRow);
                    });
                }

                $("#modal-details").modal('show');
            }

            function openVerifyModal(id, expectedAmount) {
                $("#hf_VerifyEntryId").val(id);
                $("#hf_VerifyExpectedAmount").val(expectedAmount);
                $("#txt_VerifyAmount").val(expectedAmount.toFixed(2));
                var file1 = document.getElementById('file_VerifyProof1');
                if (file1) file1.value = "";
                var file2 = document.getElementById('file_VerifyProof2');
                if (file2) file2.value = "";
                $("#file_names_list").html("");
                $("#modal-verify").modal('show');
            }

            function showSelectedFilesList() {
                var listContainer = $("#file_names_list");
                listContainer.html("");
                var count = 0;
                var namesHtml = "<strong>Selected Files:</strong><ol style='padding-left: 15px; margin-top: 5px;'>";

                var file1 = document.getElementById('file_VerifyProof1');
                if (file1 && file1.files && file1.files.length > 0) {
                    namesHtml += "<li>[Invoice] " + file1.files[0].name + " (" + (file1.files[0].size / 1024).toFixed(1) + " KB)</li>";
                    count++;
                }

                var file2 = document.getElementById('file_VerifyProof2');
                if (file2 && file2.files && file2.files.length > 0) {
                    namesHtml += "<li>[Other] " + file2.files[0].name + " (" + (file2.files[0].size / 1024).toFixed(1) + " KB)</li>";
                    count++;
                }

                namesHtml += "</ol>";
                if (count > 0) {
                    listContainer.html(namesHtml);
                }
            }

            function compressImage(file, callback) {
                if (!file.type.match(/image.*/)) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        callback(e.target.result);
                    };
                    reader.readAsDataURL(file);
                    return;
                }

                var reader = new FileReader();
                reader.onload = function (readerEvent) {
                    var image = new Image();
                    image.onload = function (imageEvent) {
                        var canvas = document.createElement('canvas');
                        var max_size = 1600;
                        var width = image.width;
                        var height = image.height;
                        if (width > height) {
                            if (width > max_size) {
                                height *= max_size / width;
                                width = max_size;
                            }
                        } else {
                            if (height > max_size) {
                                width *= max_size / height;
                                height = max_size;
                            }
                        }
                        canvas.width = width;
                        canvas.height = height;
                        var ctx = canvas.getContext('2d');
                        ctx.drawImage(image, 0, 0, width, height);
                        var dataUrl = canvas.toDataURL('image/jpeg', 0.7);
                        callback(dataUrl);
                    };
                    image.src = readerEvent.target.result;
                };
                reader.readAsDataURL(file);
            }

            function submitVerification() {
                var id = $("#hf_VerifyEntryId").val();
                var amt = parseFloat($("#txt_VerifyAmount").val());

                if (isNaN(amt) || amt <= 0) {
                    swal("Attention", "Please enter a valid verified amount.", "warning");
                    return;
                }

                var fileInput1 = document.getElementById('file_VerifyProof1');
                var fileInput2 = document.getElementById('file_VerifyProof2');

                if (!fileInput1 || !fileInput1.files || fileInput1.files.length === 0) {
                    swal("Attention", "Invoice Slip Document is mandatory.", "warning");
                    return;
                }

                var filesToLoad = [];
                filesToLoad.push(fileInput1.files[0]);

                if (fileInput2 && fileInput2.files && fileInput2.files.length > 0) {
                    filesToLoad.push(fileInput2.files[0]);
                }

                swal({
                    title: "Processing...",
                    text: "Please wait while we compress and upload files.",
                    icon: "info",
                    buttons: false,
                    closeOnClickOutside: false,
                    closeOnEsc: false
                });

                var filesData = [];
                var loadedCount = 0;
                var totalFiles = filesToLoad.length;

                for (var i = 0; i < totalFiles; i++) {
                    (function (file) {
                        compressImage(file, function (compressedBase64) {
                            var finalFileName = file.name;
                            if (file.type.match(/image.*/) && !finalFileName.toLowerCase().endsWith('.jpg') && !finalFileName.toLowerCase().endsWith('.jpeg')) {
                                finalFileName = finalFileName.substring(0, finalFileName.lastIndexOf('.')) + '.jpg';
                            }
                            filesData.push({
                                fileName: finalFileName,
                                base64Data: compressedBase64
                            });
                            loadedCount++;
                            if (loadedCount === totalFiles) {
                                executeVerification(id, amt, JSON.stringify(filesData));
                            }
                        });
                    })(filesToLoad[i]);
                }
            }

            function executeVerification(id, amt, filesJson) {
                PageMethods.VerifyScrapEntry(id, amt, filesJson, function (response) {
                    if (response.error) {
                        swal("Error", response.error, "error");
                    } else {
                        swal("Success", "Scrap entry verified and forwarded to Manager for approval!", "success")
                            .then(function () {
                                $("#modal-verify").modal('hide');
                                getTbleDet();
                            });
                    }
                });
            }

            function reviewEntry(id, action, reason) {
                swal({
                    title: "Are you sure?",
                    text: "Do you want to " + action + " this scrap entry?",
                    icon: "info",
                    buttons: true
                }).then(function (willSubmit) {
                    if (willSubmit) {
                        if (action === 'approve') {
                            PageMethods.ApproveEntry(id, function (res) {
                                if (res.error) swal("Error", res.error, "error");
                                else {
                                    swal("Success", "Entry approved successfully!", "success");
                                    getTbleDet();
                                }
                            });
                        } else if (action === 'reject') {
                            PageMethods.RejectEntry(id, reason || "", function (res) {
                                if (res.error) swal("Error", res.error, "error");
                                else {
                                    swal("Success", "Entry rejected!", "success");
                                    $("#modal-review").modal('hide');
                                    getTbleDet();
                                }
                            });
                        } else if (action === 'query') {
                            PageMethods.QueryEntry(id, reason || "", function (res) {
                                if (res.error) swal("Error", res.error, "error");
                                else {
                                    swal("Success", "Query sent to pettycashier!", "success");
                                    $("#modal-review").modal('hide');
                                    getTbleDet();
                                }
                            });
                        }
                    }
                });
            }

            function openReviewModal(id, action) {
                $("#hf_ReviewEntryId").val(id);
                $("#hf_ReviewAction").val(action);

                if (action === 'reject') {
                    $("#modal_review_title").text("Reject Scrap entry");
                    $("#lbl_ReviewReason").text("Enter Rejection Reason *");
                    $("#txt_ReviewReason").attr("placeholder", "Why is this scrap rejected?");
                } else {
                    $("#modal_review_title").text("Query Scrap Entry");
                    $("#lbl_ReviewReason").text("Enter Query Question *");
                    $("#txt_ReviewReason").attr("placeholder", "What details need clarification?");
                }

                $("#txt_ReviewReason").val("");
                $("#modal-review").modal('show');
            }

            function submitReviewReason() {
                var id = $("#hf_ReviewEntryId").val();
                var action = $("#hf_ReviewAction").val();
                var reason = $("#txt_ReviewReason").val().trim();

                if (reason.length === 0) {
                    swal("Attention", "Please provide a reason / question details.", "warning");
                    return;
                }

                reviewEntry(id, action, reason);
            }

            function openAnswerModal(id, queryText) {
                $("#hf_AnswerEntryId").val(id);
                $("#lbl_QueryQuestionText").text(queryText);
                $("#txt_QueryAnswer").val("");
                $("#modal-answer").modal('show');
            }

            function submitQueryAnswer() {
                var id = $("#hf_AnswerEntryId").val();
                var ans = $("#txt_QueryAnswer").val().trim();

                if (ans.length === 0) {
                    swal("Attention", "Please provide an answer reply", "warning");
                    return;
                }

                PageMethods.AnswerEntryQuery(id, ans, function (response) {
                    if (response.error) {
                        swal("Error", response.error, "error");
                    } else {
                        swal("Success", "Query answer submitted successfully!", "success");
                        $("#modal-answer").modal('hide');
                        getTbleDet();
                    }
                });
            }

            function formatDate(dateObj) {
                if (!dateObj) return "—";
                var d = new Date(dateObj);
                if (isNaN(d.getTime())) return "—";
                var datePart = d.getDate() + '/' + (d.getMonth() + 1) + '/' + d.getFullYear();
                var timePart = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
                return datePart + ', ' + timePart;
            }

            // Helper Abs value for float comparison
            Math.Abs = function (val) {
                return val < 0 ? -val : val;
            }

            function printFilteredList() {
                var branchName = $("#filter_Branch option:selected").text() || "All Branches";
                var fromDate = $("#filter_FromDate").val() || "";
                var toDate = $("#filter_ToDate").val() || "";
                var statusText = $("#filter_Status option:selected").text() || "All Statuses";

                var dateRange = "All Dates";
                if (fromDate && toDate) {
                    dateRange = fromDate + " to " + toDate;
                } else if (fromDate) {
                    dateRange = "From " + fromDate;
                } else if (toDate) {
                    dateRange = "Up to " + toDate;
                }

                var totalSum = 0;
                $("#tbl_bdy_Entries tr").each(function () {
                    var amtText = $(this).find("td").eq(4).text();
                    if (amtText) {
                        var amtVal = parseFloat(amtText.replace(/[^0-9.]/g, ''));
                        if (!isNaN(amtVal)) {
                            totalSum += amtVal;
                        }
                    }
                });

                var printWin = window.open('', '', 'width=900,height=600');
                var tableHtml = $("#tbl_Entries").clone();
                tableHtml.find("tr").each(function () {
                    $(this).find("th:last, td:last").remove();
                });

                printWin.document.write('<html><head><title>Print List</title>');
                printWin.document.write('<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">');
                printWin.document.write('<style>body{padding:20px;font-family:sans-serif;} .filter-info{margin-bottom:15px;padding:10px;background:#f9f9f9;border:1px solid #ddd;border-radius:4px;font-size:12px;} .total-value{margin-bottom:15px;padding:10px;background:#eef7ee;border:1px solid #c8e6c9;border-radius:4px;font-size:14px;font-weight:bold;color:#2e7d32;} table{width:100%;border-collapse:collapse;} th,td{padding:8px;border:1px solid #ddd;text-align:left;} th{background-color:#f5f5f5;}</style>');
                printWin.document.write('</head><body>');
                printWin.document.write('<h2>Scrap Entry Logs</h2>');
                printWin.document.write('<div class="filter-info">');
                printWin.document.write('<strong>Branch:</strong> ' + branchName + ' | ');
                printWin.document.write('<strong>Timings (Dates):</strong> ' + dateRange + ' | ');
                printWin.document.write('<strong>Status:</strong> ' + statusText);
                printWin.document.write('</div>');

                if (fromDate && toDate) {
                    printWin.document.write('<div class="total-value">');
                    printWin.document.write('Total Value of Filtered Entries: Rs ' + totalSum.toFixed(2));
                    printWin.document.write('</div>');
                }

                printWin.document.write(tableHtml[0].outerHTML);
                printWin.document.write('</body></html>');
                printWin.document.close();

                setTimeout(function () {
                    printWin.focus();
                    printWin.print();
                    printWin.close();
                }, 500);
            }
        </script>
    </asp:Content>

    <asp:Content ID="Content2" ContentPlaceHolderID="ctnForm" runat="Server">
        <input type="hidden" id="hf_VerifyEntryId" />
        <input type="hidden" id="hf_VerifyExpectedAmount" />
        <input type="hidden" id="hf_ReviewEntryId" />
        <input type="hidden" id="hf_ReviewAction" />
        <input type="hidden" id="hf_AnswerEntryId" />

        <div class="content-wrapper">
            <section class="content-header">
                <h1>Scrap Entry Logs
                    <small>Verification & Audit</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="../General/Dashboard.aspx"><i class="fa fa-dashboard"></i>Home</a></li>
                    <li class="active">Scrap Entry Logs</li>
                </ol>
            </section>

            <section class="content">


                <!-- Filter Bar -->
                <div class="filter-box">
                    <div class="row">
                        <div class="form-group col-md-2">
                            <label for="filter_Status">Filter Status</label>
                            <select id="filter_Status" class="form-control" onchange="getTbleDet()">
                                <option value="">All Statuses</option>
                                <option value="pending" selected>Pending Review / Verification</option>
                                <option value="approved">Approved Entries</option>
                                <option value="rejected">Rejected Entries</option>
                            </select>
                        </div>
                        <div class="form-group col-md-2">
                            <label for="filter_Branch">Filter Branch</label>
                            <select id="filter_Branch" class="form-control" onchange="getTbleDet()"></select>
                        </div>
                        <div class="form-group col-md-2">
                            <label for="filter_FromDate">From Date</label>
                            <input type="date" id="filter_FromDate" class="form-control" onchange="getTbleDet()" />
                        </div>
                        <div class="form-group col-md-2">
                            <label for="filter_ToDate">To Date</label>
                            <input type="date" id="filter_ToDate" class="form-control" onchange="getTbleDet()" />
                        </div>
                        <div class="form-group col-md-4">
                            <label>&nbsp;</label>
                            <button type="button" class="btn btn-primary btn-block" onclick="getTbleDet()"><i
                                    class="fa fa-refresh"></i> Refresh Records</button>
                        </div>
                    </div>
                </div>

                <!-- Grid Box -->
                <div class="row">
                    <div class="col-xs-12">
                        <div class="box box-primary">
                            <div class="box-header with-border">
                                <h3 class="box-title">Scrap Entry Specification Logs</h3>
                                <div class="box-tools pull-right">
                                    <button type="button" class="btn btn-default btn-sm"
                                        onclick="printFilteredList()"><i class="fa fa-print"></i> Print List</button>
                                </div>
                            </div>
                            <div class="box-body">
                                <table id="tbl_Entries" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th style="text-align: center; width: 1%">#</th>
                                            <th style="width: 25%">Company / Vendor</th>
                                            <th style="width: 15%">Vehicle Number</th>
                                            <th style="width: 15%">Main Product</th>
                                            <th style="width: 12%; text-align: right;">Total Price</th>
                                            <th style="width: 12%">Date & Time</th>
                                            <th style="width: 10%; text-align: center;">Status</th>
                                            <th style="width: 10%; text-align: center;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tbl_bdy_Entries"></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Details Modal -->
                <div id="modal-details" class="modal fade" role="dialog">
                    <div class="modal-dialog modal-md">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">Scrap Entry Specifications</h4>
                            </div>
                            <div class="modal-body">
                                <table class="table table-bordered details-table">
                                    <tr>
                                        <th>Vendor / Company</th>
                                        <td id="lbl_DetCompany" style="font-weight:bold;"></td>
                                    </tr>
                                    <tr>
                                        <th>Vehicle Registration</th>
                                        <td id="lbl_DetVehicle"></td>
                                    </tr>
                                    <tr>
                                        <th>Owner / Driver</th>
                                        <td id="lbl_DetOwner"></td>
                                    </tr>
                                    <tr>
                                        <th>Estimated Total Price</th>
                                        <td id="lbl_DetTotal" style="color:green; font-weight:bold;"></td>
                                    </tr>
                                    <tr>
                                        <th>Verified Invoice Total</th>
                                        <td id="lbl_DetVerifiedTotal" style="color:blue; font-weight:bold;"></td>
                                    </tr>
                                    <tr>
                                        <th>Current Log Status</th>
                                        <td id="lbl_DetStatus" style="font-weight:bold;"></td>
                                    </tr>
                                    <tr>
                                        <th>Created By Account</th>
                                        <td id="lbl_DetCreatedBy"></td>
                                    </tr>
                                    <tr>
                                        <th>Reporting Branch</th>
                                        <td id="lbl_DetBranch"></td>
                                    </tr>
                                    <tr>
                                        <th>Date & Time Created</th>
                                        <td id="lbl_DetDate"></td>
                                    </tr>
                                    <tr>
                                        <th>Invoice Slip Document</th>
                                        <td id="div_DetProof"></td>
                                    </tr>
                                    <tr>
                                        <th>Review Rejection Reason</th>
                                        <td id="lbl_DetRejectReason" style="color:red;"></td>
                                    </tr>
                                    <tr>
                                        <th>Pending Query Question</th>
                                        <td id="lbl_DetQuery"></td>
                                    </tr>
                                    <tr>
                                        <th>Query Answer Response</th>
                                        <td id="lbl_DetAnswer"></td>
                                    </tr>
                                </table>

                                <!-- Items List Grid -->
                                <div style="margin-top: 15px;">
                                    <h4>Materials Purchased</h4>
                                    <table class="table table-striped table-bordered">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Material Name</th>
                                                <th style="text-align:right;">Weight (Kgs)</th>
                                                <th style="text-align:right;">Rate / Kg</th>
                                                <th style="text-align:right;">Total (Rs)</th>
                                            </tr>
                                        </thead>
                                        <tbody id="tbl_DetMaterialsBdy"></tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Petty Cashier Verification Modal -->
                <div id="modal-verify" class="modal fade" role="dialog">
                    <div class="modal-dialog modal-md">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">Verify Cash & Document</h4>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="txt_VerifyAmount">Verify Net Total Amount (Rs) *</label>
                                    <input type="number" step="0.01" id="txt_VerifyAmount" class="form-control" />
                                    <p class="help-block small">Enter the final verified amount. Pre-filled with
                                        expected amount.</p>
                                </div>
                                <div class="form-group">
                                    <label for="file_VerifyProof1">Invoice Slip Document * (Mandatory - 1 file)</label>
                                    <input type="file" id="file_VerifyProof1" class="form-control"
                                        accept="image/*,application/pdf" onchange="showSelectedFilesList()" />
                                </div>
                                <div class="form-group">
                                    <label for="file_VerifyProof2">Other Document Proof (Optional - 1 file)</label>
                                    <input type="file" id="file_VerifyProof2" class="form-control"
                                        accept="image/*,application/pdf" onchange="showSelectedFilesList()" />
                                    <div id="file_names_list" class="text-info small"
                                        style="margin-top: 10px; font-weight: bold;"></div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left"
                                    data-dismiss="modal">Cancel</button>
                                <button type="button" class="btn btn-primary" onclick="submitVerification()">Verify &
                                    Forward</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Review / Action dialog Modal -->
                <div id="modal-review" class="modal fade" role="dialog">
                    <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title" id="modal_review_title">Review Action</h4>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label id="lbl_ReviewReason">Reason *</label>
                                    <textarea id="txt_ReviewReason" class="form-control" rows="3"></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left"
                                    data-dismiss="modal">Cancel</button>
                                <button type="button" class="btn btn-primary" onclick="submitReviewReason()">Submit
                                    Review</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Answer Query Modal -->
                <div id="modal-answer" class="modal fade" role="dialog">
                    <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">Reply to Query</h4>
                            </div>
                            <div class="modal-body">
                                <div class="well well-sm">
                                    <strong>Query Question:</strong>
                                    <p id="lbl_QueryQuestionText" class="text-warning"></p>
                                </div>
                                <div class="form-group">
                                    <label for="txt_QueryAnswer">Query Answer *</label>
                                    <textarea id="txt_QueryAnswer" class="form-control" rows="3"
                                        placeholder="Provide answer explanation..."></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left"
                                    data-dismiss="modal">Cancel</button>
                                <button type="button" class="btn btn-primary" onclick="submitQueryAnswer()">Submit
                                    Reply</button>
                            </div>
                        </div>
                    </div>
                </div>

            </section>
        </div>
    </asp:Content>